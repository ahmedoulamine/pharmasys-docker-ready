package pharmasys_backend.produit;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "medicaments")
public class Produit {

    @Id
    private Long id;

    @Column(name = "code_ean13")
    private String codeEan13;

    private String denomination;
    private String dci;

    @Column(name = "forme_dosage")
    private String formeDosage;

    private String presentation;
    private String ppv;

    @Column(name = "base_remboursement_ppv")
    private String baseRemboursementPpv;

    private String ph;

    @Column(name = "base_remboursement_ph")
    private String baseRemboursementPh;

    @Column(name = "classe_therapeutique")
    private String classeTherapeutique;

    @Column(name = "p_g")
    private String pG;

    @Column(name = "remboursement_taux")
    private String remboursementTaux;

    private String pa;

    private Integer stock;

    @Column(name = "stock_minimum")
    private Integer stockMinimum;

    @Column(name = "seuil_alerte")
    private Integer seuilAlerte;

    @Column(name = "date_expiration")
    private LocalDate dateExpiration;

    public Long getId()                    { return id; }
    public String getCodeEan13()           { return codeEan13; }
    public String getDenomination()        { return denomination; }
    public String getDci()                 { return dci; }
    public String getFormeDosage()         { return formeDosage; }
    public String getPresentation()        { return presentation; }
    public String getPpv()                 { return ppv; }
    public String getBaseRemboursementPpv(){ return baseRemboursementPpv; }
    public String getPh()                  { return ph; }
    public String getBaseRemboursementPh() { return baseRemboursementPh; }
    public String getClasseTherapeutique() { return classeTherapeutique; }
    public String getPG()                  { return pG; }
    public String getRemboursementTaux()   { return remboursementTaux; }
    public String getPa()                  { return pa; }
    public Integer getStock()              { return stock != null ? stock : 0; }
    public Integer getStockMinimum()       { return stockMinimum; }
    public Integer getSeuilAlerte()        { return seuilAlerte; }
    public LocalDate getDateExpiration()   { return dateExpiration; }

    public void setId(Long v)                    { this.id = v; }
    public void setCodeEan13(String v)           { this.codeEan13 = v; }
    public void setDenomination(String v)        { this.denomination = v; }
    public void setDci(String v)                 { this.dci = v; }
    public void setFormeDosage(String v)         { this.formeDosage = v; }
    public void setPresentation(String v)        { this.presentation = v; }
    public void setPpv(String v)                 { this.ppv = v; }
    public void setBaseRemboursementPpv(String v){ this.baseRemboursementPpv = v; }
    public void setPh(String v)                  { this.ph = v; }
    public void setBaseRemboursementPh(String v) { this.baseRemboursementPh = v; }
    public void setClasseTherapeutique(String v) { this.classeTherapeutique = v; }
    public void setPG(String v)                  { this.pG = v; }
    public void setRemboursementTaux(String v)   { this.remboursementTaux = v; }
    public void setPa(String v)                  { this.pa = v; }
    public void setStock(Integer v)              { this.stock = v; }
    public void setStockMinimum(Integer v)       { this.stockMinimum = v; }
    public void setSeuilAlerte(Integer v)        { this.seuilAlerte = v; }
    public void setDateExpiration(LocalDate v)   { this.dateExpiration = v; }
}
