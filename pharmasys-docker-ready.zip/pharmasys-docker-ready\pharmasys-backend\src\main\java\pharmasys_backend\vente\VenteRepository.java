package pharmasys_backend.vente;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface VenteRepository extends JpaRepository<Vente, Long> {

    Page<Vente> findByOrderByDateVenteDesc(Pageable pageable);

    List<Vente> findByPatientNomContainingIgnoreCaseOrderByDateVenteDesc(String patientNom);

    List<Vente> findByPatientNomIgnoreCaseAndStatutOrderByDateVenteAsc(String patientNom, StatutVente statut);

    @Query(value = """
        SELECT COALESCE(SUM(
            CASE WHEN v.statut = 'COMPLETEE'  THEN  v.total_ttc
                 WHEN v.statut = 'EN_ATTENTE' THEN -v.total_ttc
                 ELSE 0
            END
        ), 0) FROM ventes v WHERE v.date_vente >= :debut
        """, nativeQuery = true)
    BigDecimal sumTotalDepuis(@Param("debut") LocalDateTime debut);

    long countByDateVenteAfterAndStatut(LocalDateTime debut, StatutVente statut);

    @Query("SELECT COUNT(v) FROM Vente v WHERE v.dateVente >= :debut AND v.statut = 'COMPLETEE'")
    long countByPeriode(@Param("debut") LocalDateTime debut);

    @Query(value = """
        SELECT TO_CHAR(v.date_vente, 'YYYY-MM-DD') as jour,
               COALESCE(SUM(
                   CASE WHEN v.statut = 'COMPLETEE'  THEN  v.total_ttc
                        WHEN v.statut = 'EN_ATTENTE' THEN -v.total_ttc
                        ELSE 0
                   END
               ), 0)                                                    as total,
               COUNT(CASE WHEN v.statut = 'COMPLETEE' THEN 1 END)      as nombre
        FROM ventes v
        WHERE v.date_vente >= :debut
        GROUP BY TO_CHAR(v.date_vente, 'YYYY-MM-DD')
        ORDER BY jour
        """, nativeQuery = true)
    List<Object[]> ventesParJour(@Param("debut") LocalDateTime debut);

    @Query(value = """
        SELECT TO_CHAR(v.date_vente, 'YYYY-MM') as mois,
               COALESCE(SUM(
                   CASE WHEN v.statut = 'COMPLETEE'  THEN  v.total_ttc
                        WHEN v.statut = 'EN_ATTENTE' THEN -v.total_ttc
                        ELSE 0
                   END
               ), 0)                                                    as total,
               COUNT(CASE WHEN v.statut = 'COMPLETEE' THEN 1 END)      as nombre
        FROM ventes v
        WHERE v.date_vente >= :debut
        GROUP BY TO_CHAR(v.date_vente, 'YYYY-MM')
        ORDER BY mois
        """, nativeQuery = true)
    List<Object[]> ventesParMois(@Param("debut") LocalDateTime debut);

    @Query(value = """
        SELECT COALESCE(m.classe_therapeutique, 'Autre') as categorie,
               COALESCE(SUM(lv.sous_total), 0)           as total
        FROM lignes_vente lv
        JOIN medicaments m ON lv.produit_id = m.id
        WHERE lv.vente_id IN (
            SELECT v.id FROM ventes v
            WHERE v.date_vente >= :debut AND v.statut = 'COMPLETEE'
        )
        GROUP BY m.classe_therapeutique
        ORDER BY total DESC
        """, nativeQuery = true)
    List<Object[]> ventesParCategorie(@Param("debut") LocalDateTime debut);

    @Query(value = """
        SELECT m.denomination                   as nom,
               COALESCE(SUM(lv.quantite), 0)   as quantite,
               COALESCE(SUM(lv.sous_total), 0) as chiffre
        FROM lignes_vente lv
        JOIN medicaments m ON lv.produit_id = m.id
        JOIN ventes v ON lv.vente_id = v.id
        WHERE v.statut = 'COMPLETEE'
        GROUP BY m.denomination
        ORDER BY quantite DESC
        LIMIT 10
        """, nativeQuery = true)
    List<Object[]> topProduits();

    @Query(value = """
        SELECT TRIM(TO_CHAR(v.date_vente, 'Day')) as jour,
               COALESCE(SUM(
                   CASE WHEN v.statut = 'COMPLETEE'  THEN  v.total_ttc
                        WHEN v.statut = 'EN_ATTENTE' THEN -v.total_ttc
                        ELSE 0
                   END
               ), 0)                                                    as total,
               COUNT(CASE WHEN v.statut = 'COMPLETEE' THEN 1 END)      as nombre
        FROM ventes v
        WHERE v.date_vente >= :debut AND v.date_vente < :fin
        GROUP BY TO_CHAR(v.date_vente, 'Day'), EXTRACT(DOW FROM v.date_vente)
        ORDER BY EXTRACT(DOW FROM v.date_vente)
        """, nativeQuery = true)
    List<Object[]> performanceHebdomadaire(@Param("debut") LocalDateTime debut, @Param("fin") LocalDateTime fin);

    @Query(value = """
        SELECT TO_CHAR(v.date_vente, 'DD') as jour,
               COALESCE(SUM(
                   CASE WHEN v.statut = 'COMPLETEE'  THEN  v.total_ttc
                        WHEN v.statut = 'EN_ATTENTE' THEN -v.total_ttc
                        ELSE 0
                   END
               ), 0)                                                    as total,
               COUNT(CASE WHEN v.statut = 'COMPLETEE' THEN 1 END)      as nombre
        FROM ventes v
        WHERE v.date_vente >= :debut AND v.date_vente < :fin
        GROUP BY TO_CHAR(v.date_vente, 'DD')
        ORDER BY jour
        """, nativeQuery = true)
    List<Object[]> performanceMensuelle(@Param("debut") LocalDateTime debut, @Param("fin") LocalDateTime fin);

    @Query(value = """
        SELECT v.id, v.date_vente, v.total_ttc
        FROM ventes v
        WHERE v.statut = 'COMPLETEE'
        ORDER BY v.date_vente DESC
        LIMIT 10
        """, nativeQuery = true)
    List<Object[]> findRecentActivity();
}
