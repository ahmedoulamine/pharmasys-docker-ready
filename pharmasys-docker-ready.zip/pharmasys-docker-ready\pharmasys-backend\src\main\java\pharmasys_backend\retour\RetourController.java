package pharmasys_backend.retour;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/retours")
@RequiredArgsConstructor
public class RetourController {

    private final RetourService retourService;

    @GetMapping
    public List<Retour> getAll() {
        return retourService.getAll();
    }

    @PostMapping
    public ResponseEntity<Retour> create(@RequestBody Retour retour) {
        return ResponseEntity.ok(retourService.create(retour));
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<Retour> approve(@PathVariable Long id) {
        return ResponseEntity.ok(retourService.approve(id));
    }

    @PutMapping("/{id}/refund")
    public ResponseEntity<Retour> refund(@PathVariable Long id) {
        return ResponseEntity.ok(retourService.refund(id));
    }
}
