package pharmasys_backend.produit;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDate;

@Service
public class ProduitService {

    private final ProduitRepository repo;

    public ProduitService(ProduitRepository repo) {
        this.repo = repo;
    }

    public Page<ProduitResponse> findAll(String search, Pageable pageable) {
        Page<Produit> page = (search == null || search.isBlank())
            ? repo.findAll(pageable)
            : repo.search(search.trim(), pageable);
        return page.map(this::toResponse);
    }

    public ProduitResponse findById(Long id) {
        return toResponse(repo.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Médicament introuvable")));
    }

    @Transactional
    public ProduitResponse updateStock(Long id, int quantite, String mode) {
        Produit p = repo.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Médicament introuvable"));
        int newStock = switch (mode) {
            case "SET"      -> quantite;
            case "ADD"      -> p.getStock() + quantite;
            case "REMOVE"   -> Math.max(0, p.getStock() - quantite);
            default         -> throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Mode invalide: " + mode);
        };
        p.setStock(newStock);
        return toResponse(repo.save(p));
    }

    @Transactional
    public ProduitResponse updateExpiration(Long id, LocalDate dateExpiration) {
        Produit p = repo.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Médicament introuvable"));
        p.setDateExpiration(dateExpiration);
        return toResponse(repo.save(p));
    }

    private ProduitResponse toResponse(Produit p) {
        return new ProduitResponse(
            p.getId(),
            p.getCodeEan13(),
            p.getDenomination(),
            p.getDci(),
            p.getFormeDosage(),
            p.getPresentation(),
            p.getPpv(),
            p.getBaseRemboursementPpv(),
            p.getPh(),
            p.getBaseRemboursementPh(),
            p.getClasseTherapeutique(),
            p.getPG(),
            p.getRemboursementTaux(),
            p.getPa(),
            p.getStock(),
            p.getStockMinimum(),
            p.getSeuilAlerte(),
            p.getDateExpiration()
        );
    }
}
