import axiosInstance from "../api/axios";

export const getAllRetours = () => axiosInstance.get('/retours');

export const createRetourApi = (retour) => axiosInstance.post('/retours', retour);

export const approveRetourApi = (id) => axiosInstance.put(`/retours/${id}/approve`);

export const refundRetourApi = (id) => axiosInstance.put(`/retours/${id}/refund`);
