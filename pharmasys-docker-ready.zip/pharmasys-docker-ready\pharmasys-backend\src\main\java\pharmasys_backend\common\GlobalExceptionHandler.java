package pharmasys_backend.common;

import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.servlet.resource.NoResourceFoundException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

	private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@ExceptionHandler(ResponseStatusException.class)
	public ResponseEntity<ApiError> handleResponseStatusException(
			ResponseStatusException exception,
			HttpServletRequest request) {
		HttpStatus status = HttpStatus.valueOf(exception.getStatusCode().value());
		ApiError apiError = new ApiError(
				LocalDateTime.now(),
				status.value(),
				status.getReasonPhrase(),
				exception.getReason(),
				request.getRequestURI(),
				Map.of()
		);
		return ResponseEntity.status(status).body(apiError);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ApiError> handleValidationException(
			MethodArgumentNotValidException exception,
			HttpServletRequest request) {
		Map<String, String> validationErrors = new LinkedHashMap<>();
		exception.getBindingResult().getFieldErrors().forEach(error ->
				validationErrors.put(error.getField(), error.getDefaultMessage())
		);

		ApiError apiError = new ApiError(
				LocalDateTime.now(),
				HttpStatus.BAD_REQUEST.value(),
				HttpStatus.BAD_REQUEST.getReasonPhrase(),
				"Donnees invalides",
				request.getRequestURI(),
				validationErrors
		);
		return ResponseEntity.badRequest().body(apiError);
	}

	@ExceptionHandler(NoResourceFoundException.class)
	public ResponseEntity<ApiError> handleNoResourceFoundException(
			NoResourceFoundException exception,
			HttpServletRequest request) {
		ApiError apiError = new ApiError(
				LocalDateTime.now(),
				HttpStatus.NOT_FOUND.value(),
				HttpStatus.NOT_FOUND.getReasonPhrase(),
				"Route introuvable",
				request.getRequestURI(),
				Map.of()
		);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiError);
	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ApiError> handleMethodArgumentTypeMismatchException(
			MethodArgumentTypeMismatchException exception,
			HttpServletRequest request) {
		ApiError apiError = new ApiError(
				LocalDateTime.now(),
				HttpStatus.BAD_REQUEST.value(),
				HttpStatus.BAD_REQUEST.getReasonPhrase(),
				"Parametre invalide",
				request.getRequestURI(),
				Map.of(exception.getName(), "Type invalide")
		);
		return ResponseEntity.badRequest().body(apiError);
	}

	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<ApiError> handleMethodNotSupportedException(
			HttpRequestMethodNotSupportedException exception,
			HttpServletRequest request) {
		ApiError apiError = new ApiError(
				LocalDateTime.now(),
				HttpStatus.METHOD_NOT_ALLOWED.value(),
				HttpStatus.METHOD_NOT_ALLOWED.getReasonPhrase(),
				"Methode HTTP non autorisee pour cette route",
				request.getRequestURI(),
				Map.of()
		);
		return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(apiError);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiError> handleUnexpectedException(
			Exception exception,
			HttpServletRequest request) {
		log.error("Unexpected error on {}: {}", request.getRequestURI(), exception.getMessage(), exception);
		ApiError apiError = new ApiError(
				LocalDateTime.now(),
				HttpStatus.INTERNAL_SERVER_ERROR.value(),
				HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
				"Erreur interne du serveur",
				request.getRequestURI(),
				Map.of()
		);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(apiError);
	}
}
