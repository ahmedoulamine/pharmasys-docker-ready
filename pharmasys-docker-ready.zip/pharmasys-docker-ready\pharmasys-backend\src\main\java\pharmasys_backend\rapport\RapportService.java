package pharmasys_backend.rapport;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pharmasys_backend.vente.VenteRepository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.util.*;

@Service
@RequiredArgsConstructor
public class RapportService {

    private final VenteRepository venteRepository;

    private LocalDateTime getDebut(String periode) {
        return switch (periode == null ? "mois" : periode) {
            case "jour"      -> LocalDate.now().atStartOfDay();
            case "semaine"   -> LocalDate.now().with(DayOfWeek.MONDAY).atStartOfDay();
            case "trimestre" -> LocalDate.now().withDayOfMonth(1).minusMonths(2).atStartOfDay();
            case "annee"     -> LocalDate.now().withDayOfYear(1).atStartOfDay();
            default          -> LocalDate.now().withDayOfMonth(1).atStartOfDay();
        };
    }

    public Map<String, Object> getStats(String periode) {
        LocalDateTime debut = getDebut(periode);
        BigDecimal total    = venteRepository.sumTotalDepuis(debut);
        long       count    = venteRepository.countByPeriode(debut);
        if (total == null) total = BigDecimal.ZERO;

        BigDecimal panier = count > 0
                ? total.divide(BigDecimal.valueOf(count), 2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

        long jours = switch (periode == null ? "mois" : periode) {
            case "jour"      -> 1;
            case "semaine"   -> 7;
            case "trimestre" -> 90;
            case "annee"     -> 365;
            default          -> 30;
        };
        BigDecimal venteMoyenne = jours > 0
                ? total.divide(BigDecimal.valueOf(jours), 2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

        Map<String, Object> map = new LinkedHashMap<>();
        map.put("ventesTotales", total);
        map.put("venteMoyenne",  venteMoyenne);
        map.put("transactions",  count);
        map.put("panierMoyen",   panier);
        return map;
    }

    public List<Map<String, Object>> getVentesParMois() {
        LocalDateTime debut = LocalDate.now().withDayOfYear(1).atStartOfDay();
        List<Object[]> rows = venteRepository.ventesParMois(debut);
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object[] row : rows) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("mois",   row[0]);
            map.put("ventes", row[1]);
            result.add(map);
        }
        return result;
    }

    public List<Map<String, Object>> getVentesParCategorie(String periode) {
        LocalDateTime debut = getDebut(periode);
        List<Object[]> rows = venteRepository.ventesParCategorie(debut);
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object[] row : rows) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("categorie", row[0] != null ? row[0] : "Autre");
            map.put("total",     row[1]);
            result.add(map);
        }
        return result;
    }

    public List<Map<String, Object>> getTopProduits() {
        List<Object[]> rows = venteRepository.topProduits();
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object[] row : rows) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("nom",    row[0]);
            map.put("unites", row[1]);
            map.put("ca",     row[2]);
            result.add(map);
        }
        return result;
    }

    public List<Map<String, Object>> getPerformanceHebdo(String periode) {
        List<Object[]> rows;
        if ("semaine".equals(periode)) {
            LocalDateTime lundi    = LocalDate.now().with(DayOfWeek.MONDAY).atStartOfDay();
            LocalDateTime dimanche = lundi.plusDays(7);
            rows = venteRepository.performanceHebdomadaire(lundi, dimanche);
        } else {
            LocalDateTime debut = LocalDate.now().withDayOfMonth(1).atStartOfDay();
            LocalDateTime fin   = debut.plusMonths(1);
            rows = venteRepository.performanceMensuelle(debut, fin);
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object[] row : rows) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("jour",         row[0]);
            map.put("ventes",       row[1]);
            map.put("transactions", row[2]);
            result.add(map);
        }
        return result;
    }
}
