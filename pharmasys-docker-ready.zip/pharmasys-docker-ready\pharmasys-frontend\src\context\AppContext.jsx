import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { fetchMedicaments, fetchVentes, fetchDefectueux, createVente } from '../services/api'
import { getExpiredSummary } from '../services/achatService'

const AppContext = createContext(null)

function loadUserFromStorage() {
  try {
    const raw = localStorage.getItem('pharma_user')
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

export function AppProvider({ children }) {
  const [user, setUser]               = useState(loadUserFromStorage)
  const [products, setProducts]       = useState([])
  const [totalProducts, setTotalProducts] = useState(0)
  const [sales, setSales]             = useState([])
  const [defectives, setDefectives]   = useState([])
  const [loading, setLoading]         = useState(true)
  const [apiError, setApiError]       = useState('')
  const [expiredLotMap, setExpiredLotMap] = useState({})

  async function refreshData() {
    setLoading(true)
    setApiError('')
    try {
      const [{ products: medicaments, total }, ventes, expSummary, defs] = await Promise.all([
        fetchMedicaments(),
        fetchVentes(),
        getExpiredSummary().catch(() => ({ data: [] })),
        fetchDefectueux().catch(() => []),
      ])
      setProducts(medicaments)
      setTotalProducts(total)
      setSales(ventes)
      setDefectives(defs)
      const map = {}
      ;(expSummary.data ?? []).forEach(s => { map[s.produitId] = s.quantitePerimee })
      setExpiredLotMap(map)
    } catch (error) {
      setApiError(error.message || 'Impossible de contacter le backend.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { if (user) { refreshData() } else { setLoading(false) } }, [])

  function login(userData) {
    const roleMap = {
      PHARMACIEN_TITULAIRE: 'TITULAIRE',
      RESPONSABLE_STOCK:    'RESPONSABLE_STOCK',
      CAISSIER:             'EMPLOYE',
    }
    const enriched = {
      ...userData,
      name: userData.nom ?? userData.name ?? '',
      role: userData.role ?? 'CAISSIER',
      roleNorm: roleMap[userData.role] ?? 'EMPLOYE',
    }
    localStorage.setItem('pharma_user', JSON.stringify(enriched))
    localStorage.setItem('role', enriched.roleNorm)
    if (userData.token) localStorage.setItem('token', userData.token)
    setUser(enriched)
    refreshData()
  }

  function logout() {
    localStorage.removeItem('pharma_user')
    localStorage.removeItem('role')
    localStorage.removeItem('token')
    setUser(null)
    setProducts([])
    setSales([])
  }

  async function validateSale(cart, payment) {
    const newSale = await createVente(cart, payment)
    setSales(prev => [newSale, ...prev])
    setProducts(prev => prev.map(p => {
      const item = cart.find(i => i.id === p.id)
      return item ? { ...p, stock: p.stock - item.qty } : p
    }))
    return newSale
  }

  const lowStockProducts   = useMemo(() => products.filter(p => p.stock > 0 && p.stock <= p.stockMin), [products])
  const outOfStockProducts = useMemo(() => products.filter(p => p.stock === 0), [products])
  const today90 = new Date(); today90.setDate(today90.getDate() + 90)
  const expiredProducts    = useMemo(() => products.filter(p => (expiredLotMap[p.id] ?? 0) > 0), [products, expiredLotMap])
  const expiringSoonProducts = useMemo(() => products.filter(p => {
    if (!p.dateExpiration) return false
    const d = new Date(p.dateExpiration)
    return d >= new Date() && d <= today90
  }), [products])
  const caJour = useMemo(
    () => sales
      .filter(s => s.date === new Date().toLocaleDateString('fr-FR') && s.statut === 'COMPLETEE')
      .reduce((sum, s) => sum + s.total, 0),
    [sales],
  )

  return (
    <AppContext.Provider value={{
      user, login, logout,
      products, totalProducts, sales, defectives,
      loading, apiError, refreshData,
      validateSale,
      lowStockProducts, outOfStockProducts, expiredProducts, expiringSoonProducts, caJour,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  return useContext(AppContext)
}
