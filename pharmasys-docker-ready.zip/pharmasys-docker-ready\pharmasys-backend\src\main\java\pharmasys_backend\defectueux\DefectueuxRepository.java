package pharmasys_backend.defectueux;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DefectueuxRepository extends JpaRepository<ProduitDefectueux, Long> {
    List<ProduitDefectueux> findByOrderByCreatedAtDesc();
}
