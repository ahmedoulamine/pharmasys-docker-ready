package pharmasys_backend.common;

// CORS is configured in SecurityConfig
public class CorsConfig {
}
