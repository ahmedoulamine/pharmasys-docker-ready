package pharmasys_backend.retour;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RetourService {

    private final RetourRepository retourRepository;

    public List<Retour> getAll() {
        return retourRepository.findAllByOrderByDateRetourDesc();
    }

    public Retour create(Retour retour) {
        if (retour.getStatut() == null) retour.setStatut(StatutRetour.EN_ATTENTE);
        return retourRepository.save(retour);
    }

    public Retour approve(Long id) {
        Retour retour = retourRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Retour non trouvé: " + id));
        retour.setStatut(StatutRetour.APPROUVE);
        return retourRepository.save(retour);
    }

    public Retour refund(Long id) {
        Retour retour = retourRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Retour non trouvé: " + id));
        retour.setStatut(StatutRetour.REMBOURSE);
        return retourRepository.save(retour);
    }
}
