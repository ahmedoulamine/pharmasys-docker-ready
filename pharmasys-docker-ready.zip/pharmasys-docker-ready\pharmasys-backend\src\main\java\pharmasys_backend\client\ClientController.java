package pharmasys_backend.client;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pharmasys_backend.vente.VenteResponse;
import pharmasys_backend.vente.VenteService;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/clients")
@RequiredArgsConstructor
public class ClientController {

    private final ClientService clientService;
    private final VenteService  venteService;

    @GetMapping
    public List<Client> getAll(@RequestParam(required = false) String search) {
        return clientService.getAll(search);
    }

    @GetMapping("/stats")
    public Map<String, Object> getStats() {
        return clientService.getStats();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Client> getById(@PathVariable Long id) {
        return ResponseEntity.ok(clientService.getById(id));
    }

    @PostMapping
    public ResponseEntity<Client> create(@RequestBody Client client) {
        return ResponseEntity.ok(clientService.create(client));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Client> update(@PathVariable Long id, @RequestBody Client client) {
        return ResponseEntity.ok(clientService.update(id, client));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        clientService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/credit")
    public ResponseEntity<Client> ajouterCredit(@PathVariable Long id, @RequestBody Map<String, Double> body) {
        Double montant = body.getOrDefault("montant", 0.0);
        return ResponseEntity.ok(clientService.ajouterCredit(id, montant));
    }

    @PatchMapping("/{id}/payer-credit")
    public ResponseEntity<Client> payerCredit(@PathVariable Long id, @RequestBody Map<String, Double> body) {
        Double montant = body.getOrDefault("montant", 0.0);
        return ResponseEntity.ok(clientService.payerCredit(id, montant));
    }

    @PatchMapping("/{id}/visite")
    public ResponseEntity<Client> visite(@PathVariable Long id, @RequestParam(defaultValue = "false") boolean achat) {
        return ResponseEntity.ok(clientService.mettreAJourVisite(id, achat));
    }

    @GetMapping("/{id}/ventes")
    public List<VenteResponse> getVentesClient(@PathVariable Long id) {
        Client client = clientService.getById(id);
        return venteService.findByPatientNom(client.getNom());
    }
}
