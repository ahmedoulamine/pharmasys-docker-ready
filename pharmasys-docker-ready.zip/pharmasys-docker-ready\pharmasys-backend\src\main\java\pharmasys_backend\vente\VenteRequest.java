package pharmasys_backend.vente;

import java.math.BigDecimal;
import java.util.List;

public class VenteRequest {

    private Long         caissierId;
    private ModePaiement modePaiement;
    private BigDecimal   montantRecu;
    private String       patientNom;
    private String       tpeReference;
    private String       tpeAutorisation;
    private String       tpeCarte;
    private List<LigneRequest> lignes;

    public static class LigneRequest {
        private Long    produitId;
        private Integer quantite;

        public Long    getProduitId() { return produitId; }
        public Integer getQuantite()  { return quantite; }
        public void setProduitId(Long p)    { this.produitId = p; }
        public void setQuantite(Integer q)  { this.quantite = q; }
    }

    public Long         getCaissierId()    { return caissierId; }
    public ModePaiement getModePaiement()  { return modePaiement; }
    public BigDecimal   getMontantRecu()   { return montantRecu; }
    public String       getPatientNom()    { return patientNom; }
    public String       getTpeReference()  { return tpeReference; }
    public String       getTpeAutorisation(){ return tpeAutorisation; }
    public String       getTpeCarte()      { return tpeCarte; }
    public List<LigneRequest> getLignes()  { return lignes; }

    public void setCaissierId(Long c)           { this.caissierId = c; }
    public void setModePaiement(ModePaiement m) { this.modePaiement = m; }
    public void setMontantRecu(BigDecimal m)    { this.montantRecu = m; }
    public void setPatientNom(String p)         { this.patientNom = p; }
    public void setTpeReference(String r)       { this.tpeReference = r; }
    public void setTpeAutorisation(String a)    { this.tpeAutorisation = a; }
    public void setTpeCarte(String c)           { this.tpeCarte = c; }
    public void setLignes(List<LigneRequest> l) { this.lignes = l; }
}
