-- Ajout des colonnes TPE dans la table ventes
ALTER TABLE ventes
    ADD COLUMN IF NOT EXISTS tpe_reference    VARCHAR(20),
    ADD COLUMN IF NOT EXISTS tpe_autorisation VARCHAR(10),
    ADD COLUMN IF NOT EXISTS tpe_carte        VARCHAR(30);
