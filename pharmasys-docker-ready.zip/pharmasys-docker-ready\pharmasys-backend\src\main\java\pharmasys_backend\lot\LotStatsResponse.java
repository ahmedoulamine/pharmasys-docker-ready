package pharmasys_backend.lot;

public class LotStatsResponse {
    public Long   produitId;
    public String denomination;
    public int    quantiteOk;
    public int    quantitePerimee;
    public int    nbLots;

    public LotStatsResponse(Long produitId, String denomination,
                             int quantiteOk, int quantitePerimee, int nbLots) {
        this.produitId      = produitId;
        this.denomination   = denomination;
        this.quantiteOk     = quantiteOk;
        this.quantitePerimee= quantitePerimee;
        this.nbLots         = nbLots;
    }
}
