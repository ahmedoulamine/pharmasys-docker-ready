package pharmasys_backend.produit;

import java.time.LocalDate;

public record ProduitResponse(
    Long      id,
    String    codeEan13,
    String    denomination,
    String    dci,
    String    formeDosage,
    String    presentation,
    String    ppv,
    String    baseRemboursementPpv,
    String    ph,
    String    baseRemboursementPh,
    String    classeTherapeutique,
    String    pG,
    String    remboursementTaux,
    String    pa,
    Integer   stock,
    Integer   stockMinimum,
    Integer   seuilAlerte,
    LocalDate dateExpiration
) {}
