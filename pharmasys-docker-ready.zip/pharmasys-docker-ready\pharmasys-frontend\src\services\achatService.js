import axiosInstance from "../api/axios";

export const getAllAchats = () => axiosInstance.get('/achats');

export const createAchat = (achat) => axiosInstance.post('/achats', achat);

export const confirmAchat = (id) => axiosInstance.put(`/achats/${id}/confirm`);

export const markAchatAsReceived = (id) => axiosInstance.put(`/achats/${id}/receive`);

export const markAchatAsLitige = (id) => axiosInstance.put(`/achats/${id}/litige`);

export const updateProduitExpiration = (id, dateExpiration) =>
  axiosInstance.patch(`/produits/${id}/expiration`, { dateExpiration });

export const createLot = (lot) => axiosInstance.post('/lots', lot);

export const getLotsByProduit = (produitId) => axiosInstance.get(`/lots/produit/${produitId}`);

export const getExpiredSummary = () => axiosInstance.get('/lots/expired-summary');

export const retireLot = (id) => axiosInstance.put(`/lots/${id}/retire`);
