package pharmasys_backend.achat;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface AchatRepository extends JpaRepository<Achat, Long> {
    List<Achat> findAllByOrderByDateCommandeDesc();

    @Query("SELECT COALESCE(SUM(a.montant), 0) FROM Achat a WHERE a.dateCommande >= :debut")
    Double sumMontantDepuis(@Param("debut") LocalDate debut);

    long countByDateCommandeAfter(LocalDate debut);
}
