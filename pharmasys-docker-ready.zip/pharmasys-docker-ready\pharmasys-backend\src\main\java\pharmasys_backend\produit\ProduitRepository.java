package pharmasys_backend.produit;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProduitRepository extends JpaRepository<Produit, Long> {

    @Query("""
        SELECT p FROM Produit p
        WHERE LOWER(p.denomination)        LIKE LOWER(CONCAT('%', :q, '%'))
           OR LOWER(p.dci)                 LIKE LOWER(CONCAT('%', :q, '%'))
           OR LOWER(p.classeTherapeutique) LIKE LOWER(CONCAT('%', :q, '%'))
           OR p.codeEan13                  LIKE CONCAT('%', :q, '%')
    """)
    Page<Produit> search(@Param("q") String query, Pageable pageable);

    // Dashboard & alertes
    @Query("SELECT COUNT(p) FROM Produit p WHERE p.seuilAlerte IS NOT NULL AND p.stock IS NOT NULL AND p.stock > 0 AND p.stock <= p.seuilAlerte")
    long countProduitsEnAlerte();

    @Query("SELECT COUNT(p) FROM Produit p WHERE p.stock IS NOT NULL AND p.stock > 0 AND p.stock <= 5")
    long countAlertesCritiques();

    @Query("SELECT COUNT(p) FROM Produit p WHERE p.dateExpiration IS NOT NULL AND p.dateExpiration < CURRENT_DATE")
    long countProduitsPerimes();

    @Query("SELECT p FROM Produit p WHERE p.seuilAlerte IS NOT NULL AND p.stock IS NOT NULL AND p.stock <= p.seuilAlerte ORDER BY p.stock ASC")
    List<Produit> findTop10ProduitsEnAlerte(Pageable pageable);
}
