import { BrowserRouter, Routes, Route, useNavigate, useLocation } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext'
import Login from './pages/Login'
import ResetPassword from './pages/ResetPassword'
import Dashboard from './pages/Dashboard'
import SalesPOS from './pages/SalesPOS'
import StockManagement from './pages/StockManagement'
import DefectiveProducts from './pages/DefectiveProducts'
import ProductPage from './pages/ProductPage'
import AchatsPage from './pages/AchatsPage'
import AvoirsPage from './pages/AvoirsPage'
import Rapports from './pages/Rapports'
import Patients from './pages/Patients'
import Caisse from './pages/Caisse'
import Sidebar from './components/Sidebar'
import Header from './components/Header'

function AppShell() {
  const { user, loading, apiError, refreshData } = useApp()
  const navigate  = useNavigate()
  const location  = useLocation()

  if (!user) return (
    <Routes>
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="*" element={<Login onLogin={(path) => navigate(path ?? '/')} />} />
    </Routes>
  )

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        {apiError && (
          <div className="mx-6 mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 flex items-center justify-between gap-3">
            <span>{apiError}</span>
            <button onClick={refreshData} className="font-semibold text-red-800 hover:text-red-900">
              Réessayer
            </button>
          </div>
        )}
        {loading && (
          <div className="mx-6 mt-4 rounded-xl border border-blue-100 bg-blue-50 px-4 py-3 text-sm text-blue-700">
            Chargement des données backend...
          </div>
        )}
        <main className="flex-1 overflow-auto">
          <Routes>
            <Route path="/"          element={<Dashboard key={location.key} />} />
            <Route path="/pos"       element={<SalesPOS />} />
            <Route path="/stock"     element={<StockManagement />} />
            <Route path="/defective" element={<DefectiveProducts />} />
            <Route path="/produits"  element={<ProductPage />} />
            <Route path="/achats"    element={<AchatsPage />} />
            <Route path="/retours"   element={<AvoirsPage />} />
            <Route path="/rapports"  element={<Rapports />} />
            <Route path="/patients"  element={<Patients />} />
            <Route path="/caisse"    element={<Caisse />} />
          </Routes>
        </main>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <AppShell />
      </AppProvider>
    </BrowserRouter>
  )
}
