# PharmaSys - Docker ready

Cette version lance toute l'application avec Docker:

- Frontend React + Nginx: http://localhost:8088
- Backend Spring Boot: interne au reseau Docker
- PostgreSQL avec import automatique de `init.sql`
- Mailpit pour remplacer la configuration SMTP manquante: http://localhost:8025

## Lancement

Depuis ce dossier:

```powershell
docker compose up --build
```

Puis ouvrir:

```text
http://localhost:8088
```

Identifiants de test:

```text
login: admin
mot de passe: admin
```

Autres comptes presents dans `init.sql`:

```text
ahmed / admin
khadija / admin
```

## Repartir avec une base propre

Si le login ne marche pas a cause d'une ancienne base Docker locale:

```powershell
docker compose down -v
docker compose up --build
```

`down -v` supprime les donnees PostgreSQL locales et force la reimportation de `init.sql`.

## Verification rapide

Voir si les conteneurs tournent:

```powershell
docker compose ps
```

Tester le login via le frontend/Nginx:

```powershell
Invoke-RestMethod -Uri http://localhost:8088/api/auth/login -Method Post -ContentType "application/json" -Body '{"login":"admin","motDePasse":"admin"}'
```

Voir les emails de reinitialisation:

```text
http://localhost:8025
```
