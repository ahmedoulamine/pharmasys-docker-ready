package pharmasys_backend.auth;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import pharmasys_backend.utilisateur.Utilisateur;
import pharmasys_backend.utilisateur.UtilisateurRepository;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
@RequiredArgsConstructor
public class PasswordResetService {

    private final UtilisateurRepository utilisateurRepository;
    private final JavaMailSender mailSender;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Value("${app.frontend.url}")
    private String frontendUrl;

    @Value("${spring.mail.username}")
    private String fromEmail;

    // token -> { email, expiry }
    private final Map<String, TokenEntry> tokens = new ConcurrentHashMap<>();

    public boolean sendResetEmail(String email) {
        Optional<Utilisateur> opt = utilisateurRepository.findByEmail(email);
        if (opt.isEmpty()) {
            // On retourne true pour ne pas révéler si l'email existe
            return true;
        }

        String token = UUID.randomUUID().toString();
        tokens.put(token, new TokenEntry(email, LocalDateTime.now().plusMinutes(30)));

        String resetLink = frontendUrl + "/reset-password?token=" + token;

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromEmail);
        message.setTo(email);
        message.setSubject("Réinitialisation de votre mot de passe — PharmaSys");
        message.setText(
            "Bonjour,\n\n" +
            "Vous avez demandé la réinitialisation de votre mot de passe.\n\n" +
            "Cliquez sur ce lien (valable 30 minutes) :\n" +
            resetLink + "\n\n" +
            "Si vous n'avez pas fait cette demande, ignorez cet email.\n\n" +
            "— L'équipe PharmaSys"
        );
        mailSender.send(message);
        return true;
    }

    public boolean resetPassword(String token, String newPassword) {
        TokenEntry entry = tokens.get(token);
        if (entry == null || entry.expiry().isBefore(LocalDateTime.now())) {
            tokens.remove(token);
            return false;
        }

        Optional<Utilisateur> opt = utilisateurRepository.findByEmail(entry.email());
        if (opt.isEmpty()) return false;

        Utilisateur user = opt.get();
        user.setMotDePasse(passwordEncoder.encode(newPassword));
        utilisateurRepository.save(user);
        tokens.remove(token);
        return true;
    }

    private record TokenEntry(String email, LocalDateTime expiry) {}
}
