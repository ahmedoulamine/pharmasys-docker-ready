import { useEffect, useState } from "react";
import "./ProductPage.css";
import {
  getAllProducts,
  createProduct,
  deleteProduct,
  updateProduct,
} from "../services/productService";
import { Pencil, Trash2 } from "lucide-react";

function ProductPage() {
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [products, setProducts] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [editingProduct, setEditingProduct] = useState(null);
  const [currentDateTime, setCurrentDateTime] = useState(new Date());

  const [newProduct, setNewProduct] = useState({
    name: "",
    therapeuticClass: "",
    barcode: "",
    dosage: "",
    composition: "",
    priceHt: "",
    price: "",
  });

  const loadProducts = async () => {
    try {
      const response = await getAllProducts(page, 20, search);
      setProducts(response.data.content);
      setTotalPages(response.data.totalPages);
    } catch (error) {
      console.error("Erreur chargement produits :", error);
    }
  };

  useEffect(() => {
    loadProducts();
  }, [page, search]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleEditClick = (product) => {
    setEditingProduct(product);
    setNewProduct({
      name: product.name || "",
      therapeuticClass: product.therapeuticClass || "",
      barcode: product.barcode || "",
      dosage: product.dosage || "",
      composition: product.composition || "",
      priceHt: product.priceHt || "",
      price: product.price || "",
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    try {
      await deleteProduct(id);
      loadProducts();
    } catch (error) {
      console.error("Erreur suppression produit :", error);
    }
  };

  const handleChange = (e) => {
    setNewProduct({ ...newProduct, [e.target.name]: e.target.value });
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    const productToAdd = {
      name: newProduct.name,
      therapeuticClass: newProduct.therapeuticClass,
      barcode: newProduct.barcode,
      dosage: newProduct.dosage,
      composition: newProduct.composition,
      priceHt: Number(newProduct.priceHt),
      price: Number(newProduct.price),
    };
    try {
      if (editingProduct) {
        await updateProduct(editingProduct.id, productToAdd);
      } else {
        await createProduct(productToAdd);
      }
      setNewProduct({ name: "", therapeuticClass: "", barcode: "", dosage: "", composition: "", priceHt: "", price: "" });
      setEditingProduct(null);
      setShowModal(false);
      loadProducts();
    } catch (error) {
      console.error("Erreur sauvegarde produit :", error);
    }
  };

  const formattedDate = currentDateTime.toLocaleDateString("fr-FR", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });
  const formattedTime = currentDateTime.toLocaleTimeString("fr-FR");

  return (
    <main className="products-main">
      <header className="products-header">
        <div>
          <h1>Produits</h1>
          <p>{formattedDate} | {formattedTime}</p>
        </div>
      </header>

      <section className="products-toolbar">
        <input
          type="text"
          placeholder="Rechercher un produit..."
          className="search-input"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0); }}
        />
        <button className="filter-btn">Filtres</button>
        <button className="add-btn" onClick={() => { setEditingProduct(null); setNewProduct({ name: "", therapeuticClass: "", barcode: "", dosage: "", composition: "", priceHt: "", price: "" }); setShowModal(true); }}>
          + Ajouter un produit
        </button>
      </section>

      <section className="products-table-card">
        <table className="products-table">
          <thead>
            <tr>
              <th>Produit</th>
              <th>Classe thérapeutique</th>
              <th>Code-barres</th>
              <th>Dosage</th>
              <th>Composition</th>
              <th>Prix HT</th>
              <th>Prix de vente</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id}>
                <td className="product-name">{product.name}</td>
                <td>{product.therapeuticClass}</td>
                <td>{product.barcode}</td>
                <td>{product.dosage}</td>
                <td>{product.composition}</td>
                <td>{product.priceHt ?? "-"} DH</td>
                <td>{product.price ?? "-"} DH</td>
                <td>
                  <button className="action-btn edit-btn" onClick={() => handleEditClick(product)}>
                    <Pencil size={18} />
                  </button>
                  <button className="action-btn delete-btn" onClick={() => handleDelete(product.id)}>
                    <Trash2 size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <div className="pagination">
        <button disabled={page === 0} onClick={() => setPage(page - 1)}>Précédent</button>
        <span>Page {page + 1} / {totalPages || 1}</span>
        <button disabled={page + 1 >= totalPages} onClick={() => setPage(page + 1)}>Suivant</button>
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>{editingProduct ? "Modifier le produit" : "Ajouter un produit"}</h2>
            <form onSubmit={handleAddProduct} className="modal-form">
              <input type="text"   name="name"             placeholder="Nom du produit"          value={newProduct.name}             onChange={handleChange} />
              <input type="text"   name="therapeuticClass" placeholder="Classe thérapeutique"    value={newProduct.therapeuticClass} onChange={handleChange} />
              <input type="text"   name="barcode"          placeholder="Code-barres"             value={newProduct.barcode}          onChange={handleChange} />
              <input type="text"   name="dosage"           placeholder="Dosage"                  value={newProduct.dosage}           onChange={handleChange} />
              <input type="text"   name="composition"      placeholder="Composition"             value={newProduct.composition}      onChange={handleChange} />
              <input type="number" name="priceHt"          placeholder="Prix HT"                 value={newProduct.priceHt}          onChange={handleChange} />
              <input type="number" name="price"            placeholder="Prix de vente"           value={newProduct.price}            onChange={handleChange} />
              <div className="modal-actions">
                <button type="button" className="cancel-btn" onClick={() => { setShowModal(false); setEditingProduct(null); }}>
                  Annuler
                </button>
                <button type="submit" className="save-btn">
                  {editingProduct ? "Modifier" : "Enregistrer"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
}

export default ProductPage;
