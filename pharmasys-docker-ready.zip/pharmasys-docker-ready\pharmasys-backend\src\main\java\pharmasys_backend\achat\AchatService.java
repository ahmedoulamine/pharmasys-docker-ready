package pharmasys_backend.achat;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AchatService {

    private final AchatRepository achatRepository;

    public List<Achat> getAll() {
        return achatRepository.findAllByOrderByDateCommandeDesc();
    }

    @Transactional
    public Achat create(Achat achat) {
        if (achat.getStatut() == null) achat.setStatut(StatutAchat.EN_ATTENTE);

        if (achat.getDateCommande() == null) achat.setDateCommande(LocalDate.now());

        if (achat.getNumeroBC() == null || achat.getNumeroBC().isBlank()) {
            long seq = achatRepository.count() + 1;
            achat.setNumeroBC(String.format("BC-%d-%03d", LocalDate.now().getYear(), seq));
        }

        if (achat.getLignes() != null && !achat.getLignes().isEmpty()) {
            achat.getLignes().forEach(l -> l.setAchat(achat));
            double ht = achat.getLignes().stream()
                    .mapToDouble(l -> (l.getQuantite() != null ? l.getQuantite() : 0)
                                   * (l.getPrixUnitaire() != null ? l.getPrixUnitaire() : 0))
                    .sum();
            achat.setTotalHt(ht);
            achat.setTotalTtc(Math.round(ht * 1.1 * 100.0) / 100.0);
            achat.setMontant(ht);
            achat.setArticlesCount(achat.getLignes().size());
        }

        return achatRepository.save(achat);
    }

    @Transactional
    public Achat confirm(Long id) {
        Achat achat = achatRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Achat non trouvé: " + id));
        if (achat.getStatut() == StatutAchat.BROUILLON) {
            achat.setStatut(StatutAchat.EN_ATTENTE);
        } else if (achat.getStatut() == StatutAchat.EN_ATTENTE) {
            achat.setStatut(StatutAchat.CONFIRME);
        }
        return achatRepository.save(achat);
    }

    @Transactional
    public Achat receive(Long id) {
        Achat achat = achatRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Achat non trouvé: " + id));
        achat.setStatut(StatutAchat.RECU);
        return achatRepository.save(achat);
    }

    @Transactional
    public Achat litige(Long id) {
        Achat achat = achatRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Achat non trouvé: " + id));
        achat.setStatut(StatutAchat.LITIGE);
        return achatRepository.save(achat);
    }
}
