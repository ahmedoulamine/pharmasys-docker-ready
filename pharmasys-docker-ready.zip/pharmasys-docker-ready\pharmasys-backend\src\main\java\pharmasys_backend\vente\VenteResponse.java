package pharmasys_backend.vente;

import java.math.BigDecimal;
import java.util.List;

public record VenteResponse(
    Long   id,
    String numeroVente,
    String dateVente,
    BigDecimal totalHt,
    BigDecimal totalTva,
    BigDecimal totalTtc,
    BigDecimal montantRecu,
    BigDecimal renduMonnaie,
    String modePaiement,
    String statut,
    String patientNom,
    String caissier,
    String tpeReference,
    String tpeAutorisation,
    String tpeCarte,
    List<LigneResponse> lignes
) {
    public record LigneResponse(
        Long       id,
        Long       produitId,
        String     nom,
        Integer    quantite,
        BigDecimal prixUnitaire,
        BigDecimal sousTotal
    ) {}
}
