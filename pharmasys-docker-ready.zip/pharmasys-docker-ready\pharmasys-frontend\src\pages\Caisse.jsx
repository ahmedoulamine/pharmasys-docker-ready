import { useState, useEffect, useCallback } from "react";
import axiosInstance from "../api/axios.js";

export default function Caisse() {
    const [sessionActive, setSessionActive] = useState(null);
    const [historique, setHistorique]       = useState([]);
    const [fondInitial, setFondInitial]     = useState(200);
    const [fondCloture, setFondCloture]     = useState("");
    const [loading, setLoading]             = useState(true);
    const [saving, setSaving]               = useState(false);
    const [error, setError]                 = useState(null);
    const [successMsg, setSuccessMsg]       = useState(null);
    const [timer, setTimer]                 = useState("00:00:00");

    const role        = localStorage.getItem("role") || "TITULAIRE";
    const estTitulaire = role === "TITULAIRE";

    const formatDH = (m) => `${Number(m || 0).toFixed(2)} DH`;

    const loadData = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const [a, h] = await Promise.all([
                axiosInstance.get("/caisse/active"),
                axiosInstance.get("/caisse/historique"),
            ]);
            setSessionActive(a.data || null);
            setHistorique(h.data || []);
        } catch (e) {
            console.error("Erreur caisse:", e);
            setError("Impossible de charger les données de caisse.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { loadData(); }, [loadData]);

    useEffect(() => {
        let interval = null;
        if (sessionActive?.heureOuverture) {
            interval = setInterval(() => {
                const now = new Date();
                const [h, m] = sessionActive.heureOuverture.split(":").map(Number);
                const debut = new Date();
                debut.setHours(h, m, 0, 0);
                const diff = Math.max(0, Math.floor((now - debut) / 1000));
                const hh = String(Math.floor(diff / 3600)).padStart(2, "0");
                const mm = String(Math.floor((diff % 3600) / 60)).padStart(2, "0");
                const ss = String(diff % 60).padStart(2, "0");
                setTimer(`${hh}:${mm}:${ss}`);
            }, 1000);
        }
        return () => clearInterval(interval);
    }, [sessionActive]);

    const showSuccess = (msg) => { setSuccessMsg(msg); setTimeout(() => setSuccessMsg(null), 3500); };

    const ouvrir = async () => {
        if (!fondInitial || Number(fondInitial) < 0) { setError("Le fond de caisse doit être un montant positif."); return; }
        setSaving(true); setError(null);
        try {
            const res = await axiosInstance.post("/caisse/ouvrir", { fondInitial: Number(fondInitial) });
            setSessionActive(res.data);
            showSuccess("Caisse ouverte avec succès !");
            loadData();
        } catch (e) {
            setError(e.response?.data?.message || "Erreur lors de l'ouverture.");
        } finally { setSaving(false); }
    };

    const fermer = async () => {
        if (fondCloture === "" || fondCloture === null) { setError("Veuillez saisir le fond de clôture."); return; }
        if (!window.confirm(`Confirmer la clôture avec ${formatDH(fondCloture)} ?`)) return;
        setSaving(true); setError(null);
        try {
            await axiosInstance.put(`/caisse/${sessionActive.id}/fermer`, { fondCloture: Number(fondCloture) });
            showSuccess("Opération effectuée avec succès !");
            setSessionActive(null); setFondCloture(""); loadData();
        } catch (e) {
            setError(e.response?.data?.message || "Erreur lors de la clôture.");
        } finally { setSaving(false); }
    };

    const ecart = (s) => {
        if (s.fondCloture == null || s.fondOuverture == null || s.totalVentes == null) return null;
        return s.fondCloture - (s.fondOuverture + s.totalVentes);
    };

    const EcartBadge = ({ session }) => {
        const e = ecart(session);
        if (e === null) return <span style={{ color: "#9ca3af" }}>—</span>;
        if (Math.abs(e) < 0.01) return <span style={{ background: "#d1fae5", color: "#065f46", padding: "4px 12px", borderRadius: 20, fontSize: 12, fontWeight: 600 }}>✓ OK</span>;
        const positif = e > 0;
        return <span style={{ color: positif ? "#10b981" : "#ef4444", fontWeight: 600, fontSize: 13, display: "flex", alignItems: "center", gap: 4 }}>{positif ? "↗ +" : "↘ "}{e.toFixed(2)} DH</span>;
    };

    const cardStyle = { background: "#fff", borderRadius: 12, padding: "24px 28px", border: "1px solid #f0f0f0", boxShadow: "0 1px 4px rgba(0,0,0,0.05)" };

    const sessionsFermees   = historique.filter((s) => s.statut === "FERMEE" || s.fondCloture !== null).length;
    const totalVentesGlobal = historique.reduce((s, x) => s + (x.totalVentes || 0), 0);

    if (loading) return (
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "60vh", fontFamily: "system-ui" }}>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: 32, marginBottom: 12 }}>⏳</div><div style={{ color: "#6b7280", fontSize: 15 }}>Chargement de la caisse...</div></div>
        </div>
    );

    return (
        <div style={{ padding: "28px 32px", fontFamily: "system-ui, sans-serif", minHeight: "100vh", backgroundColor: "#fbfbfb" }}>
            <div style={{ marginBottom: 28 }}>
                <h1 style={{ fontSize: 24, fontWeight: 700, margin: 0, color: "#111" }}>Gestion de la Caisse</h1>
                <p style={{ color: "#6b7280", margin: "6px 0 0", fontSize: 14 }}>Mode {estTitulaire ? "Titulaire" : "Employé"} — Suivi des flux financiers</p>
            </div>

            {successMsg && <div style={{ background: "#f0fdf4", border: "1px solid #86efac", borderRadius: 10, padding: "12px 16px", marginBottom: 20, color: "#166534", fontSize: 14 }}>✅ {successMsg}</div>}
            {error && (
                <div style={{ background: "#fee2e2", border: "1px solid #fca5a5", borderRadius: 10, padding: "12px 16px", marginBottom: 20, color: "#dc2626", fontSize: 14 }}>
                    ⚠️ {error}
                    <button onClick={() => setError(null)} style={{ float: "right", background: "none", border: "none", cursor: "pointer", color: "#dc2626" }}>✕</button>
                </div>
            )}

            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 24 }}>
                <div style={cardStyle}><div style={{ color: "#6b7280", fontSize: 13, marginBottom: 8 }}>📅 Sessions enregistrées</div><div style={{ fontSize: 28, fontWeight: 700, color: "#111" }}>{sessionsFermees}</div></div>
                <div style={{ ...cardStyle, background: "#f0fdf4", border: "1px solid #86efac" }}><div style={{ color: "#166534", fontSize: 13, marginBottom: 8 }}>💰 CA Total (Historique)</div><div style={{ fontSize: 28, fontWeight: 700, color: "#166534" }}>{formatDH(totalVentesGlobal)}</div></div>
                <div style={{ ...cardStyle, border: `1px solid ${sessionActive ? "#86efac" : "#e5e7eb"}` }}>
                    <div style={{ color: "#6b7280", fontSize: 13, marginBottom: 8 }}>🔴 État actuel</div>
                    <div style={{ fontSize: 18, fontWeight: 700, color: sessionActive ? "#10b981" : "#6b7280", display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ width: 10, height: 10, borderRadius: "50%", background: sessionActive ? "#10b981" : "#d1d5db" }} />
                        {sessionActive ? "Ouverte" : "Fermée"}
                    </div>
                    {sessionActive && <div style={{ fontSize: 13, color: "#10b981", marginTop: 4 }}>⏱ {timer}</div>}
                </div>
            </div>

            <div style={{ ...cardStyle, marginBottom: 24 }}>
                {sessionActive ? (
                    <>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 24 }}>
                            <div>
                                <h2 style={{ margin: "0 0 4px", fontSize: 17, fontWeight: 700 }}>Session active</h2>
                                <p style={{ margin: 0, color: "#6b7280", fontSize: 14 }}>Depuis {sessionActive.heureOuverture} le {sessionActive.dateSession}</p>
                            </div>
                            <div style={{ textAlign: "right" }}>
                                <div style={{ fontSize: 12, color: "#9ca3af" }}>Fond initial</div>
                                <div style={{ fontSize: 18, fontWeight: 700 }}>{formatDH(sessionActive.fondOuverture)}</div>
                            </div>
                        </div>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12, marginBottom: 24 }}>
                            <div style={{ background: "#f9fafb", borderRadius: 8, padding: "16px", border: "1px solid #eee" }}>
                                <div style={{ fontSize: 12, color: "#6b7280" }}>Ventes cumulées</div>
                                <div style={{ fontSize: 20, fontWeight: 700, color: "#10b981" }}>{formatDH(sessionActive.totalVentes)}</div>
                            </div>
                            <div style={{ background: "#f9fafb", borderRadius: 8, padding: "16px", border: "1px solid #eee" }}>
                                <div style={{ fontSize: 12, color: "#6b7280" }}>Solde attendu</div>
                                <div style={{ fontSize: 20, fontWeight: 700, color: "#3b82f6" }}>{formatDH(Number(sessionActive.fondOuverture) + Number(sessionActive.totalVentes))}</div>
                            </div>
                        </div>
                        <div style={{ borderTop: "1px solid #eee", paddingTop: 20 }}>
                            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>Procéder à la clôture</h3>
                            <div style={{ display: "flex", gap: 12, alignItems: "flex-end" }}>
                                <div style={{ flex: 1 }}>
                                    <input type="number" value={fondCloture} onChange={(e) => setFondCloture(e.target.value)}
                                        placeholder="Montant réel compté..."
                                        style={{ width: "100%", padding: "12px", borderRadius: 8, border: "1px solid #ddd", outline: "none" }} />
                                </div>
                                <button onClick={fermer} disabled={saving || !fondCloture}
                                    style={{ background: "#ef4444", color: "#fff", border: "none", borderRadius: 8, padding: "12px 24px", cursor: "pointer", fontWeight: 700, opacity: (saving || !fondCloture) ? 0.6 : 1 }}>
                                    {saving ? "Clôture..." : "🔒 Clôturer"}
                                </button>
                            </div>
                        </div>
                    </>
                ) : (
                    estTitulaire ? (
                        <div style={{ maxWidth: 400 }}>
                            <h2 style={{ fontSize: 17, fontWeight: 700, marginBottom: 16 }}>Nouvelle session de caisse</h2>
                            <label style={{ fontSize: 13, fontWeight: 600, display: "block", marginBottom: 8 }}>Fond de départ (DH)</label>
                            <input type="number" value={fondInitial} onChange={(e) => setFondInitial(e.target.value)}
                                style={{ width: "100%", padding: "12px", borderRadius: 8, border: "1px solid #ddd", marginBottom: 16, fontSize: 16 }} />
                            <button onClick={ouvrir} disabled={saving}
                                style={{ width: "100%", background: "#10b981", color: "#fff", border: "none", borderRadius: 8, padding: "12px", fontWeight: 700, cursor: "pointer" }}>
                                {saving ? "Ouverture..." : "🔓 Ouvrir la caisse"}
                            </button>
                        </div>
                    ) : (
                        <div style={{ textAlign: "center", padding: "20px" }}>
                            <div style={{ fontSize: 32, marginBottom: 10 }}>🔒</div>
                            <p style={{ margin: 0, fontWeight: 600, color: "#374151" }}>La caisse est actuellement fermée.</p>
                            <p style={{ fontSize: 13, color: "#9ca3af" }}>Veuillez attendre l'ouverture par un titulaire.</p>
                        </div>
                    )
                )}
            </div>

            <div style={{ ...cardStyle, padding: 0, overflow: "hidden" }}>
                <div style={{ padding: "18px 24px", borderBottom: "1px solid #eee", background: "#fafafa" }}>
                    <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>Historique des 30 derniers jours</h3>
                </div>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                    <tr style={{ textAlign: "left", background: "#fdfdfd", borderBottom: "1px solid #eee" }}>
                        {["Date", "Heures", "Ouverture", "Ventes", "Clôture", "Écart"].map(h => (
                            <th key={h} style={{ padding: "14px 20px", fontSize: 12, color: "#9ca3af", textTransform: "uppercase" }}>{h}</th>
                        ))}
                    </tr>
                    </thead>
                    <tbody>
                    {historique.map((s, i) => (
                        <tr key={s.id || i} style={{ borderBottom: "1px solid #f9f9f9" }}>
                            <td style={{ padding: "14px 20px", fontWeight: 600, fontSize: 14 }}>{s.dateSession}</td>
                            <td style={{ padding: "14px 20px", color: "#6b7280", fontSize: 13 }}>{s.heureOuverture} - {s.heureCloture || "..."}</td>
                            <td style={{ padding: "14px 20px", fontSize: 14 }}>{formatDH(s.fondOuverture)}</td>
                            <td style={{ padding: "14px 20px", fontSize: 14, color: "#10b981", fontWeight: 600 }}>{formatDH(s.totalVentes)}</td>
                            <td style={{ padding: "14px 20px", fontSize: 14 }}>{s.fondCloture != null ? formatDH(s.fondCloture) : "---"}</td>
                            <td style={{ padding: "14px 20px" }}><EcartBadge session={s} /></td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
