package pharmasys_backend.common;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FrontendController {

    @RequestMapping(value = {
        "/", "/pos", "/stock", "/defective",
        "/produits", "/achats", "/retours",
        "/rapports", "/patients", "/caisse", "/login"
    })
    public String forward() {
        return "forward:/index.html";
    }
}
