import { useState, useEffect, useCallback, useRef } from 'react'
import { useApp } from '../context/AppContext'
import { fetchInventaire, updateStock } from '../services/api'
import { getAllAchats, markAchatAsReceived, markAchatAsLitige, updateProduitExpiration, createLot, getExpiredSummary, getLotsByProduit, retireLot } from '../services/achatService'
import {
  Package, AlertTriangle, Calendar, Truck,
  FileText, Eye, Plus, Search, ChevronLeft, ChevronRight,
  Pencil, X, ArrowUp, ArrowDown, RefreshCw, Building2,
} from 'lucide-react'

function getStatus(product, expiredLots = 0) {
  // Périmé = uniquement si des lots périmés sont encore EN_STOCK
  if (expiredLots > 0) return 'Périmé'

  const today = new Date()
  let daysLeft = null
  if (product.dateExpiration) {
    const expiry = new Date(product.dateExpiration)
    daysLeft = Math.ceil((expiry - today) / 86400000)
  }
  if (product.stock === 0)                                             return 'Rupture'
  if (product.stock <= Math.floor(product.seuilAlerte / 2))           return 'Stock critique'
  // Expire bientôt = date future dans les 90 jours (pas les dates passées sans lots)
  if (daysLeft !== null && daysLeft > 0 && daysLeft <= 90)            return 'Expire bientôt'
  if (product.seuilAlerte > 0 && product.stock <= product.seuilAlerte) return 'Stock faible'
  return 'OK'
}

const STATUS_STYLES = {
  'OK':             { badge: 'text-green-700 bg-green-100',   border: '',                               dateClass: 'text-gray-500' },
  'Stock faible':   { badge: 'text-amber-700 bg-amber-100',   border: 'border-l-4 border-l-amber-400',  dateClass: 'text-gray-500' },
  'Stock critique': { badge: 'text-orange-700 bg-orange-100', border: 'border-l-4 border-l-orange-500', dateClass: 'text-gray-500' },
  'Rupture':        { badge: 'text-red-700 bg-red-100',       border: 'border-l-4 border-l-red-500',    dateClass: 'text-gray-500' },
  'Expire bientôt': { badge: 'text-blue-700 bg-blue-100',     border: 'border-l-4 border-l-blue-400',   dateClass: 'text-blue-600' },
  'Périmé':         { badge: 'text-red-700 bg-red-100',       border: 'border-l-4 border-l-red-600',    dateClass: 'text-red-600 font-semibold' },
}

const BL_STATUS_STYLES = {
  'Livrée':     'text-green-700 bg-green-100',
  'En cours':   'text-blue-700 bg-blue-100',
  'En attente': 'text-orange-700 bg-orange-100',
}

function StockModal({ product, onClose, onSaved }) {
  const [mode, setMode]         = useState('ADD')
  const [quantite, setQuantite] = useState('')
  const [saving, setSaving]     = useState(false)
  const [error, setError]       = useState('')

  async function handleSave() {
    const qty = parseInt(quantite)
    if (!qty || qty <= 0) { setError('Quantité invalide'); return }
    setSaving(true)
    setError('')
    try {
      const updated = await updateStock(product.id, qty, mode)
      onSaved(updated)
      onClose()
    } catch (e) {
      setError(e.message || 'Erreur lors de la mise à jour')
    } finally {
      setSaving(false)
    }
  }

  const newStock = (() => {
    const qty = parseInt(quantite) || 0
    if (mode === 'ADD')    return product.stock + qty
    if (mode === 'REMOVE') return Math.max(0, product.stock - qty)
    if (mode === 'SET')    return qty
    return product.stock
  })()

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div>
            <h2 className="font-semibold text-gray-800">Modifier le stock</h2>
            <p className="text-xs text-gray-400 mt-0.5 truncate max-w-[280px]">{product.nom}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Stock actuel */}
          <div className="flex items-center justify-between bg-gray-50 rounded-xl px-4 py-3">
            <span className="text-sm text-gray-500">Stock actuel</span>
            <span className="text-2xl font-bold text-gray-800">{product.stock}</span>
          </div>

          {/* Mode */}
          <div>
            <p className="text-sm text-gray-500 mb-2">Opération</p>
            <div className="grid grid-cols-3 gap-2">
              {[
                { key: 'ADD',    icon: ArrowUp,    label: 'Ajouter',   color: 'green' },
                { key: 'REMOVE', icon: ArrowDown,  label: 'Retirer',   color: 'red'   },
                { key: 'SET',    icon: RefreshCw,  label: 'Définir',   color: 'blue'  },
              ].map(({ key, icon: Icon, label, color }) => (
                <button key={key} onClick={() => setMode(key)}
                  className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border text-xs font-medium transition-all ${
                    mode === key
                      ? `bg-${color}-600 border-${color}-600 text-white`
                      : 'border-gray-200 text-gray-600 hover:border-gray-300'
                  }`}>
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Quantité */}
          <div>
            <p className="text-sm text-gray-500 mb-2">
              {mode === 'SET' ? 'Nouveau stock' : 'Quantité'}
            </p>
            <input
              type="number"
              min="1"
              value={quantite}
              onChange={e => setQuantite(e.target.value)}
              placeholder="0"
              className="w-full px-4 py-3 border border-gray-200 rounded-xl text-lg font-bold text-center focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
              autoFocus
            />
          </div>

          {/* Aperçu */}
          {quantite && (
            <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-xl px-4 py-3">
              <span className="text-sm text-green-700">Nouveau stock</span>
              <span className={`text-2xl font-bold ${newStock <= (product.seuilAlerte ?? 0) ? 'text-red-600' : 'text-green-700'}`}>
                {newStock}
              </span>
            </div>
          )}

          {error && (
            <p className="text-sm text-red-600 bg-red-50 px-4 py-2 rounded-xl">{error}</p>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <button onClick={onClose}
              className="flex-1 py-3 border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">
              Annuler
            </button>
            <button onClick={handleSave} disabled={!quantite || saving}
              className="flex-1 py-3 bg-green-600 hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl text-sm font-semibold transition-colors">
              {saving ? 'Enregistrement...' : 'Enregistrer'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function StockManagement() {
  const { totalProducts, refreshData } = useApp()
  const [tab, setTab]           = useState('inventaire')
  const [search, setSearch]     = useState('')
  const [products, setProducts] = useState([])
  const [total, setTotal]       = useState(0)
  const [totalPages, setTotalPages] = useState(1)
  const [page, setPage]         = useState(0)
  const [loading, setLoading]   = useState(false)
  const [editProduct, setEditProduct] = useState(null)
  const [bonsLivraison, setBonsLivraison]   = useState([])
  const [showNewBL, setShowNewBL]           = useState(false)
  const [allAchats, setAllAchats]           = useState([])
  const [expandedBCId, setExpandedBCId]     = useState(null)
  const [litigeId, setLitigeId]             = useState(null)
  const [selectedBL, setSelectedBL]         = useState(null)
  const [blLotsMap, setBlLotsMap]           = useState({}) // { produitId: datePeremption }
  // Saisie dates d'expiration à la réception
  const [pendingReceive, setPendingReceive]  = useState(null) // { id, lignes[], numeroBL, fournisseur }
  const [expDates, setExpDates]             = useState({})   // { produitId: 'YYYY-MM-DD' }
  const [lotNums, setLotNums]              = useState({})   // { produitId: 'LOT-xxx' }
  const [savingExp, setSavingExp]           = useState(false)
  // Résumé des lots périmés par produit  { produitId: quantitePerimee }
  const [expiredByProduit, setExpiredByProduit] = useState({})
  // Modal de gestion des lots périmés d'un produit
  const [lotsModal, setLotsModal] = useState(null)   // { produit, lots[] }
  const [lotsModalLoading, setLotsModalLoading] = useState(false)
  const [retiringLotId, setRetiringLotId] = useState(null)
  const [receivingId, setReceivingId]       = useState(null)
  // Édition inline de la date d'expiration
  const [editingExpId, setEditingExpId]     = useState(null)
  const [editingExpVal, setEditingExpVal]   = useState('')
  const [savingExpId, setSavingExpId]       = useState(null)
  const debounceRef = useRef(null)

  const loadProducts = useCallback(async (q, p) => {
    setLoading(true)
    try {
      const res = await fetchInventaire(q, p, 100)
      setProducts(res.products)
      setTotal(res.total)
      setTotalPages(res.totalPages)
      setPage(res.page)
    } catch {
      setProducts([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadProducts('', 0) }, [loadProducts])

  const STATUT_BL = {
    'Reçue':      { label: 'Livrée',    css: 'text-green-700 bg-green-100'  },
    'Confirmée':  { label: 'En attente',css: 'text-orange-700 bg-orange-100'},
    'En attente': { label: 'En cours',  css: 'text-blue-700 bg-blue-100'    },
    'Litige':     { label: 'Litige',    css: 'text-red-700 bg-red-100'      },
  }

  const loadBL = () => {
    getAllAchats()
      .then(res => {
        const tous = (res.data ?? []).filter(a => !['Brouillon', 'Annulé'].includes(a.statut))
        setAllAchats(tous)
        setBonsLivraison(tous.map(a => ({
          _id:          a.id,
          id:           a.numeroBC ?? a.reference ?? `BC-${a.id}`,
          fournisseur:  a.fournisseur ?? '—',
          date:         a.datePrevue ?? a.dateCommande ?? '',
          dateCommande: a.dateCommande ?? '',
          articles:     a.articlesCount ?? a.lignes?.length ?? 0,
          totalHT:      a.totalHt ?? a.montant ?? 0,
          totalTTC:     a.totalTtc ?? (a.totalHt ?? a.montant ?? 0) * 1.1,
          statut:       a.statut,
          lignes:       a.lignes ?? [],
        })))
      })
      .catch(() => setBonsLivraison([]))
  }

  useEffect(() => {
    if (tab !== 'bons') return
    loadBL()
  }, [tab])

  const openBLDetail = async (bl) => {
    setSelectedBL(bl)
    setBlLotsMap({})
    const lignes = bl.lignes?.filter(l => l.produitId) ?? []
    if (lignes.length === 0) return
    try {
      const results = await Promise.all(lignes.map(l => getLotsByProduit(l.produitId).catch(() => ({ data: [] }))))
      const map = {}
      lignes.forEach((l, i) => {
        const lots = results[i].data ?? []
        const lot = lots.find(lo => lo.numeroBonLivraison === bl.id)
        if (lot?.datePeremption) map[l.produitId] = lot.datePeremption
      })
      setBlLotsMap(map)
    } catch { /* silently ignore */ }
  }

  const saveExpiration = async (produitId) => {
    setSavingExpId(produitId)
    try {
      await updateProduitExpiration(produitId, editingExpVal)
      setProducts(prev => prev.map(p => p.id === produitId ? { ...p, dateExpiration: editingExpVal || null } : p))
      await loadExpiredSummary()
      refreshData()
    } catch (err) { console.error('Erreur date expiration :', err) }
    finally { setSavingExpId(null); setEditingExpId(null); setEditingExpVal('') }
  }

  const loadExpiredSummary = async () => {
    try {
      const res = await getExpiredSummary()
      const map = {}
      ;(res.data ?? []).forEach(s => { map[s.produitId] = s.quantitePerimee })
      setExpiredByProduit(map)
    } catch { setExpiredByProduit({}) }
  }

  useEffect(() => { loadExpiredSummary() }, [])

  const openLotsModal = async (produit) => {
    setLotsModalLoading(true)
    setLotsModal({ produit, lots: [] })
    try {
      const res = await getLotsByProduit(produit.id)
      const expiredLots = (res.data ?? []).filter(l => l.perime && l.statut === 'EN_STOCK')
      setLotsModal({ produit, lots: expiredLots })
    } catch { setLotsModal(null) }
    finally { setLotsModalLoading(false) }
  }

  const doRetireLot = async (lotId) => {
    setRetiringLotId(lotId)
    try {
      await retireLot(lotId)
      // Rafraîchir les lots dans le modal
      if (lotsModal) {
        const produitId = lotsModal.produit.id
        const res = await getLotsByProduit(produitId)
        const expiredLots = (res.data ?? []).filter(l => l.perime && l.statut === 'EN_STOCK')
        setLotsModal(prev => ({ ...prev, lots: expiredLots }))
        // Si plus aucun lot périmé EN_STOCK → effacer la dateExpiration du produit
        if (expiredLots.length === 0) {
          await updateProduitExpiration(produitId, '')
        }
      }
      await loadExpiredSummary()
      refreshData()
    } catch (err) { console.error('Erreur retrait lot :', err) }
    finally { setRetiringLotId(null) }
  }

  // Ouvre le modal de saisie des dates avant de réceptionner
  const openDateModal = (bl) => {
    const lignes = bl.lignes?.filter(l => l.produitId) ?? []
    setPendingReceive({ id: bl._id, lignes, numeroBL: bl.id ?? bl._id, fournisseur: bl.fournisseur ?? '' })
    const initDates = {}; const initLots = {}
    lignes.forEach(l => { initDates[l.produitId] = ''; initLots[l.produitId] = '' })
    setExpDates(initDates)
    setLotNums(initLots)
  }

  const doReceive = async (id) => {
    setReceivingId(id)
    try {
      await markAchatAsReceived(id)
      loadBL()
      setShowNewBL(false)
      setExpandedBCId(null)
    } catch (err) {
      console.error('Erreur réception :', err)
    } finally {
      setReceivingId(null)
    }
  }

  const doReceiveWithDates = async () => {
    if (!pendingReceive) return
    setSavingExp(true)
    try {
      await markAchatAsReceived(pendingReceive.id)

      const lignesAvecDate = pendingReceive.lignes.filter(l => expDates[l.produitId])

      await Promise.all(lignesAvecDate.map(async l => {
        const date = expDates[l.produitId]
        // 1. Met à jour la date d'expiration du produit (pour l'affichage inventaire)
        await updateProduitExpiration(l.produitId, date)
        // 2. Crée un lot tracé séparément
        await createLot({
          produitId:          l.produitId,
          numeroLot:          lotNums[l.produitId] || null,
          datePeremption:     date,
          quantite:           l.quantite ?? 0,
          fournisseur:        pendingReceive.fournisseur,
          numeroBonLivraison: String(pendingReceive.numeroBL),
          prixAchat:          l.prixUnitaire ?? null,
        })
      }))

      await loadExpiredSummary()  // refresh les badges périmés
      loadBL()
      refreshData()
      setShowNewBL(false)
      setExpandedBCId(null)
      setPendingReceive(null)
      setExpDates({})
      setLotNums({})
    } catch (err) {
      console.error('Erreur réception :', err)
    } finally {
      setSavingExp(false)
      setReceivingId(null)
    }
  }

  const doLitige = async (id) => {
    setLitigeId(id)
    try {
      await markAchatAsLitige(id)
      loadBL()
      setShowNewBL(false)
      setExpandedBCId(null)
    } catch (err) {
      console.error('Erreur litige :', err)
    } finally {
      setLitigeId(null)
    }
  }

  useEffect(() => {
    clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      setPage(0)
      loadProducts(search, 0)
    }, 300)
    return () => clearTimeout(debounceRef.current)
  }, [search, loadProducts])

  function handleStockSaved(updated) {
    setProducts(prev => prev.map(p => p.id === updated.id ? updated : p))
  }

  const withStatus = products.map(p => ({ ...p, status: getStatus(p, expiredByProduit[p.id] ?? 0) }))
  const stockFaible   = withStatus.filter(p => p.status === 'Stock faible').length
  const stockCritique = withStatus.filter(p => p.status === 'Stock critique' || p.status === 'Rupture').length
  const perimes       = withStatus.filter(p => p.status === 'Périmé').length
  const alertes       = withStatus.filter(p => p.status !== 'OK')

  const now         = new Date()
  const blCeMois    = bonsLivraison.filter(bl => {
    const d = new Date(bl.date)
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
  }).length
  const blLivrees   = bonsLivraison.filter(bl => bl.statut === 'Reçue').length
  const blEnAttente = bonsLivraison.filter(bl => bl.statut === 'Confirmée').length
  const blEnCours   = bonsLivraison.filter(bl => bl.statut === 'En attente').length
  const blLitiges   = bonsLivraison.filter(bl => bl.statut === 'Litige').length
  const confirmees  = allAchats.filter(a => a.statut === 'Confirmée')

  return (
    <div className="p-6 space-y-6">

      {editProduct && (
        <StockModal
          product={editProduct}
          onClose={() => setEditProduct(null)}
          onSaved={handleStockSaved}
        />
      )}

      {/* ─── Modal : Nouveau bon de livraison (depuis BC confirmé) ─── */}
      {showNewBL && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl mx-4 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 flex-shrink-0">
              <div>
                <h2 className="font-semibold text-gray-800 text-lg">Nouveau bon de livraison</h2>
                <p className="text-xs text-gray-400 mt-0.5">Sélectionner un bon de commande confirmé à réceptionner</p>
              </div>
              <button onClick={() => { setShowNewBL(false); setExpandedBCId(null); }} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1">
              {confirmees.length === 0 ? (
                <div className="text-center py-12">
                  <Truck className="w-12 h-12 text-gray-200 mx-auto mb-3" />
                  <p className="text-gray-500 font-medium">Aucun bon de commande confirmé disponible</p>
                  <p className="text-gray-400 text-sm mt-1">
                    Confirmez d'abord un bon de commande depuis la page Achats
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {confirmees.map(bc => {
                    const isExpanded = expandedBCId === bc.id
                    const ht  = bc.totalHt  ?? bc.montant ?? 0
                    const ttc = bc.totalTtc ?? ht * 1.1
                    return (
                      <div key={bc.id} className={`border rounded-xl transition-colors ${isExpanded ? 'border-green-300 bg-green-50/20' : 'border-gray-200 hover:border-green-200'}`}>

                        {/* ── Ligne résumé ── */}
                        <div className="flex items-center justify-between px-4 py-3.5">
                          <button
                            className="flex-1 min-w-0 text-left"
                            onClick={() => setExpandedBCId(isExpanded ? null : bc.id)}>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-gray-800 text-sm">
                                {bc.numeroBC ?? bc.reference ?? `BC-${bc.id}`}
                              </span>
                              <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 font-medium">
                                Confirmée
                              </span>
                            </div>
                            <div className="flex items-center gap-4 text-xs text-gray-500 flex-wrap">
                              <span className="flex items-center gap-1"><Building2 className="w-3 h-3" />{bc.fournisseur ?? '—'}</span>
                              <span>📦 {bc.articlesCount ?? bc.lignes?.length ?? 0} article(s)</span>
                              <span>💰 {ht.toFixed(2)} DH HT</span>
                              {bc.dateCommande && <span>🗓 Commandé : {new Date(bc.dateCommande).toLocaleDateString('fr-FR')}</span>}
                              {bc.datePrevue   && <span>🚚 Livraison : {new Date(bc.datePrevue).toLocaleDateString('fr-FR')}</span>}
                            </div>
                          </button>
                          <div className="flex items-center gap-2 ml-4 flex-shrink-0">
                            <button
                              onClick={() => setExpandedBCId(isExpanded ? null : bc.id)}
                              className="text-xs text-gray-500 hover:text-green-700 px-3 py-1.5 rounded-lg border border-gray-200 hover:border-green-300 transition-colors">
                              {isExpanded ? 'Réduire ▲' : 'Voir détails ▼'}
                            </button>
                            <button
                              onClick={() => doLitige(bc.id)}
                              disabled={litigeId === bc.id || receivingId === bc.id}
                              className="flex items-center gap-1.5 bg-red-50 hover:bg-red-100 disabled:opacity-50 text-red-600 border border-red-200 px-4 py-2 rounded-xl text-sm font-semibold transition-colors">
                              ⚠ {litigeId === bc.id ? 'Traitement...' : 'Problème'}
                            </button>
                            <button
                              onClick={() => { setShowNewBL(false); openDateModal({ _id: bc.id, lignes: bc.lignes ?? [] }); }}
                              disabled={receivingId === bc.id || litigeId === bc.id}
                              className="flex items-center gap-1.5 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white px-4 py-2 rounded-xl text-sm font-semibold transition-colors">
                              <Truck className="w-4 h-4" />
                              {receivingId === bc.id ? 'Réception...' : 'Réceptionner'}
                            </button>
                          </div>
                        </div>

                        {/* ── Détails expansibles ── */}
                        {isExpanded && (
                          <div className="border-t border-gray-100 px-4 pb-4 pt-3">

                            {/* Infos générales */}
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                              <div className="bg-white rounded-xl border border-gray-100 p-3">
                                <p className="text-xs text-gray-400 mb-1">N° Bon</p>
                                <p className="font-semibold text-gray-800 text-sm">{bc.numeroBC ?? bc.reference ?? '—'}</p>
                              </div>
                              <div className="bg-white rounded-xl border border-gray-100 p-3">
                                <p className="text-xs text-gray-400 mb-1">Fournisseur</p>
                                <p className="font-semibold text-gray-800 text-sm">{bc.fournisseur ?? '—'}</p>
                              </div>
                              <div className="bg-white rounded-xl border border-gray-100 p-3">
                                <p className="text-xs text-gray-400 mb-1">Date commande</p>
                                <p className="font-semibold text-gray-800 text-sm">
                                  {bc.dateCommande ? new Date(bc.dateCommande).toLocaleDateString('fr-FR') : '—'}
                                </p>
                              </div>
                              <div className="bg-white rounded-xl border border-gray-100 p-3">
                                <p className="text-xs text-gray-400 mb-1">Date livraison prévue</p>
                                <p className="font-semibold text-gray-800 text-sm">
                                  {bc.datePrevue ? new Date(bc.datePrevue).toLocaleDateString('fr-FR') : '—'}
                                </p>
                              </div>
                            </div>

                            {/* Tableau des articles */}
                            {bc.lignes?.length > 0 ? (
                              <div className="rounded-xl overflow-hidden border border-gray-100">
                                <table className="w-full text-sm">
                                  <thead>
                                    <tr className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wide">
                                      <th className="text-left px-4 py-2.5">Médicament</th>
                                      <th className="text-center px-4 py-2.5">Quantité</th>
                                      <th className="text-right px-4 py-2.5">Prix unitaire</th>
                                      <th className="text-right px-4 py-2.5">Total ligne</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {bc.lignes.map((l, i) => (
                                      <tr key={i} className="border-t border-gray-50 hover:bg-gray-50/50">
                                        <td className="px-4 py-2.5 font-medium text-gray-800">{l.nom ?? '—'}</td>
                                        <td className="px-4 py-2.5 text-center text-gray-600">{l.quantite ?? 0}</td>
                                        <td className="px-4 py-2.5 text-right text-gray-600">{(l.prixUnitaire ?? 0).toFixed(2)} DH</td>
                                        <td className="px-4 py-2.5 text-right font-semibold text-gray-800">
                                          {((l.quantite ?? 0) * (l.prixUnitaire ?? 0)).toFixed(2)} DH
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            ) : (
                              <p className="text-xs text-gray-400 text-center py-4">Aucun article enregistré</p>
                            )}

                            {/* Totaux */}
                            <div className="flex justify-end gap-8 mt-4 pt-3 border-t border-gray-100">
                              <div className="text-right">
                                <p className="text-xs text-gray-400">Total HT</p>
                                <p className="font-bold text-gray-800">{ht.toFixed(2)} DH</p>
                              </div>
                              <div className="text-right">
                                <p className="text-xs text-gray-400">Total TTC</p>
                                <p className="font-bold text-green-600">{ttc.toFixed(2)} DH</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ─── Modal : Détails bon de livraison ─── */}
      {selectedBL && (() => {
        const isLitige  = selectedBL.statut === 'Litige'
        const isLivree  = selectedBL.statut === 'Reçue'
        const meta      = STATUT_BL[selectedBL.statut] ?? { label: selectedBL.statut, css: 'text-gray-600 bg-gray-100' }
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl mx-4 overflow-hidden max-h-[90vh] flex flex-col">

              {/* Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 flex-shrink-0">
                <div className="flex items-center gap-3">
                  <div>
                    <h2 className="font-semibold text-gray-800 text-lg">{selectedBL.id}</h2>
                    <p className="text-xs text-gray-400 mt-0.5">{selectedBL.fournisseur}</p>
                  </div>
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${meta.css}`}>
                    {meta.label}
                  </span>
                  {isLitige && (
                    <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-red-50 text-red-500 border border-red-200">
                      ⚠ Problème signalé
                    </span>
                  )}
                </div>
                <button onClick={() => setSelectedBL(null)} className="text-gray-400 hover:text-gray-600">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 overflow-y-auto flex-1">

                {/* Infos générales */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-5">
                  <div className="bg-gray-50 rounded-xl p-3">
                    <p className="text-xs text-gray-400 mb-1">N° Bon</p>
                    <p className="font-semibold text-gray-800 text-sm">{selectedBL.id}</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3">
                    <p className="text-xs text-gray-400 mb-1">Fournisseur</p>
                    <p className="font-semibold text-gray-800 text-sm">{selectedBL.fournisseur}</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3">
                    <p className="text-xs text-gray-400 mb-1">Date commande</p>
                    <p className="font-semibold text-gray-800 text-sm">
                      {selectedBL.dateCommande ? new Date(selectedBL.dateCommande).toLocaleDateString('fr-FR') : '—'}
                    </p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3">
                    <p className="text-xs text-gray-400 mb-1">Date livraison prévue</p>
                    <p className="font-semibold text-gray-800 text-sm">
                      {selectedBL.date ? new Date(selectedBL.date).toLocaleDateString('fr-FR') : '—'}
                    </p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3">
                    <p className="text-xs text-gray-400 mb-1">Articles</p>
                    <p className="font-semibold text-gray-800 text-sm">{selectedBL.articles} article(s)</p>
                  </div>
                  <div className={`rounded-xl p-3 ${isLitige ? 'bg-red-50' : 'bg-gray-50'}`}>
                    <p className="text-xs text-gray-400 mb-1">Statut</p>
                    <p className={`font-semibold text-sm ${isLitige ? 'text-red-600' : 'text-gray-800'}`}>
                      {meta.label}
                    </p>
                  </div>
                </div>

                {/* Message litige */}
                {isLitige && (
                  <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-5 flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-red-700 text-sm">Problème de livraison signalé</p>
                      <p className="text-red-500 text-xs mt-1">
                        Cette livraison a été marquée comme non conforme à la commande.
                        Si le problème est résolu, vous pouvez la marquer comme livrée.
                      </p>
                    </div>
                  </div>
                )}

                {/* Tableau des articles */}
                {selectedBL.lignes?.length > 0 ? (
                  <div className="rounded-xl overflow-hidden border border-gray-100">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wide">
                          <th className="text-left px-4 py-2.5">Médicament</th>
                          <th className="text-center px-4 py-2.5">Quantité</th>
                          <th className="text-center px-4 py-2.5">Date expiration</th>
                          <th className="text-right px-4 py-2.5">Prix unitaire</th>
                          <th className="text-right px-4 py-2.5">Total ligne</th>
                        </tr>
                      </thead>
                      <tbody>
                        {selectedBL.lignes.map((l, i) => (
                          <tr key={i} className="border-t border-gray-50 hover:bg-gray-50/50">
                            <td className="px-4 py-2.5 font-medium text-gray-800">{l.nom ?? '—'}</td>
                            <td className="px-4 py-2.5 text-center text-gray-600">{l.quantite ?? 0}</td>
                            <td className="px-4 py-2.5 text-center text-xs">
                              {blLotsMap[l.produitId]
                                ? <span className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full font-medium">{new Date(blLotsMap[l.produitId]).toLocaleDateString('fr-FR')}</span>
                                : <span className="text-gray-400">—</span>
                              }
                            </td>
                            <td className="px-4 py-2.5 text-right text-gray-600">{(l.prixUnitaire ?? 0).toFixed(2)} DH</td>
                            <td className="px-4 py-2.5 text-right font-semibold text-gray-800">
                              {((l.quantite ?? 0) * (l.prixUnitaire ?? 0)).toFixed(2)} DH
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-xs text-gray-400 text-center py-6">Aucun article enregistré</p>
                )}

                {/* Totaux */}
                <div className="flex justify-end gap-8 mt-4 pt-3 border-t border-gray-100">
                  <div className="text-right">
                    <p className="text-xs text-gray-400">Total HT</p>
                    <p className="font-bold text-gray-800">{selectedBL.totalHT.toFixed(2)} DH</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-400">Total TTC</p>
                    <p className="font-bold text-green-600">{selectedBL.totalTTC.toFixed(2)} DH</p>
                  </div>
                </div>
              </div>

              {/* Footer actions */}
              <div className="px-6 py-4 border-t border-gray-100 flex gap-3 flex-shrink-0">
                <button
                  onClick={() => setSelectedBL(null)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-gray-600 font-semibold text-sm hover:bg-gray-50 transition-colors">
                  Fermer
                </button>
                {isLitige && (
                  <button
                    onClick={() => { setSelectedBL(null); openDateModal(selectedBL); }}
                    disabled={receivingId === selectedBL._id}
                    className="flex-1 py-2.5 rounded-xl bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors">
                    <Truck className="w-4 h-4" />
                    Marquer comme livré
                  </button>
                )}
              </div>

            </div>
          </div>
        )
      })()}

      {/* ─── Modal : Gestion des lots périmés ─── */}
      {lotsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xl mx-4 overflow-hidden max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <div>
                <h2 className="font-semibold text-gray-800 text-lg">Lots périmés — {lotsModal.produit.nom}</h2>
                <p className="text-xs text-gray-400 mt-0.5">Retirez les lots que vous avez déjà traités</p>
              </div>
              <button onClick={() => setLotsModal(null)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 space-y-3">
              {lotsModalLoading ? (
                <div className="text-center py-10 text-gray-400 text-sm">Chargement...</div>
              ) : lotsModal.lots.length === 0 ? (
                <div className="text-center py-10">
                  <div className="text-3xl mb-2">✅</div>
                  <p className="text-gray-500 font-medium">Aucun lot périmé en stock</p>
                  <p className="text-gray-400 text-xs mt-1">Tous les lots ont été retirés</p>
                </div>
              ) : lotsModal.lots.map(lot => (
                <div key={lot.id} className="flex items-center gap-4 bg-red-50 border border-red-200 rounded-xl px-4 py-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-semibold text-gray-800 text-sm">{lot.numeroLot}</span>
                      <span className="text-xs px-2 py-0.5 bg-red-100 text-red-700 rounded-full font-medium">Périmé</span>
                    </div>
                    <div className="text-xs text-gray-500 flex gap-3 flex-wrap">
                      <span>📅 Exp : {new Date(lot.datePeremption).toLocaleDateString('fr-FR')}</span>
                      <span>📦 {lot.quantiteRestante} unités</span>
                      {lot.fournisseur && <span>🏭 {lot.fournisseur}</span>}
                      {lot.numeroBonLivraison && <span>BL #{lot.numeroBonLivraison}</span>}
                    </div>
                  </div>
                  <button
                    onClick={() => doRetireLot(lot.id)}
                    disabled={retiringLotId === lot.id}
                    className="flex-shrink-0 px-3 py-2 bg-white hover:bg-red-600 hover:text-white disabled:opacity-50 text-red-600 border border-red-300 rounded-xl text-xs font-semibold transition-colors">
                    {retiringLotId === lot.id ? '...' : 'Retirer du stock'}
                  </button>
                </div>
              ))}
            </div>

            <div className="px-6 py-4 border-t border-gray-100 flex justify-end">
              <button
                onClick={() => setLotsModal(null)}
                className="px-5 py-2.5 rounded-xl border border-gray-200 text-gray-600 font-semibold text-sm hover:bg-gray-50 transition-colors">
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ─── Modal : Saisie rapide des dates d'expiration ─── */}
      {pendingReceive && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl mx-4 overflow-hidden max-h-[90vh] flex flex-col">

            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 flex-shrink-0">
              <div>
                <h2 className="font-semibold text-gray-800 text-lg">Dates d'expiration — Réception</h2>
                <p className="text-xs text-gray-400 mt-0.5">
                  Saisissez le mois/année imprimé sur chaque boîte · Tab pour passer à la suivante
                </p>
              </div>
              <button onClick={() => setPendingReceive(null)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Bouton "même date pour tous" */}
            {pendingReceive.lignes.length > 1 && (
              <div className="px-6 pt-4 pb-0 flex items-center gap-3 flex-shrink-0">
                <span className="text-xs text-gray-500 font-medium">Même date pour tous :</span>
                <input
                  type="date"
                  className="border border-gray-200 rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
                  onChange={e => {
                    if (!e.target.value) return
                    const all = {}
                    pendingReceive.lignes.forEach(l => { if (l.produitId) all[l.produitId] = e.target.value })
                    setExpDates(all)
                  }}
                />
                <span className="text-xs text-gray-400">→ applique à tous les articles</span>
              </div>
            )}

            {/* Liste des articles */}
            <div className="p-6 overflow-y-auto flex-1 space-y-2 mt-2">
              {pendingReceive.lignes.length === 0 ? (
                <div className="text-center py-10">
                  <Package className="w-10 h-10 text-gray-200 mx-auto mb-3" />
                  <p className="text-gray-400 text-sm">Aucun article avec référence produit</p>
                  <p className="text-gray-300 text-xs mt-1">La réception sera quand même enregistrée</p>
                </div>
              ) : pendingReceive.lignes.map((l, i) => {
                const val      = expDates[l.produitId] ?? ''
                const hasDate  = !!val
                const isExp    = hasDate && new Date(val) < new Date()
                const bgCss    = isExp ? 'bg-red-50 border-red-300' : hasDate ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-100'
                return (
                  <div key={i} className={`rounded-xl px-4 py-3 border transition-colors ${bgCss}`}>
                    <div className="flex items-center gap-4">
                      {/* Numéro */}
                      <div className={`w-6 h-6 rounded-full border flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                        isExp ? 'bg-red-100 border-red-300 text-red-600' : 'bg-white border-gray-200 text-gray-500'
                      }`}>{i + 1}</div>
                      {/* Nom + qté */}
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-gray-800 text-sm truncate">{l.nom ?? '—'}</p>
                        <p className="text-xs text-gray-400">{l.quantite} unités reçues</p>
                      </div>
                      {/* N° lot */}
                      <input
                        type="text"
                        placeholder="N° lot (optionnel)"
                        value={lotNums[l.produitId] ?? ''}
                        onChange={e => setLotNums(prev => ({ ...prev, [l.produitId]: e.target.value }))}
                        className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300 bg-white"
                        style={{ width: 140 }}
                      />
                      {/* Date expiration */}
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <input
                          type="date"
                          value={val}
                          autoFocus={i === 0}
                          onChange={e => setExpDates(prev => ({ ...prev, [l.produitId]: e.target.value }))}
                          className={`border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 transition-colors ${
                            isExp ? 'border-red-400 ring-red-300 text-red-700 bg-red-50'
                            : hasDate ? 'border-green-300 ring-green-400 text-green-800 bg-white'
                            : 'border-gray-200 ring-green-400 bg-white'
                          }`}
                          style={{ width: 155 }}
                        />
                        {isExp  && <span className="text-red-500 text-base" title="Date périmée !">⚠</span>}
                        {!isExp && hasDate && <span className="text-green-500 text-base">✓</span>}
                      </div>
                    </div>
                    {/* Avertissement périmé */}
                    {isExp && (
                      <div className="mt-2 ml-10 flex items-center gap-2 text-xs text-red-600 font-medium">
                        <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                        Ce lot est périmé — il sera enregistré séparément ({l.quantite} unités ⚠)
                      </div>
                    )}
                  </div>
                )
              })}
              <p className="text-xs text-gray-300 text-center pt-1">
                Les articles sans date ne seront pas modifiés
              </p>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-gray-100 flex gap-3 flex-shrink-0 items-center">
              <div className="flex-1 text-xs text-gray-400">
                {Object.values(expDates).filter(Boolean).length} / {pendingReceive.lignes.length} dates saisies
              </div>
              <button
                onClick={() => setPendingReceive(null)}
                className="px-5 py-2.5 rounded-xl border border-gray-200 text-gray-600 font-semibold text-sm hover:bg-gray-50 transition-colors">
                Annuler
              </button>
              <button
                onClick={doReceiveWithDates}
                disabled={savingExp}
                className="px-6 py-2.5 rounded-xl bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white font-semibold text-sm flex items-center gap-2 transition-colors">
                <Truck className="w-4 h-4" />
                {savingExp ? 'Enregistrement...' : 'Réceptionner'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-gray-200 -mb-6">
        {[
          { key: 'inventaire', icon: Package, label: 'Inventaire' },
          { key: 'bons',       icon: Truck,   label: 'Bons de livraison' },
        ].map(({ key, icon: Icon, label }) => (
          <button key={key} onClick={() => setTab(key)}
            className={`flex items-center gap-2 px-4 pb-3 text-sm font-medium border-b-2 transition-colors ${
              tab === key
                ? 'border-green-600 text-green-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}>
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {tab === 'inventaire' ? (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 pt-6">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
              <div className="p-2.5 rounded-xl bg-green-50">
                <Package className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">{totalProducts || total}</p>
                <p className="text-sm text-gray-500">Total produits</p>
              </div>
            </div>
            <div className="bg-orange-50 rounded-2xl border border-orange-100 p-5 flex items-center gap-4">
              <AlertTriangle className="w-6 h-6 text-orange-500 flex-shrink-0" />
              <div>
                <p className="text-2xl font-bold text-gray-800">{stockFaible}</p>
                <p className="text-sm text-gray-500">Stock faible</p>
              </div>
            </div>
            <div className="bg-red-50 rounded-2xl border border-red-100 p-5 flex items-center gap-4">
              <AlertTriangle className="w-6 h-6 text-red-500 flex-shrink-0" />
              <div>
                <p className="text-2xl font-bold text-gray-800">{stockCritique}</p>
                <p className="text-sm text-gray-500">Stock critique / Rupture</p>
              </div>
            </div>
            <div className="bg-red-50 rounded-2xl border border-red-100 p-5 flex items-center gap-4">
              <Calendar className="w-6 h-6 text-red-600 flex-shrink-0" />
              <div>
                <p className="text-2xl font-bold text-gray-800">{perimes}</p>
                <p className="text-sm text-gray-500">Produits périmés</p>
              </div>
            </div>
          </div>

          {/* Alertes */}
          {alertes.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-4">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <h3 className="font-semibold text-amber-800">
                  Alertes — page courante ({alertes.length})
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {alertes.map(p => (
                  <div key={p.id} className="flex items-center justify-between bg-white rounded-xl px-4 py-3">
                    <div className="min-w-0 mr-3">
                      <p className="font-semibold text-gray-800 text-sm truncate">{p.nom}</p>
                      <p className="text-xs text-gray-400">Stock: {p.stock} / Seuil: {p.seuilAlerte}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className={`text-xs font-medium px-2.5 py-1 rounded-full whitespace-nowrap ${STATUS_STYLES[p.status]?.badge}`}>
                        {p.status}
                      </span>
                      <button onClick={() => setEditProduct(p)}
                        className="text-gray-400 hover:text-green-600 transition-colors">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Table */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-4">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Rechercher un médicament..."
                  className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
                {loading && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 border-2 border-green-500 border-t-transparent rounded-full animate-spin" />
                )}
              </div>
              <p className="text-sm text-gray-400 whitespace-nowrap">
                {total} résultat(s) — page {page + 1}/{totalPages}
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-gray-500 border-b border-gray-100 bg-gray-50">
                    <th className="text-left px-5 py-3 font-medium">Produit</th>
                    <th className="text-left px-4 py-3 font-medium">DCI</th>
                    <th className="text-left px-4 py-3 font-medium">Code EAN13</th>
                    <th className="text-center px-4 py-3 font-medium">Stock</th>
                    <th className="text-center px-4 py-3 font-medium">Seuil alerte</th>
                    <th className="text-right px-4 py-3 font-medium">Prix vente</th>
                    <th className="text-center px-4 py-3 font-medium">Expiration</th>
                    <th className="text-center px-4 py-3 font-medium">Statut</th>
                    <th className="text-center px-4 py-3 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {withStatus.length === 0 && !loading ? (
                    <tr>
                      <td colSpan={9} className="text-center py-16 text-gray-400 text-sm">
                        Aucun médicament trouvé
                      </td>
                    </tr>
                  ) : (
                    withStatus.map(p => {
                      const s = STATUS_STYLES[p.status] ?? STATUS_STYLES['OK']
                      return (
                        <tr key={p.id}
                          className={`border-b border-gray-50 last:border-0 hover:bg-gray-50/50 transition-colors ${s.border}`}>
                          <td className="px-5 py-3 font-semibold text-gray-800 max-w-[200px] truncate">{p.nom}</td>
                          <td className="px-4 py-3 text-gray-500 text-xs max-w-[140px] truncate">{p.dci || '—'}</td>
                          <td className="px-4 py-3 font-mono text-xs text-gray-400">{p.codeEan13 || '—'}</td>
                          <td className="px-4 py-3 text-center">
                            <span className="font-bold text-gray-800">{p.stock}</span>
                            {expiredByProduit[p.id] > 0 && (
                              <button
                                onClick={() => openLotsModal(p)}
                                className="block mx-auto text-xs text-red-600 font-medium mt-0.5 hover:text-red-800 hover:underline cursor-pointer transition-colors"
                                title="Voir et gérer les lots périmés">
                                ⚠ {expiredByProduit[p.id]} périmé{expiredByProduit[p.id] > 1 ? 's' : ''}
                              </button>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center text-gray-500">{p.seuilAlerte}</td>
                          <td className="px-4 py-3 text-right font-semibold text-green-600">
                            {p.prixVente ? `${p.prixVente.toFixed(2)} DH` : '—'}
                          </td>
                          <td className="px-4 py-3 text-center text-xs">
                            {editingExpId === p.id ? (
                              <div className="flex items-center gap-1 justify-center">
                                <input
                                  type="date"
                                  autoFocus
                                  value={editingExpVal}
                                  onChange={e => setEditingExpVal(e.target.value)}
                                  onKeyDown={e => {
                                    if (e.key === 'Enter') saveExpiration(p.id)
                                    if (e.key === 'Escape') { setEditingExpId(null); setEditingExpVal('') }
                                  }}
                                  className="border border-green-300 rounded-lg px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-green-300"
                                  style={{ width: 130 }}
                                />
                                <button
                                  onClick={() => saveExpiration(p.id)}
                                  disabled={savingExpId === p.id}
                                  className="text-green-600 hover:text-green-800 font-bold text-sm disabled:opacity-50">
                                  {savingExpId === p.id ? '…' : '✓'}
                                </button>
                                <button
                                  onClick={() => { setEditingExpId(null); setEditingExpVal('') }}
                                  className="text-gray-400 hover:text-gray-600">
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => {
                                  setEditingExpId(p.id)
                                  setEditingExpVal(p.dateExpiration ?? '')
                                }}
                                className={`group flex items-center gap-1 mx-auto hover:bg-gray-100 rounded-lg px-2 py-1 transition-colors ${s.dateClass}`}
                                title="Modifier la date d'expiration">
                                <span>{p.dateExpiration ?? '—'}</span>
                                <Pencil className="w-3 h-3 opacity-0 group-hover:opacity-50 transition-opacity flex-shrink-0" />
                              </button>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${s.badge}`}>
                              {p.status}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <button onClick={() => setEditProduct(p)}
                              className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors">
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </table>
            </div>

            {totalPages > 1 && (
              <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
                <button
                  onClick={() => loadProducts(search, page - 1)}
                  disabled={page === 0 || loading}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-600 border border-gray-200 rounded-lg hover:border-green-400 hover:text-green-600 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                  <ChevronLeft className="w-4 h-4" />
                  Précédent
                </button>
                <span className="text-sm text-gray-500">Page {page + 1} sur {totalPages}</span>
                <button
                  onClick={() => loadProducts(search, page + 1)}
                  disabled={page >= totalPages - 1 || loading}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-600 border border-gray-200 rounded-lg hover:border-green-400 hover:text-green-600 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                  Suivant
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </>
      ) : (
        <>
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 pt-6">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <FileText className="w-7 h-7 text-green-600 mb-3" />
              <p className="text-3xl font-bold text-gray-800">{blCeMois || bonsLivraison.length}</p>
              <p className="text-sm text-gray-500 mt-1">Total ce mois</p>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <Truck className="w-7 h-7 text-blue-500 mb-3" />
              <p className="text-3xl font-bold text-gray-800">{blLivrees}</p>
              <p className="text-sm text-gray-500 mt-1">Livrées</p>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <Calendar className="w-7 h-7 text-orange-500 mb-3" />
              <p className="text-3xl font-bold text-gray-800">{blEnAttente}</p>
              <p className="text-sm text-gray-500 mt-1">En attente</p>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <Package className="w-7 h-7 text-purple-500 mb-3" />
              <p className="text-3xl font-bold text-gray-800">{blEnCours}</p>
              <p className="text-sm text-gray-500 mt-1">En cours</p>
            </div>
            {blLitiges > 0 && (
              <div className="bg-red-50 rounded-2xl border border-red-100 shadow-sm p-5">
                <AlertTriangle className="w-7 h-7 text-red-500 mb-3" />
                <p className="text-3xl font-bold text-red-700">{blLitiges}</p>
                <p className="text-sm text-red-400 mt-1">Litiges</p>
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <p className="text-sm text-gray-400">{bonsLivraison.length} bon(s)</p>
              <button
                onClick={() => setShowNewBL(true)}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors">
                <Plus className="w-4 h-4" />
                Nouveau bon de livraison
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-gray-500 border-b border-gray-100 bg-gray-50">
                    <th className="text-left px-5 py-3 font-medium">N° Bon</th>
                    <th className="text-left px-4 py-3 font-medium">Fournisseur</th>
                    <th className="text-left px-4 py-3 font-medium">Date livraison</th>
                    <th className="text-center px-4 py-3 font-medium">Articles</th>
                    <th className="text-right px-4 py-3 font-medium">Total HT</th>
                    <th className="text-right px-4 py-3 font-medium">Total TTC</th>
                    <th className="text-center px-4 py-3 font-medium">Statut</th>
                    <th className="text-center px-4 py-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {bonsLivraison.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="text-center py-16 text-gray-400 text-sm">
                        Aucun bon de livraison
                      </td>
                    </tr>
                  ) : (
                    bonsLivraison.map(bl => {
                      const meta = STATUT_BL[bl.statut] ?? { label: bl.statut, css: 'text-gray-600 bg-gray-100' }
                      return (
                        <tr key={bl._id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50/50 transition-colors">
                          <td className="px-5 py-3.5 font-semibold text-gray-800">{bl.id}</td>
                          <td className="px-4 py-3.5 text-gray-600">{bl.fournisseur}</td>
                          <td className="px-4 py-3.5 text-gray-500">{bl.date ? new Date(bl.date).toLocaleDateString('fr-FR') : '—'}</td>
                          <td className="px-4 py-3.5 text-center font-medium text-gray-800">{bl.articles}</td>
                          <td className="px-4 py-3.5 text-right font-semibold text-gray-800">{(bl.totalHT ?? 0).toFixed(2)} DH</td>
                          <td className="px-4 py-3.5 text-right font-semibold text-gray-800">{(bl.totalTTC ?? 0).toFixed(2)} DH</td>
                          <td className="px-4 py-3.5 text-center">
                            <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${meta.css}`}>
                              {meta.label}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-center">
                            {bl.statut === 'Confirmée' ? (
                              <div className="flex items-center justify-center gap-2">
                                <button
                                  onClick={() => doLitige(bl._id)}
                                  disabled={litigeId === bl._id || receivingId === bl._id}
                                  title="Signaler un problème de livraison"
                                  className="text-xs font-semibold px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 rounded-lg transition-colors disabled:opacity-50">
                                  {litigeId === bl._id ? '...' : '⚠ Litige'}
                                </button>
                                <button
                                  onClick={() => openDateModal(bl)}
                                  disabled={receivingId === bl._id || litigeId === bl._id}
                                  className="text-xs font-semibold px-3 py-1.5 bg-green-100 hover:bg-green-200 text-green-700 rounded-lg transition-colors disabled:opacity-50">
                                  {receivingId === bl._id ? '...' : 'Réceptionner'}
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => openBLDetail(bl)}
                                className="text-gray-400 hover:text-green-600 transition-colors"
                                title="Voir les détails">
                                <Eye className="w-4 h-4" />
                              </button>
                            )}
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* ══════════ FIN ONGLETS ══════════ */}
      {false && (() => {
        const today = new Date()
        const in30  = new Date(); in30.setDate(today.getDate() + 30)
        const in60  = new Date(); in60.setDate(today.getDate() + 60)
        const in90  = new Date(); in90.setDate(today.getDate() + 90)

        const filtered = expProducts.filter(p => {
          const d = new Date(p.dateExpiration)
          if (expFilter === 'perimes')  return d < today
          if (expFilter === '30j')      return d >= today && d <= in30
          if (expFilter === '60j')      return d >= today && d <= in60
          if (expFilter === '90j')      return d >= today && d <= in90
          return true
        })

        const nbPerimes = expProducts.filter(p => new Date(p.dateExpiration) < today).length
        const nb30      = expProducts.filter(p => { const d = new Date(p.dateExpiration); return d >= today && d <= in30 }).length
        const nb90      = expProducts.filter(p => { const d = new Date(p.dateExpiration); return d >= today && d <= in90 }).length

        return (
          <>
            {/* Stats */}
            <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 pt-6">
              <div className={`rounded-2xl border p-5 ${nbPerimes > 0 ? 'bg-red-50 border-red-100' : 'bg-white border-gray-100 shadow-sm'}`}>
                <AlertTriangle className={`w-7 h-7 mb-3 ${nbPerimes > 0 ? 'text-red-500' : 'text-gray-300'}`} />
                <p className={`text-3xl font-bold ${nbPerimes > 0 ? 'text-red-700' : 'text-gray-800'}`}>{nbPerimes}</p>
                <p className="text-sm text-gray-500 mt-1">Périmés</p>
              </div>
              <div className={`rounded-2xl border p-5 ${nb30 > 0 ? 'bg-orange-50 border-orange-100' : 'bg-white border-gray-100 shadow-sm'}`}>
                <Calendar className={`w-7 h-7 mb-3 ${nb30 > 0 ? 'text-orange-500' : 'text-gray-300'}`} />
                <p className={`text-3xl font-bold ${nb30 > 0 ? 'text-orange-700' : 'text-gray-800'}`}>{nb30}</p>
                <p className="text-sm text-gray-500 mt-1">Expirent dans 30 jours</p>
              </div>
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <AlertTriangle className="w-7 h-7 text-amber-400 mb-3" />
                <p className="text-3xl font-bold text-gray-800">{nb90}</p>
                <p className="text-sm text-gray-500 mt-1">Expirent dans 90 jours</p>
              </div>
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <Package className="w-7 h-7 text-green-600 mb-3" />
                <p className="text-3xl font-bold text-gray-800">{expProducts.length}</p>
                <p className="text-sm text-gray-500 mt-1">Total avec date</p>
              </div>
            </div>

            {/* Filtres */}
            <div className="flex items-center gap-2 mt-6 flex-wrap">
              {[
                { key: 'tous',    label: 'Tous',              color: 'bg-gray-100 text-gray-700' },
                { key: 'perimes', label: '🔴 Périmés',        color: 'bg-red-100 text-red-700'    },
                { key: '30j',     label: '🟠 Dans 30 jours',  color: 'bg-orange-100 text-orange-700' },
                { key: '60j',     label: '🟡 Dans 60 jours',  color: 'bg-yellow-100 text-yellow-700' },
                { key: '90j',     label: '🔵 Dans 90 jours',  color: 'bg-blue-100 text-blue-700'  },
              ].map(f => (
                <button key={f.key}
                  onClick={() => setExpFilter(f.key)}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${
                    expFilter === f.key ? f.color + ' ring-2 ring-offset-1 ring-current' : 'bg-white border border-gray-200 text-gray-500 hover:border-gray-300'
                  }`}>
                  {f.label}
                  {f.key !== 'tous' && (
                    <span className="ml-1.5 text-xs opacity-70">
                      ({f.key === 'perimes' ? nbPerimes : f.key === '30j' ? nb30 : f.key === '90j' ? nb90 :
                        expProducts.filter(p => { const d = new Date(p.dateExpiration); return d >= today && d <= in60 }).length})
                    </span>
                  )}
                </button>
              ))}
              <button onClick={loadExpProducts}
                className="ml-auto p-2 text-gray-400 hover:text-green-600 border border-gray-200 rounded-xl hover:border-green-300 transition-colors">
                <RefreshCw className={`w-4 h-4 ${expLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Tableau */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden mt-4">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-gray-500 border-b border-gray-100 bg-gray-50">
                    <th className="text-left px-5 py-3 font-medium">Médicament</th>
                    <th className="text-left px-4 py-3 font-medium">Forme</th>
                    <th className="text-center px-4 py-3 font-medium">Stock</th>
                    <th className="text-center px-4 py-3 font-medium">Date expiration</th>
                    <th className="text-center px-4 py-3 font-medium">Statut</th>
                    <th className="text-center px-4 py-3 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {expLoading ? (
                    <tr><td colSpan={6} className="text-center py-16 text-gray-400 text-sm">Chargement...</td></tr>
                  ) : filtered.length === 0 ? (
                    <tr><td colSpan={6} className="text-center py-16 text-gray-400 text-sm">Aucun médicament pour ce filtre</td></tr>
                  ) : filtered.map(p => {
                    const d        = new Date(p.dateExpiration)
                    const daysLeft = Math.ceil((d - today) / 86400000)
                    const isExp    = daysLeft <= 0
                    const is30     = daysLeft > 0 && daysLeft <= 30
                    const is90     = daysLeft > 0 && daysLeft <= 90
                    const badgeCss = isExp ? 'text-red-700 bg-red-100' : is30 ? 'text-orange-700 bg-orange-100' : is90 ? 'text-amber-700 bg-amber-100' : 'text-green-700 bg-green-100'
                    const badgeTxt = isExp ? `Périmé (${Math.abs(daysLeft)}j)` : is30 ? `${daysLeft}j restants` : is90 ? `${daysLeft}j restants` : 'OK'
                    const rowCss   = isExp ? 'bg-red-50/30' : is30 ? 'bg-orange-50/20' : ''
                    const isEditing = editingExpId === p.id
                    return (
                      <tr key={p.id} className={`border-b border-gray-50 last:border-0 hover:bg-gray-50/50 transition-colors ${rowCss}`}>
                        <td className="px-5 py-3.5">
                          <p className="font-semibold text-gray-800">{p.denomination ?? p.nom ?? '—'}</p>
                          {p.dci && <p className="text-xs text-gray-400">{p.dci}</p>}
                        </td>
                        <td className="px-4 py-3.5 text-gray-500 text-xs">{p.formeDosage ?? '—'}</td>
                        <td className="px-4 py-3.5 text-center font-semibold text-gray-800">{p.stock ?? 0}</td>
                        <td className="px-4 py-3.5 text-center">
                          {isEditing ? (
                            <div className="flex items-center justify-center gap-2">
                              <input
                                type="date"
                                value={editingExpDate}
                                onChange={e => setEditingExpDate(e.target.value)}
                                className="border border-green-300 rounded-lg px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
                                autoFocus
                              />
                              <button onClick={() => saveExpDate(p.id)}
                                className="text-xs bg-green-600 text-white px-2 py-1 rounded-lg hover:bg-green-700">✓</button>
                              <button onClick={() => { setEditingExpId(null); setEditingExpDate('') }}
                                className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-lg hover:bg-gray-200">✕</button>
                            </div>
                          ) : (
                            <button
                              onClick={() => { setEditingExpId(p.id); setEditingExpDate(p.dateExpiration ?? '') }}
                              className={`font-medium hover:underline ${isExp ? 'text-red-600' : is30 ? 'text-orange-600' : 'text-gray-700'}`}>
                              {p.dateExpiration ? new Date(p.dateExpiration).toLocaleDateString('fr-FR') : '—'}
                            </button>
                          )}
                        </td>
                        <td className="px-4 py-3.5 text-center">
                          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${badgeCss}`}>{badgeTxt}</span>
                        </td>
                        <td className="px-4 py-3.5 text-center">
                          <button
                            onClick={() => { setEditingExpId(p.id); setEditingExpDate(p.dateExpiration ?? '') }}
                            className="text-xs font-medium px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg transition-colors border border-blue-100">
                            Modifier date
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </>
        )
      })()}

    </div>
  )
}
