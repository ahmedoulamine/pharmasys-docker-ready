package pharmasys_backend.dashboard;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/stats")
    public Map<String, Object> getStats() {
        return dashboardService.getStats();
    }

    @GetMapping("/ventes-semaine")
    public List<Map<String, Object>> getVentesSemaine() {
        return dashboardService.getVentesSemaine();
    }

    @GetMapping("/top-produits")
    public List<Map<String, Object>> getTopProduits() {
        return dashboardService.getTopProduits();
    }

    @GetMapping("/alertes-stock")
    public List<Map<String, Object>> getAlertesStock() {
        return dashboardService.getAlertesStock();
    }

    @GetMapping("/activite")
    public List<Map<String, Object>> getActivite() {
        return dashboardService.getActivite();
    }
}
