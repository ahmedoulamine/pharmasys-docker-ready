package pharmasys_backend.defectueux;

public enum Priorite {
    BASSE, MOYENNE, HAUTE, CRITIQUE
}
