package pharmasys_backend.retour;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum StatutRetour {
    EN_ATTENTE("En attente"),
    APPROUVE("Approuvé"),
    REMBOURSE("Remboursé");

    private final String label;

    StatutRetour(String label) { this.label = label; }

    @JsonValue
    public String getLabel() { return label; }

    @JsonCreator
    public static StatutRetour fromLabel(String value) {
        if (value == null) return EN_ATTENTE;
        for (StatutRetour s : values()) {
            if (s.label.equals(value) || s.name().equals(value)) return s;
        }
        return EN_ATTENTE;
    }
}
