import { useLocation } from 'react-router-dom'

const PAGE_TITLES = {
  '/':          'Tableau de bord',
  '/pos':       'Vente POS — Caisse',
  '/stock':     'Gestion du Stock',
  '/defective': 'Produits Défectueux',
  '/produits':  'Produits',
  '/achats':    'Achats Fournisseurs',
  '/retours':   'Retours Achats',
  '/rapports':  'Rapports & Statistiques',
  '/patients':  'Gestion des Patients',
  '/caisse':    'Gestion de la Caisse',
}

export default function Header() {
  const { pathname } = useLocation()

  const today = new Date().toLocaleDateString('fr-FR', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  })

  return (
    <header className="h-16 bg-white border-b border-gray-100 px-6 flex items-center justify-between shadow-sm">
      <div>
        <h1 className="text-lg font-bold text-gray-800">{PAGE_TITLES[pathname] ?? 'PharmaSys'}</h1>
        <p className="text-xs text-gray-400 capitalize">{today}</p>
      </div>
    </header>
  )
}
