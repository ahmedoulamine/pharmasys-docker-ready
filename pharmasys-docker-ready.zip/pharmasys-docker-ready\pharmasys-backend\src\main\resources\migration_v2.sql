-- Migration v2 : nouvelles tables pour Chaimae & Khadija
-- Exécuter manuellement sur la DB pharmacie_db

-- Produits de Chaimae (CRUD séparé des médicaments)
CREATE TABLE IF NOT EXISTS products (
    id               BIGSERIAL PRIMARY KEY,
    name             VARCHAR(255) NOT NULL,
    therapeutic_class VARCHAR(255),
    barcode          VARCHAR(100),
    dosage           VARCHAR(255),
    composition      TEXT,
    price_ht         DOUBLE PRECISION,
    price            DOUBLE PRECISION,
    stock            INTEGER,
    expiration       VARCHAR(100)
);

-- Commandes fournisseurs
CREATE TABLE IF NOT EXISTS achats (
    id              BIGSERIAL PRIMARY KEY,
    reference       VARCHAR(100),
    fournisseur     VARCHAR(255),
    date_commande   DATE,
    date_prevue     DATE,
    articles_count  INTEGER,
    montant         DOUBLE PRECISION,
    statut          VARCHAR(50) NOT NULL DEFAULT 'EN_ATTENTE'
);

-- Retours fournisseurs
CREATE TABLE IF NOT EXISTS retours (
    id              BIGSERIAL PRIMARY KEY,
    reference       VARCHAR(100),
    fournisseur     VARCHAR(255),
    date_retour     DATE,
    motif           TEXT,
    articles_list   TEXT,
    articles        INTEGER,
    montant         DOUBLE PRECISION,
    statut          VARCHAR(50) NOT NULL DEFAULT 'EN_ATTENTE'
);

-- Clients / Patients
CREATE TABLE IF NOT EXISTS clients (
    id               BIGSERIAL PRIMARY KEY,
    nom              VARCHAR(255) NOT NULL,
    telephone        VARCHAR(50),
    email            VARCHAR(255),
    adresse          TEXT,
    derniere_visite  DATE,
    nombre_achats    INTEGER NOT NULL DEFAULT 0,
    credit_total     DOUBLE PRECISION NOT NULL DEFAULT 0.0
);

-- Sessions de caisse (note: sessions_caisse est déjà utilisé par Ahmed, on crée caisse_sessions)
CREATE TABLE IF NOT EXISTS caisse_sessions (
    id               BIGSERIAL PRIMARY KEY,
    date_session     DATE,
    heure_ouverture  VARCHAR(10),
    heure_cloture    VARCHAR(10),
    fond_ouverture   DOUBLE PRECISION,
    fond_cloture     DOUBLE PRECISION,
    total_ventes     DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    statut           VARCHAR(50) NOT NULL DEFAULT 'OUVERTE'
);
