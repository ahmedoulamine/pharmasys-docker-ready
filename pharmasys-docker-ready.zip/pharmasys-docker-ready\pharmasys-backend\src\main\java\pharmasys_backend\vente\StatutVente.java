package pharmasys_backend.vente;

public enum StatutVente {
    COMPLETEE, ANNULEE, REMBOURSEE, EN_ATTENTE
}
