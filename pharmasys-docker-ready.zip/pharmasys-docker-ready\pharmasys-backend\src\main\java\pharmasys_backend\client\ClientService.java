package pharmasys_backend.client;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pharmasys_backend.vente.VenteService;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ClientService {

    private final ClientRepository clientRepository;
    private final VenteService     venteService;

    public List<Client> getAll(String search) {
        if (search != null && !search.isBlank()) {
            return clientRepository.findByNomContainingIgnoreCaseOrderByNomAsc(search);
        }
        return clientRepository.findAll();
    }

    public Client getById(Long id) {
        return clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client non trouvé: " + id));
    }

    public Map<String, Object> getStats() {
        long total       = clientRepository.count();
        long avecCredit  = clientRepository.countAvecCredit();
        Double creditTotal = clientRepository.sumCreditTotal();

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("total", total);
        stats.put("avecCredit", avecCredit);
        stats.put("creditTotal", creditTotal != null ? creditTotal : 0.0);
        return stats;
    }

    public Client create(Client client) {
        return clientRepository.save(client);
    }

    public Client update(Long id, Client updated) {
        Client existing = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client non trouvé: " + id));
        existing.setNom(updated.getNom());
        existing.setTelephone(updated.getTelephone());
        existing.setEmail(updated.getEmail());
        existing.setAdresse(updated.getAdresse());
        existing.setCreditTotal(updated.getCreditTotal());
        return clientRepository.save(existing);
    }

    public void delete(Long id) {
        clientRepository.deleteById(id);
    }

    public Client ajouterCredit(Long id, Double montant) {
        Client client = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client non trouvé: " + id));
        client.setCreditTotal(client.getCreditTotal() + montant);
        return clientRepository.save(client);
    }

    public Client mettreAJourVisite(Long id, boolean incrementerAchats) {
        Client client = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client non trouvé: " + id));
        client.setDerniereVisite(java.time.LocalDate.now());
        if (incrementerAchats) client.setNombreAchats(client.getNombreAchats() + 1);
        return clientRepository.save(client);
    }

    public Client payerCredit(Long id, Double montant) {
        Client client = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client non trouvé: " + id));
        venteService.marquerVentesPayees(client.getNom(), BigDecimal.valueOf(montant));
        double nouveau = Math.max(0, client.getCreditTotal() - montant);
        client.setCreditTotal(nouveau);
        return clientRepository.save(client);
    }
}
