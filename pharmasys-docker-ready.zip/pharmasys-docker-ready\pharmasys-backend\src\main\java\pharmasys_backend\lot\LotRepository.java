package pharmasys_backend.lot;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;

public interface LotRepository extends JpaRepository<Lot, Long> {

    @Query("""
        SELECT l FROM Lot l
        WHERE l.produit.id = :produitId
          AND l.statut = 'EN_STOCK'
          AND l.quantiteRestante > 0
        ORDER BY l.datePeremption ASC
    """)
    List<Lot> findFefoByProduit(@Param("produitId") Long produitId);

    List<Lot> findByProduitId(Long produitId);

    @Query("""
        SELECT l FROM Lot l
        WHERE l.statut = 'EN_STOCK'
          AND l.quantiteRestante > 0
          AND l.datePeremption < :today
        ORDER BY l.datePeremption ASC
    """)
    List<Lot> findExpiredInStock(@Param("today") LocalDate today);
}
