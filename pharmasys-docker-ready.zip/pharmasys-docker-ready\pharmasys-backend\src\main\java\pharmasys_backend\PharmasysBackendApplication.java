package pharmasys_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmasysBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PharmasysBackendApplication.class, args);
	}

}
