package pharmasys_backend.produit;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/produits")
public class ProduitController {

    private final ProduitService service;

    public ProduitController(ProduitService service) {
        this.service = service;
    }

    @GetMapping
    public Page<ProduitResponse> findAll(
            @RequestParam(name = "search", required = false) String search,
            @PageableDefault(size = 50, sort = "denomination") Pageable pageable) {
        return service.findAll(search, pageable);
    }

    @GetMapping("/{id}")
    public ProduitResponse findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PatchMapping("/{id}/stock")
    public ProduitResponse updateStock(
            @PathVariable Long id,
            @RequestBody Map<String, Object> body) {
        int quantite = Integer.parseInt(body.get("quantite").toString());
        String mode  = body.getOrDefault("mode", "SET").toString();
        return service.updateStock(id, quantite, mode);
    }

    @PatchMapping("/{id}/expiration")
    public ProduitResponse updateExpiration(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        String ds = body.get("dateExpiration");
        LocalDate date = (ds == null || ds.isBlank()) ? null : LocalDate.parse(ds);
        return service.updateExpiration(id, date);
    }
}
