package pharmasys_backend.caisse;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SessionCaisseRepository extends JpaRepository<SessionCaisse, Long> {
    List<SessionCaisse> findByStatut(StatutCaisse statut);
    List<SessionCaisse> findAllByOrderByDateSessionDesc();
}
