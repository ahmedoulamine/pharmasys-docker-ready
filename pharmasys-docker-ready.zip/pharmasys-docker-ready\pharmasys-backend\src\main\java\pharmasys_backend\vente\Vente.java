package pharmasys_backend.vente;

import jakarta.persistence.*;
import pharmasys_backend.utilisateur.Utilisateur;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ventes")
public class Vente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "numero_vente", nullable = false, unique = true, length = 30)
    private String numeroVente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "caissier_id", nullable = false)
    private Utilisateur caissier;

    @Column(name = "date_vente", nullable = false)
    private LocalDateTime dateVente = LocalDateTime.now();

    @Column(name = "total_ht", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalHt = BigDecimal.ZERO;

    @Column(name = "total_tva", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalTva = BigDecimal.ZERO;

    @Column(name = "total_ttc", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalTtc = BigDecimal.ZERO;

    @Column(name = "montant_recu", nullable = false, precision = 10, scale = 2)
    private BigDecimal montantRecu = BigDecimal.ZERO;

    @Column(name = "rendu_monnaie", nullable = false, precision = 10, scale = 2)
    private BigDecimal renduMonnaie = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(name = "mode_paiement", nullable = false, columnDefinition = "mode_paiement")
    private ModePaiement modePaiement = ModePaiement.ESPECES;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, columnDefinition = "statut_vente")
    private StatutVente statut = StatutVente.COMPLETEE;

    @Column(name = "patient_nom", length = 200)
    private String patientNom;

    @Column(name = "tpe_reference", length = 20)
    private String tpeReference;

    @Column(name = "tpe_autorisation", length = 10)
    private String tpeAutorisation;

    @Column(name = "tpe_carte", length = 30)
    private String tpeCarte;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @OneToMany(mappedBy = "vente", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LigneVente> lignes = new ArrayList<>();

    public Long getId() { return id; }
    public String getNumeroVente() { return numeroVente; }
    public Utilisateur getCaissier() { return caissier; }
    public LocalDateTime getDateVente() { return dateVente; }
    public BigDecimal getTotalHt() { return totalHt; }
    public BigDecimal getTotalTva() { return totalTva; }
    public BigDecimal getTotalTtc() { return totalTtc; }
    public BigDecimal getMontantRecu() { return montantRecu; }
    public BigDecimal getRenduMonnaie() { return renduMonnaie; }
    public ModePaiement getModePaiement() { return modePaiement; }
    public StatutVente getStatut() { return statut; }
    public String getPatientNom()     { return patientNom; }
    public String getTpeReference()   { return tpeReference; }
    public String getTpeAutorisation(){ return tpeAutorisation; }
    public String getTpeCarte()       { return tpeCarte; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public List<LigneVente> getLignes() { return lignes; }

    public void setNumeroVente(String n)        { this.numeroVente = n; }
    public void setCaissier(Utilisateur c)      { this.caissier = c; }
    public void setDateVente(LocalDateTime d)   { this.dateVente = d; }
    public void setTotalHt(BigDecimal t)        { this.totalHt = t; }
    public void setTotalTva(BigDecimal t)       { this.totalTva = t; }
    public void setTotalTtc(BigDecimal t)       { this.totalTtc = t; }
    public void setMontantRecu(BigDecimal m)    { this.montantRecu = m; }
    public void setRenduMonnaie(BigDecimal r)   { this.renduMonnaie = r; }
    public void setModePaiement(ModePaiement m) { this.modePaiement = m; }
    public void setStatut(StatutVente s)        { this.statut = s; }
    public void setPatientNom(String p)         { this.patientNom = p; }
    public void setTpeReference(String r)       { this.tpeReference = r; }
    public void setTpeAutorisation(String a)    { this.tpeAutorisation = a; }
    public void setTpeCarte(String c)           { this.tpeCarte = c; }
    public void setLignes(List<LigneVente> l)   { this.lignes = l; }
}
