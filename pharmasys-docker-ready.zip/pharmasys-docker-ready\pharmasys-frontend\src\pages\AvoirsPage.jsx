import { useEffect, useState } from "react";
import "./RetoursPage.css";
import { getAllRetours, createRetourApi, approveRetourApi, refundRetourApi } from "../services/retourService";
import { Search, CalendarDays } from "lucide-react";
import { getAllProducts } from "../services/productService";

const EMPTY_ARTICLE = { selected: false, productId: "", name: "", lot: "", quantite: 1, prix: 0 };

const EMPTY_FORM = {
  fournisseur: "", client: "", motif: "", commentaire: "",
  articles: [{ ...EMPTY_ARTICLE }],
};

export default function AvoirsPage() {
  const [tab, setTab]                       = useState("fournisseur"); // "fournisseur" | "client"
  const [search, setSearch]                 = useState("");
  const [filter, setFilter]                 = useState("Tous");
  const [showModal, setShowModal]           = useState(false);
  const [selectedAvoir, setSelectedAvoir]   = useState(null);
  const [avoirs, setAvoirs]                 = useState([]);
  const [message, setMessage]               = useState("");
  const [formError, setFormError]           = useState("");
  const [suggestionsByIndex, setSuggestionsByIndex] = useState({});
  const [form, setForm]                     = useState({ ...EMPTY_FORM });

  // ─── data ────────────────────────────────────────────────────────────────
  const loadAvoirs = async () => {
    try {
      const res = await getAllRetours();
      setAvoirs(res.data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => { loadAvoirs(); }, []);

  // ─── split by type ────────────────────────────────────────────────────────
  const fournisseurAvoirs = avoirs.filter(a => !a.reference?.startsWith("CLI-"));
  const clientAvoirs      = avoirs.filter(a =>  a.reference?.startsWith("CLI-"));
  const list              = tab === "fournisseur" ? fournisseurAvoirs : clientAvoirs;

  const filtered = list.filter(a => {
    const ref    = (a.reference   || "").toLowerCase();
    const tiers  = (a.fournisseur || "").toLowerCase();
    const statut = (a.statut      || "");
    const q      = search.toLowerCase();
    return (ref.includes(q) || tiers.includes(q)) && (filter === "Tous" || statut === filter);
  });

  // ─── stats ────────────────────────────────────────────────────────────────
  const totalMois  = list.reduce((s, a) => s + (a.montant ?? 0), 0);
  const enAttente  = list.filter(a => a.statut === "En attente").length;
  const approuves  = list.filter(a => a.statut === "Approuvé").length;
  const rembourses = list.filter(a => a.statut === "Remboursé").length;

  // ─── search médicaments ───────────────────────────────────────────────────
  const searchMedicaments = async (text, index) => {
    if (text.trim().length < 2) { setSuggestionsByIndex(p => ({ ...p, [index]: [] })); return; }
    try {
      const res = await getAllProducts(0, 10, text);
      setSuggestionsByIndex(p => ({ ...p, [index]: res.data.content || [] }));
    } catch (e) { console.error(e); }
  };

  const updateArticle = (index, field, value) => {
    const updated = [...form.articles];
    updated[index] = { ...updated[index], [field]: value };
    setForm(f => ({ ...f, articles: updated }));
  };

  const selectProduct = (index, product) => {
    const updated = [...form.articles];
    updated[index] = { ...updated[index], selected: true, productId: product.id, name: product.name, lot: product.barcode || "", prix: product.price || 0, quantite: 1 };
    setForm(f => ({ ...f, articles: updated }));
    setSuggestionsByIndex(p => ({ ...p, [index]: [] }));
  };

  // ─── create avoir ─────────────────────────────────────────────────────────
  const createAvoir = async () => {
    const articles = form.articles.filter(a => a.selected);
    const tiers    = tab === "fournisseur" ? form.fournisseur : form.client;

    if (!tiers || !form.motif) { setFormError("Veuillez remplir tous les champs obligatoires."); return; }
    if (articles.length === 0) { setFormError("Veuillez sélectionner au moins un article."); return; }
    setFormError("");

    const count = (tab === "fournisseur" ? fournisseurAvoirs : clientAvoirs).length;
    const prefix = tab === "fournisseur" ? "FOUR" : "CLI";
    const montant = articles.reduce((s, a) => s + a.quantite * a.prix, 0);

    const payload = {
      reference:   `${prefix}-2026-${count + 1}`,
      fournisseur: tiers,
      dateRetour:  new Date().toISOString().split("T")[0],
      motif:       form.motif,
      articles:    articles.length,
      articlesList: JSON.stringify(articles),
      montant,
      statut: "En attente",
    };

    try {
      await createRetourApi(payload);
      await loadAvoirs();
      setShowModal(false);
      setFormError("");
      setForm({ ...EMPTY_FORM, articles: [{ ...EMPTY_ARTICLE }] });
      setMessage(`✅ Avoir ${tab === "fournisseur" ? "fournisseur" : "client"} créé avec succès`);
      setTimeout(() => setMessage(""), 3000);
    } catch (e) {
      console.error(e);
      setFormError("Erreur lors de la création de l'avoir.");
    }
  };

  const approveAvoir = async (id) => {
    try { await approveRetourApi(id); await loadAvoirs(); setSelectedAvoir(null); } catch (e) { console.error(e); }
  };

  const refundAvoir = async (id) => {
    try { await refundRetourApi(id); await loadAvoirs(); setSelectedAvoir(null); } catch (e) { console.error(e); }
  };

  const openModal = () => {
    setForm({ ...EMPTY_FORM, articles: [{ ...EMPTY_ARTICLE }] });
    setFormError("");
    setShowModal(true);
  };

  const tiersLabel = tab === "fournisseur" ? "Fournisseur" : "Client";

  // ─── render ───────────────────────────────────────────────────────────────
  return (
    <div className="retours-page">
      {message && <div className="success-message">{message}</div>}

      {/* Header */}
      <div className="retours-title-row">
        <div>
          <h1>Avoirs</h1>
          <p>Gestion des retours fournisseurs et clients</p>
        </div>
        <button className="new-retour-btn" onClick={openModal}>+ Nouvel Avoir</button>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 12, marginBottom: 28 }}>
        <button
          onClick={() => { setTab("fournisseur"); setFilter("Tous"); setSearch(""); }}
          style={{
            padding: "12px 28px", borderRadius: 12, fontWeight: "bold", fontSize: 16, cursor: "pointer", border: "none",
            background: tab === "fournisseur" ? "#10b981" : "#f3f4f6",
            color:      tab === "fournisseur" ? "white"    : "#374151",
          }}
        >
          Avoirs Fournisseurs ({fournisseurAvoirs.length})
        </button>
        <button
          onClick={() => { setTab("client"); setFilter("Tous"); setSearch(""); }}
          style={{
            padding: "12px 28px", borderRadius: 12, fontWeight: "bold", fontSize: 16, cursor: "pointer", border: "none",
            background: tab === "client" ? "#10b981" : "#f3f4f6",
            color:      tab === "client" ? "white"    : "#374151",
          }}
        >
          Avoirs Clients ({clientAvoirs.length})
        </button>
      </div>

      {/* Stats */}
      <div className="retours-cards">
        <div className="retour-card"><p>Total du mois</p><h2>{totalMois.toLocaleString("fr-FR")} DH</h2></div>
        <div className="retour-card"><p>En attente</p><h2 className="orange">{enAttente}</h2></div>
        <div className="retour-card"><p>Approuvés</p><h2 className="blue">{approuves}</h2></div>
        <div className="retour-card"><p>Remboursés</p><h2 className="green">{rembourses}</h2></div>
      </div>

      {/* Filters */}
      <div className="retours-filter-card">
        <div className="search-box">
          <Search size={24} className="search-icon" />
          <input
            type="text"
            placeholder={`Rechercher par ${tab === "fournisseur" ? "fournisseur" : "client"} ou référence...`}
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        {["Tous", "En attente", "Approuvé", "Remboursé"].map(f => (
          <button
            key={f}
            className={`filter-btn ${filter === f ? (f === "Tous" ? "active-green" : f === "En attente" ? "active-orange" : f === "Approuvé" ? "active-blue" : "active-green") : ""}`}
            onClick={() => setFilter(f)}
          >
            {f === "Approuvé" ? "Approuvés" : f === "Remboursé" ? "Remboursés" : f}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="retours-table-card">
        <table>
          <thead>
            <tr>
              <th>Référence</th>
              <th>{tiersLabel}</th>
              <th>Date</th>
              <th>Motif</th>
              <th>Articles</th>
              <th>Montant</th>
              <th>Statut</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={8} style={{ textAlign: "center", color: "#9ca3af", padding: 40 }}>Aucun avoir trouvé</td></tr>
            ) : filtered.map(a => (
              <tr key={a.id}>
                <td>{a.reference}</td>
                <td>{a.fournisseur}</td>
                <td><div className="date-cell"><CalendarDays size={18} /><span>{a.dateRetour}</span></div></td>
                <td>{a.motif}</td>
                <td>{a.articles} article(s)</td>
                <td>{(a.montant ?? 0).toLocaleString("fr-FR")} DH</td>
                <td>
                  <span className={a.statut === "En attente" ? "status waiting" : a.statut === "Approuvé" ? "status approved" : "status refunded"}>
                    {a.statut}
                  </span>
                </td>
                <td><span className="details-btn" onClick={() => setSelectedAvoir(a)}>Détails</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal — Nouvel avoir */}
      {showModal && (
        <div className="modal-overlay">
          <div className="retour-modal">
            <h2>Nouvel Avoir {tab === "fournisseur" ? "Fournisseur" : "Client"}</h2>

            <div className="modal-row">
              <div>
                <label>{tiersLabel}</label>
                {tab === "fournisseur" ? (
                  <select value={form.fournisseur} onChange={e => setForm(f => ({ ...f, fournisseur: e.target.value }))}>
                    <option value="">Sélectionner un fournisseur</option>
                    <option value="Laboratoire SOTHEMA">Laboratoire SOTHEMA</option>
                    <option value="Pharma 5">Pharma 5</option>
                    <option value="Cooper Pharma">Cooper Pharma</option>
                  </select>
                ) : (
                  <input
                    type="text"
                    placeholder="Nom du client"
                    value={form.client}
                    onChange={e => setForm(f => ({ ...f, client: e.target.value }))}
                    style={{ width: "100%", padding: "16px", borderRadius: "12px", border: "1px solid #d1d5db", fontSize: "16px" }}
                  />
                )}
              </div>
              <div>
                <label>Motif du retour</label>
                <select value={form.motif} onChange={e => setForm(f => ({ ...f, motif: e.target.value }))}>
                  <option value="">Sélectionner un motif</option>
                  {tab === "fournisseur" ? (
                    <>
                      <option value="Produit endommagé">Produit endommagé</option>
                      <option value="Produit périmé">Produit périmé</option>
                      <option value="Mauvais article">Mauvais article</option>
                      <option value="Erreur de livraison">Erreur de livraison</option>
                    </>
                  ) : (
                    <>
                      <option value="Produit non conforme">Produit non conforme</option>
                      <option value="Erreur de délivrance">Erreur de délivrance</option>
                      <option value="Produit endommagé">Produit endommagé</option>
                      <option value="Ordonnance annulée">Ordonnance annulée</option>
                    </>
                  )}
                </select>
              </div>
            </div>

            <label>Commentaire</label>
            <textarea
              placeholder="Détails du retour..."
              value={form.commentaire}
              onChange={e => setForm(f => ({ ...f, commentaire: e.target.value }))}
            />

            <h3>Articles à retourner</h3>
            {form.articles.map((article, index) => (
              <div className="return-item" key={index}>
                <input
                  type="checkbox"
                  checked={article.selected}
                  onChange={e => updateArticle(index, "selected", e.target.checked)}
                />
                <div className="return-info">
                  <div className="medicine-search">
                    <input
                      type="text"
                      placeholder="Nom du médicament..."
                      value={article.name}
                      onChange={e => {
                        const val = e.target.value;
                        updateArticle(index, "name", val);
                        const found = suggestionsByIndex[index]?.find(p => p.name === val);
                        if (found) selectProduct(index, found);
                        else searchMedicaments(val, index);
                      }}
                    />
                    {suggestionsByIndex[index]?.length > 0 && (
                      <div className="medicine-suggestions">
                        {suggestionsByIndex[index].map(p => (
                          <div key={p.id} className="medicine-suggestion-item" onClick={() => selectProduct(index, p)}>
                            <strong>{p.name}</strong>
                            <span>{p.dosage}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <input
                    type="text"
                    placeholder="Lot"
                    value={article.lot}
                    onChange={e => updateArticle(index, "lot", e.target.value)}
                  />
                </div>
                <div className="return-qty">
                  <label>Quantité</label>
                  <input type="number" value={article.quantite} min={1} onChange={e => updateArticle(index, "quantite", Number(e.target.value))} />
                </div>
                <div className="return-price">
                  <label>Prix</label>
                  <input type="number" value={article.prix} min={0} onChange={e => updateArticle(index, "prix", Number(e.target.value))} />
                </div>
                <div className="return-total">
                  <label>Total</label>
                  <strong>{(article.quantite * article.prix).toLocaleString("fr-FR")} DH</strong>
                </div>
                <button onClick={() => setForm(f => ({ ...f, articles: f.articles.filter((_, i) => i !== index) }))}>❌</button>
              </div>
            ))}

            <button onClick={() => setForm(f => ({ ...f, articles: [...f.articles, { ...EMPTY_ARTICLE }] }))}>
              + Ajouter médicament
            </button>

            {formError && (
              <div style={{ background: "#fee2e2", border: "1px solid #fca5a5", color: "#dc2626", borderRadius: 10, padding: "12px 16px", fontSize: 14, marginBottom: 8 }}>
                {formError}
              </div>
            )}
            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setShowModal(false)}>Annuler</button>
              <button className="create-btn" onClick={createAvoir}>Créer l'avoir</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal — Détails */}
      {selectedAvoir && (
        <div className="modal-overlay">
          <div className="retour-modal">
            <div className="modal-header">
              <h2>Détails de l'avoir</h2>
              <span className={selectedAvoir.statut === "En attente" ? "status waiting" : selectedAvoir.statut === "Approuvé" ? "status approved" : "status refunded"}>
                {selectedAvoir.statut}
              </span>
            </div>
            <div className="modal-info-grid">
              <div><p>Référence</p><h3>{selectedAvoir.reference}</h3></div>
              <div><p>{selectedAvoir.reference?.startsWith("CLI-") ? "Client" : "Fournisseur"}</p><h3>{selectedAvoir.fournisseur}</h3></div>
              <div><p>Date</p><h3>{selectedAvoir.dateRetour}</h3></div>
              <div><p>Motif</p><h3>{selectedAvoir.motif}</h3></div>
            </div>
            <div className="motif-box">
              <h3>⚠️ Motif du retour</h3>
              <p>{selectedAvoir.motif}</p>
            </div>
            <h3 className="articles-title">Articles retournés</h3>
            {(() => {
              try {
                const raw    = selectedAvoir.articlesList;
                const parsed = typeof raw === "string" ? JSON.parse(raw || "[]") : (raw || []);
                return (Array.isArray(parsed) ? parsed : []).map((a, i) => (
                  <div className="returned-item" key={i}>
                    <div><h3>{a.name}</h3><p>Lot : {a.lot} • Quantité : {a.quantite}</p></div>
                    <strong>{((a.quantite ?? 0) * (a.prix ?? 0)).toLocaleString("fr-FR")} DH</strong>
                  </div>
                ));
              } catch { return null; }
            })()}
            <div className="modal-total">
              <h2>Montant total</h2>
              <h2>{(selectedAvoir.montant ?? 0).toLocaleString("fr-FR")} DH</h2>
            </div>
            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setSelectedAvoir(null)}>Fermer</button>
              {selectedAvoir.statut === "En attente" && (
                <button className="create-btn" onClick={() => approveAvoir(selectedAvoir.id)}>Approuver</button>
              )}
              {selectedAvoir.statut === "Approuvé" && (
                <button className="create-btn" onClick={() => refundAvoir(selectedAvoir.id)}>Marquer remboursé</button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
