import { useState, useEffect, useCallback, useRef } from 'react'
import { useApp } from '../context/AppContext'
import { searchMedicaments, fetchClients } from '../services/api'
import {
  Search, Plus, Minus, Trash2, Scan,
  CheckCircle, CreditCard, Banknote, AlertTriangle, XCircle, User, Clock,
} from 'lucide-react'

const PAYMENT_MODES = [
  { key: 'Espèces', icon: Banknote,    label: 'Espèces' },
  { key: 'Carte',   icon: CreditCard,  label: 'Carte'   },
  { key: 'Crédit',  icon: Clock,       label: 'Crédit'  },
]

const SIMULATED_CARDS = [
  'Visa •••• 4821', 'Mastercard •••• 3729',
  'Visa •••• 0952', 'Mastercard •••• 6174',
]

function generateTpeData() {
  return {
    ref:  'TXN-' + Math.random().toString(36).substring(2, 6).toUpperCase(),
    auth: String(Math.floor(100000 + Math.random() * 900000)),
    card: SIMULATED_CARDS[Math.floor(Math.random() * SIMULATED_CARDS.length)],
  }
}

function TPEModal({ open, phase, data, totalTTC, onValidate, onRefuse, onRetry, onClose }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
              <CreditCard className="w-4 h-4 text-blue-600" />
            </div>
            <span className="font-semibold text-gray-800">Paiement par carte</span>
          </div>
          {phase !== 'waiting' && (
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
              <XCircle className="w-5 h-5" />
            </button>
          )}
        </div>
        <div className="p-5 space-y-4">
          <div className="flex items-center justify-between bg-gray-50 rounded-xl px-4 py-3">
            <span className="text-sm text-gray-500">Montant</span>
            <span className="text-xl font-bold text-gray-800">{totalTTC.toFixed(2)} DH</span>
          </div>
          {phase === 'waiting' && (
            <>
              <div className="flex flex-col items-center gap-3 py-6">
                <div className="w-16 h-16 border-4 border-gray-200 border-t-blue-500 rounded-full animate-spin" />
                <p className="font-semibold text-gray-700 text-center">En attente du TPE...</p>
                <p className="text-xs text-gray-400 text-center leading-relaxed">
                  Le client doit insérer sa carte<br />et saisir son code PIN
                </p>
              </div>
              <button onClick={onRefuse}
                className="w-full py-2.5 text-sm text-orange-600 border border-orange-200 rounded-xl hover:bg-orange-50 transition-colors font-medium">
                Simuler un refus
              </button>
              <button onClick={onClose}
                className="w-full py-2.5 text-sm text-gray-500 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                Annuler
              </button>
            </>
          )}
          {phase === 'approved' && (
            <>
              <div className="bg-green-50 border border-green-200 rounded-xl p-4 space-y-2.5">
                <div className="flex items-center gap-2 text-green-700 font-semibold">
                  <CheckCircle className="w-4 h-4" /> Paiement approuvé
                </div>
                <div className="flex justify-between text-sm pt-1">
                  <span className="text-gray-500">Référence</span>
                  <span className="font-mono font-semibold text-gray-800">{data.ref}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Autorisation</span>
                  <span className="font-mono font-semibold text-gray-800">{data.auth}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Carte</span>
                  <span className="font-mono font-semibold text-gray-800">{data.card}</span>
                </div>
              </div>
              <button onClick={onValidate}
                className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold text-sm transition-colors">
                Valider la vente
              </button>
            </>
          )}
          {phase === 'refused' && (
            <>
              <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex flex-col items-center gap-2 py-6">
                <XCircle className="w-10 h-10 text-red-400" />
                <p className="font-semibold text-red-700">Paiement refusé</p>
                <p className="text-xs text-red-400 text-center">Transaction refusée par la banque émettrice</p>
              </div>
              <button onClick={onRetry}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-sm transition-colors">
                Réessayer
              </button>
              <button onClick={onClose}
                className="w-full py-2.5 text-sm text-gray-500 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                Annuler
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default function SalesPOS() {
  const { validateSale } = useApp()
  const [search, setSearch]           = useState('')
  const [barcode, setBarcode]         = useState('')
  const [results, setResults]         = useState([])
  const [loading, setLoading]         = useState(false)
  const [cart, setCart]               = useState([])
  const [paymentMode, setPaymentMode] = useState('Espèces')
  const [amountGiven, setAmountGiven] = useState('')
  const [success, setSuccess]         = useState(false)
  const [submitting, setSubmitting]   = useState(false)
  const [error, setError]             = useState('')
  const debounceRef = useRef(null)

  // Patient autocomplete
  const [patientNom, setPatientNom]                   = useState('')
  const [patientSuggestions, setPatientSuggestions]   = useState([])
  const [showSuggestions, setShowSuggestions]         = useState(false)
  const patientDebounceRef = useRef(null)

  // TPE state
  const [tpeOpen, setTpeOpen]   = useState(false)
  const [tpePhase, setTpePhase] = useState('waiting')
  const [tpeData, setTpeData]   = useState(null)
  const tpeTimerRef = useRef(null)

  const doSearch = useCallback(async (query) => {
    setLoading(true)
    try { setResults(await searchMedicaments(query)) }
    catch { setResults([]) }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { doSearch('') }, [doSearch])

  useEffect(() => {
    clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => doSearch(search), 300)
    return () => clearTimeout(debounceRef.current)
  }, [search, doSearch])

  useEffect(() => () => {
    clearTimeout(tpeTimerRef.current)
    clearTimeout(patientDebounceRef.current)
  }, [])

  useEffect(() => {
    clearTimeout(patientDebounceRef.current)
    if (patientNom.trim().length < 1) { setPatientSuggestions([]); return }
    patientDebounceRef.current = setTimeout(async () => {
      const clients = await fetchClients(patientNom)
      setPatientSuggestions(clients.slice(0, 6))
    }, 300)
  }, [patientNom])

  // Si on passe en mode Crédit, vider le patient pour forcer la resaisie
  useEffect(() => {
    if (paymentMode !== 'Crédit') return
    // Mode crédit sélectionné : s'assurer que le champ patient est visible
  }, [paymentMode])

  async function handleBarcode(e) {
    if (e.key !== 'Enter' || !barcode.trim()) return
    const data = await searchMedicaments(barcode.trim())
    const product = data.find(p => p.codeEan13 === barcode.trim())
    if (product) addToCart(product)
    setBarcode('')
  }

  function addToCart(product) {
    if (product.stock === 0) return
    setCart(prev => {
      const existing = prev.find(i => i.id === product.id)
      if (existing) {
        if (existing.qty >= product.stock) return prev
        return prev.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i)
      }
      return [...prev, { ...product, qty: 1 }]
    })
  }

  function setQty(id, qty) {
    const product = cart.find(i => i.id === id)
    if (qty <= 0) setCart(prev => prev.filter(i => i.id !== id))
    else if (qty <= (product?.stock ?? 999))
      setCart(prev => prev.map(i => i.id === id ? { ...i, qty } : i))
  }

  function removeFromCart(id) {
    setCart(prev => prev.filter(i => i.id !== id))
  }

  const totalTTC = cart.reduce((s, i) => s + i.prixVente * i.qty, 0)
  const rendu    = paymentMode === 'Espèces' && parseFloat(amountGiven) > totalTTC
                   ? parseFloat(amountGiven) - totalTTC : 0

  // Validation : le mode Crédit exige un patient
  const creditSansPatient = paymentMode === 'Crédit' && !patientNom.trim()

  async function doValidateSale(tpe = null) {
    setSubmitting(true)
    setError('')
    try {
      const montantRecu = paymentMode === 'Espèces' && parseFloat(amountGiven) >= totalTTC
        ? parseFloat(amountGiven)
        : totalTTC
      await validateSale(cart, {
        mode: paymentMode,
        total: totalTTC,
        montantRecu,
        tpe,
        patientNom: patientNom.trim() || null,
      })
      setCart([])
      setAmountGiven('')
      setPatientNom('')
      setPatientSuggestions([])
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err.message || "Impossible d'enregistrer la vente.")
    } finally {
      setSubmitting(false)
    }
  }

  function handleValidate() {
    if (cart.length === 0 || submitting) return

    if (creditSansPatient) {
      setError('Le mode Crédit exige la sélection d\'un patient.')
      return
    }
    setError('')

    if (paymentMode === 'Carte') {
      setTpeData(generateTpeData())
      setTpePhase('waiting')
      setTpeOpen(true)
      tpeTimerRef.current = setTimeout(() => setTpePhase('approved'), 3000)
      return
    }

    doValidateSale()
  }

  function handleTPERefuse() { clearTimeout(tpeTimerRef.current); setTpePhase('refused') }
  function handleTPERetry()  { setTpeData(generateTpeData()); setTpePhase('waiting'); tpeTimerRef.current = setTimeout(() => setTpePhase('approved'), 3000) }
  function handleTPEClose()  { clearTimeout(tpeTimerRef.current); setTpeOpen(false); setTpePhase('waiting') }
  async function handleTPEValidate() { setTpeOpen(false); await doValidateSale(tpeData) }

  const lowStockInCart = cart.filter(i => i.stock - i.qty <= i.seuilAlerte)

  return (
    <div className="flex h-[calc(100vh-64px)] overflow-hidden bg-gray-50">

      <TPEModal open={tpeOpen} phase={tpePhase} data={tpeData} totalTTC={totalTTC}
        onValidate={handleTPEValidate} onRefuse={handleTPERefuse}
        onRetry={handleTPERetry} onClose={handleTPEClose} />

      {/* Catalogue */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="m-4 mb-0 bg-green-600 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <Scan className="w-5 h-5 text-white" />
            <span className="text-white font-semibold text-sm">Scanner Code-barres</span>
          </div>
          <input type="text" value={barcode} onChange={e => setBarcode(e.target.value)}
            onKeyDown={handleBarcode} placeholder="Scanner ou saisir le code EAN13..."
            className="w-full bg-green-700/40 border border-green-500 rounded-xl px-4 py-3 text-green-100 placeholder-green-300 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-green-300" />
        </div>

        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Rechercher un médicament (nom, DCI, classe)..."
              className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent" />
            {loading && <div className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 border-2 border-green-500 border-t-transparent rounded-full animate-spin" />}
          </div>
          <p className="text-xs text-gray-400 mt-1 ml-1">{results.length} résultat(s) — tape pour filtrer</p>
        </div>

        <div className="flex-1 overflow-y-auto px-4 pb-4">
          {results.length === 0 && !loading ? (
            <div className="text-center py-16 text-gray-400">
              <Search className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">Aucun médicament trouvé</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {results.map(product => (
                <div key={product.id} onClick={() => addToCart(product)}
                  className={`bg-white rounded-xl border p-4 transition-all ${
                    product.stock === 0
                      ? 'opacity-50 cursor-not-allowed border-gray-100'
                      : 'cursor-pointer hover:border-green-400 hover:shadow-sm border-gray-200'
                  }`}>
                  <p className="font-semibold text-gray-800 text-sm leading-tight truncate">{product.nom}</p>
                  <p className="text-xs text-gray-400 truncate">{product.formeDosage}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-green-600 font-bold text-base">{product.prixVente.toFixed(2)} DH</span>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      product.stock === 0       ? 'bg-red-100 text-red-600'    :
                      product.stock <= product.seuilAlerte ? 'bg-orange-100 text-orange-600' :
                      'bg-green-100 text-green-700'}`}>
                      Stock: {product.stock}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Panier */}
      <div className="w-80 flex flex-col bg-white border-l border-gray-100">
        <div className="px-5 py-4 border-b border-gray-100">
          <h2 className="font-semibold text-gray-800">Panier ({cart.length})</h2>
        </div>

        <div className="flex-1 overflow-y-auto">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full gap-2">
              <Scan className="w-12 h-12 text-gray-200" />
              <p className="text-sm text-gray-400 font-medium">Panier vide</p>
              <p className="text-xs text-gray-300">Cliquer sur un produit pour commencer</p>
            </div>
          ) : (
            <div className="p-4 space-y-2">
              {cart.map(item => (
                <div key={item.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{item.nom}</p>
                    <p className="text-xs text-gray-400">{item.prixVente.toFixed(2)} DH / unité</p>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <button onClick={() => setQty(item.id, item.qty - 1)}
                      className="w-6 h-6 rounded-lg bg-white border border-gray-200 text-gray-600 hover:border-red-300 hover:text-red-500 flex items-center justify-center transition-colors">
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-7 text-center text-sm font-semibold text-gray-800">{item.qty}</span>
                    <button onClick={() => setQty(item.id, item.qty + 1)}
                      className="w-6 h-6 rounded-lg bg-white border border-gray-200 text-gray-600 hover:border-green-300 hover:text-green-600 flex items-center justify-center transition-colors">
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="text-right flex-shrink-0 min-w-[56px]">
                    <p className="text-sm font-bold text-gray-800">{(item.prixVente * item.qty).toFixed(2)} DH</p>
                  </div>
                  <button onClick={() => removeFromCart(item.id)}
                    className="text-gray-300 hover:text-red-500 transition-colors flex-shrink-0">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {lowStockInCart.length > 0 && (
          <div className="mx-4 mb-2 p-3 bg-orange-50 border border-orange-200 rounded-xl flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-orange-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-orange-700">Stock faible : {lowStockInCart.map(i => i.nom).join(', ')}</p>
          </div>
        )}

        <div className="border-t border-gray-100 p-4 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-lg font-bold text-gray-900">Total</span>
            <span className="text-xl font-bold text-green-600">{totalTTC.toFixed(2)} DH</span>
          </div>

          {/* Patient */}
          <div className="relative">
            <p className="text-sm text-gray-500 mb-1.5">
              Patient {paymentMode === 'Crédit' ? <span className="text-red-500 font-semibold">*obligatoire*</span> : '(optionnel)'}
            </p>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input type="text" value={patientNom}
                onChange={e => { setPatientNom(e.target.value); setShowSuggestions(true) }}
                onFocus={() => setShowSuggestions(true)}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
                placeholder="Nom du patient..."
                className={`w-full pl-9 pr-3 py-2.5 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 ${
                  creditSansPatient ? 'border-red-300 bg-red-50' : 'border-gray-200'
                }`}
              />
            </div>
            {showSuggestions && patientSuggestions.length > 0 && (
              <div className="absolute bottom-full mb-1 left-0 right-0 bg-white border border-gray-200 rounded-xl shadow-lg z-20 overflow-hidden">
                {patientSuggestions.map(c => (
                  <button key={c.id} type="button"
                    onMouseDown={() => { setPatientNom(c.nom); setShowSuggestions(false); setPatientSuggestions([]) }}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-green-50 flex items-center gap-2">
                    <span className="font-medium text-gray-800">{c.nom}</span>
                    {c.telephone && <span className="text-gray-400 text-xs">{c.telephone}</span>}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Mode de paiement */}
          <div>
            <p className="text-sm text-gray-500 mb-2">Mode de paiement</p>
            <div className="flex gap-2">
              {PAYMENT_MODES.map(({ key, icon: Icon, label }) => (
                <button key={key} onClick={() => setPaymentMode(key)}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-xs font-medium transition-all ${
                    paymentMode === key
                      ? key === 'Crédit'
                        ? 'bg-orange-500 border-orange-500 text-white'
                        : 'bg-green-600 border-green-600 text-white'
                      : 'border-gray-200 text-gray-600 hover:border-green-300'
                  }`}>
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Info Crédit */}
          {paymentMode === 'Crédit' && cart.length > 0 && (
            <div className="flex items-start gap-2 px-3 py-2 bg-orange-50 border border-orange-200 rounded-xl">
              <Clock className="w-4 h-4 text-orange-500 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-orange-700">
                La vente sera enregistrée mais <b>le montant ne sera pas encaissé</b>.
                Il sera ajouté au crédit du patient et visible dans les rapports sous "Ventes à crédit".
              </p>
            </div>
          )}

          {paymentMode === 'Espèces' && cart.length > 0 && (
            <div className="space-y-1.5">
              <input type="number" value={amountGiven} onChange={e => setAmountGiven(e.target.value)}
                placeholder="Montant reçu (DH)" min={totalTTC}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 text-right" />
              {rendu > 0 && (
                <div className="flex justify-between text-sm font-semibold text-green-700 bg-green-50 px-3 py-2 rounded-xl">
                  <span>Rendu monnaie</span>
                  <span>{rendu.toFixed(2)} DH</span>
                </div>
              )}
            </div>
          )}

          {paymentMode === 'Carte' && cart.length > 0 && (
            <div className="flex items-center gap-2 px-3 py-2 bg-blue-50 border border-blue-100 rounded-xl">
              <CreditCard className="w-4 h-4 text-blue-500 flex-shrink-0" />
              <p className="text-xs text-blue-600">La modale TPE s'ouvrira au moment de la validation</p>
            </div>
          )}

          {error && (
            <div className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
              {error}
            </div>
          )}

          {success ? (
            <div className="flex items-center justify-center gap-2 py-3 bg-green-50 text-green-700 rounded-xl font-semibold text-sm">
              <CheckCircle className="w-5 h-5" />
              Vente enregistrée !
            </div>
          ) : (
            <button onClick={handleValidate}
              disabled={cart.length === 0 || submitting || creditSansPatient}
              className="w-full py-3 rounded-xl font-semibold text-sm transition-colors disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed enabled:bg-green-600 enabled:hover:bg-green-700 enabled:text-white">
              {submitting       ? 'Enregistrement...' :
               paymentMode === 'Carte'  ? 'Envoyer au TPE' :
               paymentMode === 'Crédit' ? 'Valider (mise en crédit)' :
               'Valider la vente'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
