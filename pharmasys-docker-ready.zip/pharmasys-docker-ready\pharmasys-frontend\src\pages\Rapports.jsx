import { useState, useEffect, useRef } from "react";
import axiosInstance from "../api/axios.js";
import {
    LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
    PieChart, Pie, Cell, BarChart, Bar, Legend, CartesianGrid
} from "recharts";

const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#8b5cf6", "#ef4444"];

export default function Rapports() {
    const [periode, setPeriode]       = useState("annee");
    const [stats, setStats]           = useState(null);
    const [mensuelles, setMensuelles] = useState([]);
    const [categories, setCategories] = useState([]);
    const [topProduits, setTopProduits] = useState([]);
    const [perfHebdo, setPerfHebdo]   = useState([]);
    const [loading, setLoading]       = useState(true);
    const [error, setError]           = useState(null);
    const [exporting, setExporting]   = useState(false);
    const contentRef                  = useRef(null);

    useEffect(() => { loadData(); }, [periode]);

    const loadData = async () => {
        setLoading(true);
        setError(null);
        try {
            const [s, m, c, t, h] = await Promise.all([
                axiosInstance.get(`/rapports/stats?periode=${periode}`),
                axiosInstance.get("/rapports/ventes-mensuelles"),
                axiosInstance.get(`/rapports/ventes-categories?periode=${periode}`),
                axiosInstance.get("/rapports/top-produits"),
                axiosInstance.get("/rapports/performance-hebdo"),
            ]);
            setStats(s.data);
            setMensuelles(m.data || []);
            setCategories(c.data || []);
            setTopProduits(t.data || []);
            setPerfHebdo(h.data || []);
        } catch (e) {
            console.error("Erreur API:", e);
            setError("Erreur de connexion au serveur. Vérifiez que le backend tourne sur le port 8080.");
        } finally {
            setLoading(false);
        }
    };

    const fmt = (n) => `${Number(n || 0).toLocaleString("fr-MA")} DH`;

    const cardStyle = {
        background: "#fff", borderRadius: 12, padding: "20px 24px",
        border: "1px solid #f0f0f0", boxShadow: "0 1px 4px rgba(0,0,0,0.05)",
    };

    if (loading) return (
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "60vh", fontFamily: "system-ui" }}>
            <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 32, marginBottom: 12 }}>⏳</div>
                <div style={{ color: "#6b7280", fontSize: 15 }}>Chargement des données...</div>
            </div>
        </div>
    );

    if (error) return (
        <div style={{ padding: "28px 32px", fontFamily: "system-ui" }}>
            <div style={{ background: "#fee2e2", border: "1px solid #fca5a5", borderRadius: 12, padding: "20px 24px", color: "#dc2626" }}>
                <div style={{ fontWeight: 700, marginBottom: 8 }}>❌ Erreur de connexion</div>
                <div style={{ fontSize: 14 }}>{error}</div>
                <button onClick={loadData} style={{ marginTop: 12, background: "#ef4444", color: "#fff", border: "none", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontWeight: 600 }}>
                    Réessayer
                </button>
            </div>
        </div>
    );

    const periodeLabel = { mois: "Ce mois", semaine: "Cette semaine", trimestre: "Ce trimestre", annee: "Cette année" }[periode] ?? periode;

    const exportPDF = async () => {
        if (!contentRef.current) return;
        setExporting(true);
        try {
            const { default: jsPDF }      = await import("jspdf");
            const { default: html2canvas } = await import("html2canvas");

            const canvas = await html2canvas(contentRef.current, {
                scale: 2,
                useCORS: true,
                backgroundColor: "#f9fafb",
                logging: false,
            });

            const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });

            const pageW  = pdf.internal.pageSize.getWidth();
            const pageH  = pdf.internal.pageSize.getHeight();
            const margin = 10;
            const usableW = pageW - margin * 2;

            // Header bande verte
            pdf.setFillColor(16, 185, 129);
            pdf.rect(0, 0, pageW, 18, "F");
            pdf.setTextColor(255, 255, 255);
            pdf.setFontSize(13);
            pdf.setFont("helvetica", "bold");
            pdf.text("PharmaSys — Rapport & Statistiques", margin, 12);
            pdf.setFontSize(9);
            pdf.setFont("helvetica", "normal");
            const dateStr = new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
            pdf.text(`${periodeLabel}  •  Généré le ${dateStr}`, pageW - margin, 12, { align: "right" });

            // Image du contenu
            const imgH      = (canvas.height * usableW) / canvas.width;
            const startY    = 22;
            let remainingH  = imgH;
            let srcY        = 0;
            let isFirstPage = true;

            while (remainingH > 0) {
                const sliceH  = Math.min(remainingH, pageH - (isFirstPage ? startY : margin) - margin);
                const sliceCanvas = document.createElement("canvas");
                sliceCanvas.width  = canvas.width;
                sliceCanvas.height = (sliceH / usableW) * canvas.width;
                const ctx = sliceCanvas.getContext("2d");
                ctx.drawImage(canvas, 0, srcY, canvas.width, sliceCanvas.height, 0, 0, canvas.width, sliceCanvas.height);

                if (!isFirstPage) pdf.addPage();
                pdf.addImage(sliceCanvas.toDataURL("image/png"), "PNG", margin, isFirstPage ? startY : margin, usableW, sliceH);

                srcY        += sliceCanvas.height;
                remainingH  -= sliceH;
                isFirstPage  = false;
            }

            // Pied de page sur chaque page
            const totalPages = pdf.getNumberOfPages();
            for (let i = 1; i <= totalPages; i++) {
                pdf.setPage(i);
                pdf.setFontSize(8);
                pdf.setTextColor(156, 163, 175);
                pdf.text(`Page ${i} / ${totalPages}`, pageW / 2, pageH - 5, { align: "center" });
            }

            pdf.save(`rapport-pharmacie-${periode}-${new Date().toISOString().slice(0, 10)}.pdf`);
        } catch (err) {
            console.error("Erreur export PDF:", err);
        } finally {
            setExporting(false);
        }
    };

    const kpiCards = [
        { label: "Ventes totales",  value: fmt(stats?.ventesTotales),                                       badge: "Toutes périodes",  badgeColor: "#10b981", icon: "💰" },
        { label: "Vente moyenne",   value: fmt(stats?.venteMoyenne),                                        badge: "Par période",       badgeColor: "#3b82f6", icon: "📈" },
        { label: "Transactions",    value: Number(stats?.transactions || 0).toLocaleString("fr-MA"),        badge: "Total",             badgeColor: "#6b7280", icon: "📊" },
        { label: "Panier moyen",    value: fmt(stats?.panierMoyen),                                         badge: "Par transaction",   badgeColor: "#f59e0b", icon: "🛒" },
    ];

    return (
        <div style={{ padding: "28px 32px", fontFamily: "system-ui, sans-serif", minHeight: "100vh" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
                <div>
                    <h1 style={{ fontSize: 24, fontWeight: 700, margin: 0, color: "#111" }}>Rapports et Statistiques</h1>
                    <p style={{ color: "#6b7280", margin: "6px 0 0", fontSize: 14 }}>Analyse des performances de la pharmacie</p>
                </div>
                <div style={{ display: "flex", gap: 12 }}>
                    <select value={periode} onChange={(e) => setPeriode(e.target.value)}
                        style={{ padding: "9px 16px", borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 14, background: "#fff", cursor: "pointer", outline: "none" }}>
                        <option value="mois">Ce mois</option>
                        <option value="semaine">Cette semaine</option>
                        <option value="trimestre">Ce trimestre</option>
                        <option value="annee">Cette année</option>
                    </select>
                    <button
                        onClick={exportPDF}
                        disabled={exporting}
                        style={{ background: "#10b981", color: "#fff", border: "none", borderRadius: 8, padding: "9px 18px", cursor: exporting ? "not-allowed" : "pointer", fontWeight: 600, fontSize: 14, opacity: exporting ? 0.7 : 1, display: "flex", alignItems: "center", gap: 6 }}>
                        {exporting ? "⏳ Export..." : "⬇ Exporter PDF"}
                    </button>
                </div>
            </div>

            <div ref={contentRef}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16, marginBottom: 24 }}>
                {kpiCards.map((k, i) => (
                    <div key={i} style={cardStyle}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, color: "#6b7280", fontSize: 13, marginBottom: 10 }}>
                            <span style={{ fontSize: 16 }}>{k.icon}</span>{k.label}
                        </div>
                        <div style={{ fontSize: 24, fontWeight: 700, color: "#111", marginBottom: 6 }}>{k.value}</div>
                        <div style={{ fontSize: 12, color: k.badgeColor, fontWeight: 500 }}>{k.badge}</div>
                    </div>
                ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
                <div style={cardStyle}>
                    <h3 style={{ margin: "0 0 20px", fontSize: 15, fontWeight: 600, color: "#111" }}>Évolution des ventes mensuelles</h3>
                    {mensuelles.length === 0
                        ? <div style={{ height: 220, display: "flex", alignItems: "center", justifyContent: "center", color: "#9ca3af" }}>Aucune donnée disponible</div>
                        : (
                            <ResponsiveContainer width="100%" height={220}>
                                <LineChart data={mensuelles} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                                    <XAxis dataKey="mois" tick={{ fontSize: 12, fill: "#9ca3af" }} axisLine={false} tickLine={false}/>
                                    <YAxis tick={{ fontSize: 12, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`}/>
                                    <Tooltip formatter={(v) => [`${v.toLocaleString("fr-MA")} DH`, "Ventes"]} contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 13 }}/>
                                    <Line type="monotone" dataKey="ventes" stroke="#10b981" strokeWidth={2.5} dot={{ r: 5, fill: "#10b981", strokeWidth: 2, stroke: "#fff" }} activeDot={{ r: 7 }}/>
                                </LineChart>
                            </ResponsiveContainer>
                        )}
                </div>
                <div style={cardStyle}>
                    <h3 style={{ margin: "0 0 20px", fontSize: 15, fontWeight: 600, color: "#111" }}>Ventes par catégorie</h3>
                    {categories.length === 0
                        ? <div style={{ height: 200, display: "flex", alignItems: "center", justifyContent: "center", color: "#9ca3af" }}>Aucune donnée disponible</div>
                        : (
                            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
                                <PieChart width={180} height={200}>
                                    <Pie data={categories} dataKey="total" nameKey="categorie" cx="50%" cy="50%" innerRadius={45} outerRadius={82} paddingAngle={3}>
                                        {categories.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]}/>)}
                                    </Pie>
                                    <Tooltip formatter={(v) => [`${v.toLocaleString("fr-MA")} DH`]} contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 13 }}/>
                                </PieChart>
                                <div style={{ flex: 1 }}>
                                    {categories.map((c, i) => (
                                        <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                                            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                                <div style={{ width: 12, height: 12, borderRadius: 3, background: COLORS[i % COLORS.length], flexShrink: 0 }}/>
                                                <span style={{ fontSize: 13, color: "#374151" }}>{c.categorie}</span>
                                            </div>
                                            <span style={{ fontWeight: 600, fontSize: 13, color: "#111" }}>{Number(c.total).toLocaleString("fr-MA")} DH</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
                <div style={cardStyle}>
                    <h3 style={{ margin: "0 0 20px", fontSize: 15, fontWeight: 600, color: "#111" }}>Produits les plus vendus</h3>
                    {topProduits.length === 0
                        ? <div style={{ height: 220, display: "flex", alignItems: "center", justifyContent: "center", color: "#9ca3af" }}>Aucune donnée disponible</div>
                        : (
                            <ResponsiveContainer width="100%" height={220}>
                                <BarChart data={topProduits} layout="vertical" margin={{ top: 0, right: 20, left: 0, bottom: 0 }}>
                                    <XAxis type="number" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false}/>
                                    <YAxis dataKey="nom" type="category" tick={{ fontSize: 11, fill: "#374151" }} width={130} axisLine={false} tickLine={false}/>
                                    <Tooltip formatter={(v, name) => [v.toLocaleString("fr-MA"), name === "unites" ? "Unités" : name]} contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 13 }}/>
                                    <Bar dataKey="unites" name="Unités" fill="#10b981" radius={[0, 6, 6, 0]} barSize={18}/>
                                </BarChart>
                            </ResponsiveContainer>
                        )}
                </div>
                <div style={cardStyle}>
                    <h3 style={{ margin: "0 0 20px", fontSize: 15, fontWeight: 600, color: "#111" }}>Performance hebdomadaire</h3>
                    {perfHebdo.length === 0
                        ? <div style={{ height: 220, display: "flex", alignItems: "center", justifyContent: "center", color: "#9ca3af" }}>Aucune donnée disponible</div>
                        : (
                            <ResponsiveContainer width="100%" height={220}>
                                <BarChart data={perfHebdo} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                                    <XAxis dataKey="jour" tick={{ fontSize: 12, fill: "#9ca3af" }} axisLine={false} tickLine={false}/>
                                    <YAxis tick={{ fontSize: 12, fill: "#9ca3af" }} axisLine={false} tickLine={false}/>
                                    <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 13 }}/>
                                    <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }}/>
                                    <Bar dataKey="ventes" name="Ventes (DH)" fill="#10b981" radius={[4, 4, 0, 0]} barSize={16}/>
                                    <Bar dataKey="transactions" name="Transactions" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={16}/>
                                </BarChart>
                            </ResponsiveContainer>
                        )}
                </div>
            </div>

            <div style={cardStyle}>
                <h3 style={{ margin: "0 0 20px", fontSize: 15, fontWeight: 600, color: "#111" }}>Détails des ventes par produit</h3>
                {topProduits.length === 0
                    ? <div style={{ padding: 40, textAlign: "center", color: "#9ca3af" }}>Aucune donnée</div>
                    : (
                        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
                            <thead>
                            <tr style={{ borderBottom: "1px solid #e5e7eb" }}>
                                {["#", "Produit", "Unités vendues", "Chiffre d'affaires", "Part du CA"].map((h) => (
                                    <th key={h} style={{ textAlign: "left", padding: "10px 14px", color: "#9ca3af", fontWeight: 500, fontSize: 13 }}>{h}</th>
                                ))}
                            </tr>
                            </thead>
                            <tbody>
                            {topProduits.map((p, i) => {
                                const totalCA = topProduits.reduce((s, x) => s + (x.ca || 0), 0);
                                const part    = totalCA > 0 ? ((p.ca / totalCA) * 100).toFixed(1) : "0.0";
                                return (
                                    <tr key={i} style={{ borderBottom: "1px solid #f9fafb" }}>
                                        <td style={{ padding: "14px" }}>
                                            <div style={{ width: 24, height: 24, borderRadius: "50%", background: "#f0fdf4", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 600, color: "#10b981" }}>{i + 1}</div>
                                        </td>
                                        <td style={{ padding: "14px", fontWeight: 500, color: "#111" }}>{p.nom}</td>
                                        <td style={{ padding: "14px", color: "#374151" }}>{(p.unites || 0).toLocaleString("fr-MA")}</td>
                                        <td style={{ padding: "14px", color: "#374151" }}>{(p.ca || 0).toLocaleString("fr-MA")} DH</td>
                                        <td style={{ padding: "14px" }}>
                                            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                                                <div style={{ flex: 1, background: "#e5e7eb", borderRadius: 4, height: 6 }}>
                                                    <div style={{ width: `${part}%`, background: "#10b981", height: 6, borderRadius: 4 }}/>
                                                </div>
                                                <span style={{ fontSize: 12, color: "#6b7280", minWidth: 36 }}>{part}%</span>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                            </tbody>
                        </table>
                    )}
            </div>
            </div> {/* end ref={contentRef} */}
        </div>
    );
}
