import { NavLink } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import {
  ShoppingCart, Package, AlertOctagon, LayoutDashboard, LogOut, Cross,
  Pill, ShoppingBag, RotateCcw, BarChart3, Users, Landmark,
} from 'lucide-react'

const NAV = [
  { to: '/',          label: 'Tableau de bord',     icon: LayoutDashboard },
  { to: '/pos',       label: 'Vente POS',           icon: ShoppingCart },
  { to: '/stock',     label: 'Gestion Stock',       icon: Package },
  { to: '/defective', label: 'Produits Défectueux', icon: AlertOctagon },
  { to: '/produits',  label: 'Produits',            icon: Pill },
  { to: '/achats',    label: 'Achats',              icon: ShoppingBag },
  { to: '/retours',   label: 'Avoirs',              icon: RotateCcw },
  { to: '/rapports',  label: 'Rapports',            icon: BarChart3 },
  { to: '/patients',  label: 'Patients',            icon: Users },
  { to: '/caisse',    label: 'Caisse',              icon: Landmark },
]

export default function Sidebar() {
  const { user, logout, lowStockProducts, expiredProducts, defectives } = useApp()

  const todayStr = new Date().toLocaleDateString('fr-FR')
  const newDefectivesToday = defectives.filter(d => d.date === todayStr).length

  return (
    <aside className="w-64 min-h-screen bg-white border-r border-gray-100 flex flex-col shadow-sm">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-green-600 rounded-xl flex items-center justify-center">
            <Cross className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-gray-900 font-bold text-sm">PharmaSys</p>
            <p className="text-gray-400 text-xs">Gestion Officine</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV.map(({ to, label, icon: Icon }) => {
          const stockBadge = lowStockProducts.length + expiredProducts.length || null
          const badge =
            to === '/stock'     ? stockBadge :
            to === '/defective' ? (newDefectivesToday || null) : null

          return (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-green-600 text-white shadow-sm'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`
              }
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span className="flex-1">{label}</span>
              {badge && (
                <span className="text-xs font-bold px-1.5 py-0.5 rounded-full bg-red-100 text-red-600">
                  {badge}
                </span>
              )}
            </NavLink>
          )
        })}
      </nav>

      {/* User */}
      <div className="px-3 py-4 border-t border-gray-100">
        <div className="flex items-center gap-3 px-2 mb-3">
          <div className="w-8 h-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-bold text-sm flex-shrink-0">
            {user?.name?.[0] ?? 'U'}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-gray-800 truncate">{user?.name}</p>
            <p className="text-xs text-gray-400 truncate">{user?.role}</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-gray-500 hover:bg-red-50 hover:text-red-600 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Déconnexion
        </button>
      </div>
    </aside>
  )
}
