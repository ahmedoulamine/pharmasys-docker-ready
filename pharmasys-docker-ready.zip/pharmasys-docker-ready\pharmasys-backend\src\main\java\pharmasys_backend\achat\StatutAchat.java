package pharmasys_backend.achat;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum StatutAchat {
    BROUILLON("Brouillon"),
    EN_ATTENTE("En attente"),
    CONFIRME("Confirmée"),
    RECU("Reçue"),
    ANNULE("Annulé"),
    LITIGE("Litige");

    private final String label;

    StatutAchat(String label) { this.label = label; }

    @JsonValue
    public String getLabel() { return label; }

    @JsonCreator
    public static StatutAchat fromLabel(String value) {
        if (value == null) return EN_ATTENTE;
        for (StatutAchat s : values()) {
            if (s.label.equals(value) || s.name().equals(value)) return s;
        }
        return EN_ATTENTE;
    }
}
