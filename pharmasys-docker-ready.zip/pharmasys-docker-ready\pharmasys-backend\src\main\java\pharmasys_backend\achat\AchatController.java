package pharmasys_backend.achat;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/achats")
@RequiredArgsConstructor
public class AchatController {

    private final AchatService achatService;

    @GetMapping
    public List<Achat> getAll() {
        return achatService.getAll();
    }

    @PostMapping
    public ResponseEntity<Achat> create(@RequestBody Achat achat) {
        return ResponseEntity.ok(achatService.create(achat));
    }

    @PutMapping("/{id}/confirm")
    public ResponseEntity<Achat> confirm(@PathVariable Long id) {
        return ResponseEntity.ok(achatService.confirm(id));
    }

    @PutMapping("/{id}/receive")
    public ResponseEntity<Achat> receive(@PathVariable Long id) {
        return ResponseEntity.ok(achatService.receive(id));
    }

    @PutMapping("/{id}/litige")
    public ResponseEntity<Achat> litige(@PathVariable Long id) {
        return ResponseEntity.ok(achatService.litige(id));
    }
}
