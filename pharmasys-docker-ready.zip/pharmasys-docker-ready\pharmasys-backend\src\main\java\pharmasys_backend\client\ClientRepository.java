package pharmasys_backend.client;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ClientRepository extends JpaRepository<Client, Long> {

    List<Client> findByNomContainingIgnoreCaseOrderByNomAsc(String nom);

    Optional<Client> findByNomIgnoreCase(String nom);

    // Nombre de clients ENREGISTRÉS ayant au moins une vente EN_ATTENTE
    @Query(value = """
        SELECT COUNT(*) FROM clients c
        WHERE (SELECT COALESCE(SUM(v.total_ttc), 0)
               FROM ventes v
               WHERE LOWER(v.patient_nom) = LOWER(c.nom)
               AND v.statut = 'EN_ATTENTE') > 0
        """, nativeQuery = true)
    long countAvecCredit();

    // Total des crédits EN_ATTENTE pour les clients ENREGISTRÉS uniquement
    @Query(value = """
        SELECT COALESCE(SUM(sub.credit), 0) FROM (
            SELECT (SELECT COALESCE(SUM(v.total_ttc), 0)
                    FROM ventes v
                    WHERE LOWER(v.patient_nom) = LOWER(c.nom)
                    AND v.statut = 'EN_ATTENTE') AS credit
            FROM clients c
        ) sub
        """, nativeQuery = true)
    Double sumCreditTotal();

    @Query("SELECT COUNT(c) FROM Client c WHERE c.derniereVisite >= :debut")
    long countNouveauxCeMois(@Param("debut") LocalDate debut);
}
