package pharmasys_backend.lot;

import jakarta.persistence.*;
import pharmasys_backend.produit.Produit;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "lots")
public class Lot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "produit_id", nullable = false)
    private Produit produit;

    @Column(name = "numero_lot", nullable = false, length = 100)
    private String numeroLot;

    @Column(name = "date_fabrication")
    private LocalDate dateFabrication;

    @Column(name = "date_peremption", nullable = false)
    private LocalDate datePeremption;

    @Column(name = "quantite_initiale", nullable = false)
    private Integer quantiteInitiale = 0;

    @Column(name = "quantite_restante", nullable = false)
    private Integer quantiteRestante = 0;

    private String fournisseur;

    @Column(name = "numero_bon_livraison", length = 100)
    private String numeroBonLivraison;

    @Column(name = "prix_achat", precision = 10, scale = 2)
    private BigDecimal prixAchat;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, columnDefinition = "statut_lot")
    private StatutLot statut = StatutLot.EN_STOCK;

    private String emplacement;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public Produit getProduit() { return produit; }
    public String getNumeroLot() { return numeroLot; }
    public LocalDate getDateFabrication() { return dateFabrication; }
    public LocalDate getDatePeremption() { return datePeremption; }
    public Integer getQuantiteInitiale() { return quantiteInitiale; }
    public Integer getQuantiteRestante() { return quantiteRestante; }
    public String getFournisseur() { return fournisseur; }
    public String getNumeroBonLivraison() { return numeroBonLivraison; }
    public BigDecimal getPrixAchat() { return prixAchat; }
    public StatutLot getStatut() { return statut; }
    public String getEmplacement() { return emplacement; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setId(Long id) { this.id = id; }
    public void setProduit(Produit produit) { this.produit = produit; }
    public void setNumeroLot(String numeroLot) { this.numeroLot = numeroLot; }
    public void setDateFabrication(LocalDate d) { this.dateFabrication = d; }
    public void setDatePeremption(LocalDate d) { this.datePeremption = d; }
    public void setQuantiteInitiale(Integer q) { this.quantiteInitiale = q; }
    public void setQuantiteRestante(Integer q) { this.quantiteRestante = q; }
    public void setFournisseur(String fournisseur) { this.fournisseur = fournisseur; }
    public void setNumeroBonLivraison(String n) { this.numeroBonLivraison = n; }
    public void setPrixAchat(BigDecimal prixAchat) { this.prixAchat = prixAchat; }
    public void setStatut(StatutLot statut) { this.statut = statut; }
    public void setEmplacement(String emplacement) { this.emplacement = emplacement; }
}
