package pharmasys_backend.defectueux;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record DefectueuxResponse(
    Long id,
    Long produitId,
    String produitNom,
    String produitEan13,
    TypeDefaut typeDefaut,
    String description,
    Integer quantiteConcernee,
    LocalDate dateDetection,
    LocalDate dateSignalement,
    String signaledParNom,
    Priorite priorite,
    StatutSignalement statut,
    LocalDateTime createdAt
) {}
