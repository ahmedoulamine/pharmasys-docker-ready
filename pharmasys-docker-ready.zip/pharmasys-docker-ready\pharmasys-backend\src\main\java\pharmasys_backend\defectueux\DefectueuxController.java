package pharmasys_backend.defectueux;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/defectueux")
public class DefectueuxController {

    private final DefectueuxService service;

    public DefectueuxController(DefectueuxService service) {
        this.service = service;
    }

    @GetMapping
    public List<DefectueuxResponse> findAll() {
        return service.findAll();
    }

    @PostMapping
    public DefectueuxResponse create(@RequestBody DefectueuxRequest req) {
        return service.create(req);
    }
}
