import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { Eye, EyeOff, LogIn, Cross } from 'lucide-react'
import axiosInstance from '../api/axios'

const ROLE_PATHS = {
  PHARMACIEN_TITULAIRE: '/',
  RESPONSABLE_STOCK:    '/produits',
  CAISSIER:             '/pos',
}

export default function Login({ onLogin }) {
  const { login } = useApp()
  const [loginVal, setLoginVal]   = useState('')
  const [password, setPassword]   = useState('')
  const [showPass, setShowPass]   = useState(false)
  const [error, setError]         = useState('')
  const [loading, setLoading]     = useState(false)
  const [showForgot, setShowForgot] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const { data } = await axiosInstance.post('/auth/login', {
        login: loginVal,
        motDePasse: password,
      })
      login(data)
      const path = ROLE_PATHS[data.role] ?? '/'
      onLogin(path)
    } catch (err) {
      setError(err.response?.data?.message || 'Login ou mot de passe incorrect.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 flex items-center justify-center p-4">

      {showForgot && <ForgotPasswordModal onClose={() => setShowForgot(false)} />}

      <div className="w-full max-w-md">

        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-600 rounded-2xl shadow-lg mb-4">
            <Cross className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">Système de Gestion de Pharmacie</h1>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg px-4 py-3 mb-5">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Email / Login
              </label>
              <input
                type="text"
                value={loginVal}
                onChange={e => { setLoginVal(e.target.value); setError('') }}
                placeholder="votre.email@pharma.ma"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition placeholder-gray-400"
                required
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold text-gray-700">Mot de passe</label>
                <button
                  type="button"
                  onClick={() => setShowForgot(true)}
                  className="text-sm text-green-600 hover:text-green-700 font-medium"
                >
                  Mot de passe oublié ?
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError('') }}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 pr-11 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition placeholder-gray-400"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-colors shadow-sm text-base"
            >
              <LogIn className="w-5 h-5" />
              {loading ? 'Connexion...' : 'Se connecter'}
            </button>
          </form>

        </div>
      </div>
    </div>
  )
}

function ForgotPasswordModal({ onClose }) {
  const [email, setEmail]     = useState('')
  const [sent, setSent]       = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await axiosInstance.post('/auth/forgot-password', { email: email.trim().toLowerCase() })
      setSent(true)
    } catch {
      setError('Une erreur est survenue. Veuillez réessayer.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-8">

        {!sent ? (
          <>
            <h2 className="text-lg font-bold text-gray-800 mb-2">Mot de passe oublié</h2>
            <p className="text-sm text-gray-500 mb-6">
              Entrez votre adresse email. Un lien de réinitialisation vous sera envoyé.
            </p>
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg px-4 py-3 mb-4">
                {error}
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="email"
                value={email}
                onChange={e => { setEmail(e.target.value); setError('') }}
                placeholder="votre.email@pharma.ma"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition placeholder-gray-400"
                required
              />
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-green-500 hover:bg-green-600 disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-colors"
              >
                {loading ? 'Envoi...' : 'Envoyer le lien'}
              </button>
            </form>
          </>
        ) : (
          <div className="text-center">
            <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">✓</span>
            </div>
            <h2 className="text-lg font-bold text-gray-800 mb-2">Email envoyé !</h2>
            <p className="text-sm text-gray-500">
              Si cet email est associé à un compte, vous recevrez un lien de réinitialisation.
            </p>
          </div>
        )}

        <button
          onClick={onClose}
          className="mt-5 w-full text-sm text-gray-400 hover:text-gray-600 transition-colors"
        >
          Fermer
        </button>
      </div>
    </div>
  )
}
