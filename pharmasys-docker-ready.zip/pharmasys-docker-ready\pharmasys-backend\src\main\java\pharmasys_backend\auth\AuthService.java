package pharmasys_backend.auth;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import pharmasys_backend.utilisateur.Utilisateur;
import pharmasys_backend.utilisateur.UtilisateurRepository;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UtilisateurRepository utilisateurRepository;
    private final JwtService jwtService;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public Optional<Map<String, Object>> authenticate(String login, String motDePasse) {
        Optional<Utilisateur> user = utilisateurRepository.findByLogin(login);
        if (user.isEmpty()) {
            user = utilisateurRepository.findByEmail(login);
        }
        return user
                .filter(u -> Boolean.TRUE.equals(u.getActif()))
                .filter(u -> passwordEncoder.matches(motDePasse, u.getMotDePasse()))
                .map(u -> {
                    u.setDerniereConnexion(LocalDateTime.now());
                    utilisateurRepository.save(u);
                    return buildResponse(u);
                });
    }

    private Map<String, Object> buildResponse(Utilisateur u) {
        String token = jwtService.generateToken(u.getLogin(), u.getRole().name());
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("token", token);
        resp.put("id",    u.getId());
        resp.put("nom",   u.getNom() + " " + u.getPrenom());
        resp.put("login", u.getLogin());
        resp.put("email", u.getEmail());
        resp.put("role",  u.getRole().name());
        return resp;
    }
}
