package pharmasys_backend.caisse;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pharmasys_backend.vente.VenteRepository;

import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CaisseService {

    private final SessionCaisseRepository sessionCaisseRepository;
    private final VenteRepository venteRepository;

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    public Optional<SessionCaisse> getActiveSession() {
        return sessionCaisseRepository.findByStatut(StatutCaisse.OUVERTE)
                .stream().findFirst()
                .map(session -> {
                    try {
                        LocalTime ouverture = LocalTime.parse(session.getHeureOuverture());
                        LocalDateTime debut = session.getDateSession().atTime(ouverture);
                        BigDecimal total = venteRepository.sumTotalDepuis(debut);
                        session.setTotalVentes(total != null ? total.doubleValue() : 0.0);
                    } catch (Exception ignored) { }
                    return session;
                });
    }

    public List<SessionCaisse> getHistorique() {
        return sessionCaisseRepository.findAllByOrderByDateSessionDesc();
    }

    public SessionCaisse ouvrirSession(Double fondOuverture) {
        sessionCaisseRepository.findByStatut(StatutCaisse.OUVERTE).forEach(s -> {
            s.setStatut(StatutCaisse.FERMEE);
            s.setHeureCloture(LocalTime.now().format(TIME_FMT));
            sessionCaisseRepository.save(s);
        });

        SessionCaisse session = new SessionCaisse();
        session.setDateSession(LocalDate.now());
        session.setHeureOuverture(LocalTime.now().format(TIME_FMT));
        session.setFondOuverture(fondOuverture);
        session.setTotalVentes(0.0);
        session.setStatut(StatutCaisse.OUVERTE);
        return sessionCaisseRepository.save(session);
    }

    public SessionCaisse fermerSession(Long id, Double fondCloture) {
        SessionCaisse session = sessionCaisseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Session non trouvée: " + id));
        try {
            LocalTime ouverture = LocalTime.parse(session.getHeureOuverture());
            LocalDateTime debut = session.getDateSession().atTime(ouverture);
            BigDecimal total = venteRepository.sumTotalDepuis(debut);
            session.setTotalVentes(total != null ? total.doubleValue() : 0.0);
        } catch (Exception ignored) { }

        session.setHeureCloture(LocalTime.now().format(TIME_FMT));
        session.setFondCloture(fondCloture);
        session.setStatut(StatutCaisse.FERMEE);
        return sessionCaisseRepository.save(session);
    }

}
