package pharmasys_backend.auth;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final PasswordResetService passwordResetService;

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> body) {
        String login    = body.get("login");
        String password = body.get("motDePasse");

        if (login == null || password == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Login et mot de passe requis"));
        }

        return authService.authenticate(login, password)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(401).body(Map.of("message", "Login ou mot de passe incorrect")));
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, String>> forgotPassword(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        if (email == null || email.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Email requis"));
        }
        try {
            passwordResetService.sendResetEmail(email.trim().toLowerCase());
        } catch (Exception e) {
            // Ne pas exposer l'erreur SMTP au client
        }
        return ResponseEntity.ok(Map.of("message", "Si cet email existe, un lien de réinitialisation a été envoyé."));
    }

    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, String>> resetPassword(@RequestBody Map<String, String> body) {
        String token       = body.get("token");
        String newPassword = body.get("newPassword");

        if (token == null || newPassword == null || newPassword.length() < 6) {
            return ResponseEntity.badRequest().body(Map.of("message", "Token ou mot de passe invalide (6 caractères min)"));
        }

        boolean ok = passwordResetService.resetPassword(token, newPassword);
        if (!ok) {
            return ResponseEntity.badRequest().body(Map.of("message", "Lien invalide ou expiré. Veuillez refaire une demande."));
        }
        return ResponseEntity.ok(Map.of("message", "Mot de passe réinitialisé avec succès."));
    }

}
