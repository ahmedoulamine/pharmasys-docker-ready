package pharmasys_backend.retour;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RetourRepository extends JpaRepository<Retour, Long> {
    List<Retour> findAllByOrderByDateRetourDesc();

    long countByStatut(StatutRetour statut);

    @Query("SELECT COALESCE(SUM(r.montant), 0) FROM Retour r WHERE r.statut = 'EN_ATTENTE'")
    Double sumMontantEnAttente();
}
