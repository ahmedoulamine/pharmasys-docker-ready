package pharmasys_backend.vente;

public enum ModePaiement {
    ESPECES, CARTE_BANCAIRE, CHEQUE, VIREMENT,
    TIERS_PAYANT_AMO, TIERS_PAYANT_AMC, DOUBLE_TIERS_PAYANT, FRACTIONNE, CREDIT
}
