const API_BASE = import.meta.env.VITE_API_URL ?? 'http://localhost:8080/api'

async function request(path, options = {}) {
  const token = localStorage.getItem('token')
  const res = await fetch(`${API_BASE}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers ?? {}),
    },
    ...options,
  })
  if (res.status === 401 || res.status === 403) {
    localStorage.clear()
    window.location.href = '/'
    return
  }
  if (!res.ok) {
    let msg = `Erreur API ${res.status}`
    try { const e = await res.json(); msg = e.message || msg } catch { /* keep fallback */ }
    throw new Error(msg)
  }
  if (res.status === 204) return null
  return res.json()
}

function parseAmount(value) {
  if (value == null || value === '') return 0
  if (typeof value === 'number') return value
  return Number(String(value).replace(/\./g, '').replace(',', '.')) || 0
}

export function toProduct(p) {
  return {
    id:                   p.id,
    codeEan13:            p.codeEan13 ?? p.codeCIP ?? p.code_ean13 ?? '',
    nom:                  p.denomination ?? p.nom ?? '',
    dci:                  p.dci ?? '',
    formeDosage:          p.formeDosage ?? p.forme ?? p.dosage ?? '',
    presentation:         p.presentation ?? '',
    ppv:                  p.ppv ?? '',
    baseRemboursementPpv: p.baseRemboursementPpv ?? '',
    ph:                   p.ph ?? '',
    baseRemboursementPh:  p.baseRemboursementPh ?? '',
    categorie:            p.classeTherapeutique ?? p.categorie ?? '',
    remboursementTaux:    p.remboursementTaux ?? '',
    prixAchat:            parseAmount(p.pa ?? p.prixAchat ?? 0),
    prixVente:            parseAmount(p.ppv ?? p.prix ?? p.prixVente ?? 0),
    stock:                p.stock ?? 0,
    stockMin:             p.stockMinimum ?? p.stockMin ?? p.seuilAlerte ?? 0,
    seuilAlerte:          p.seuilAlerte ?? 0,
    dateExpiration:       p.dateExpiration ?? null,
  }
}

export const PAYMENT_TO_API = {
  'Espèces':        'ESPECES',
  'Carte':          'CARTE_BANCAIRE',
  'Crédit':         'CREDIT',
  'Chèque':         'CHEQUE',
  'Virement':       'VIREMENT',
  'Tiers payant':   'TIERS_PAYANT_AMO',
}

const PAYMENT_FROM_API = {
  ESPECES:             'Espèces',
  CARTE_BANCAIRE:      'Carte',
  CREDIT:              'Crédit',
  CHEQUE:              'Chèque',
  VIREMENT:            'Virement',
  TIERS_PAYANT_AMO:    'Tiers payant',
  TIERS_PAYANT_AMC:    'Tiers payant',
  DOUBLE_TIERS_PAYANT: 'Tiers payant',
  FRACTIONNE:          'Fractionné',
}

export function toSale(v) {
  const lignes = v.lignes ?? []
  return {
    id:          v.id,
    numeroVente: v.numeroVente ?? '',
    date:        v.dateVente ? new Date(v.dateVente).toLocaleDateString('fr-FR') : '',
    produits:    lignes.map(l => `${l.nom ?? l.produit?.nom ?? '?'} ×${l.quantite}`).join(', '),
    total:       Number(v.totalTtc ?? v.montant ?? 0),
    totalHt:     Number(v.totalHt  ?? 0),
    totalTva:    Number(v.totalTva  ?? 0),
    montantRecu: Number(v.montantRecu   ?? 0),
    rendu:       Number(v.renduMonnaie  ?? 0),
    mode:        PAYMENT_FROM_API[v.modePaiement] ?? v.modePaiement ?? '',
    nbArticles:  lignes.reduce((s, l) => s + (l.quantite ?? 0), 0),
    statut:      v.statut ?? '',
    caissier:    v.caissier ?? '',
    lignes,
  }
}

export async function fetchMedicaments() {
  const page = await request('/produits?size=50&sort=denomination')
  return {
    products: (page.content ?? []).map(toProduct),
    total:    page.totalElements ?? 0,
  }
}

export async function searchMedicaments(query) {
  const url = query && query.trim().length >= 1
    ? `/produits?search=${encodeURIComponent(query.trim())}&size=50&sort=denomination`
    : `/produits?size=50&sort=denomination`
  const page = await request(url)
  return (page.content ?? []).map(toProduct)
}

export async function fetchInventaire(query = '', page = 0, size = 100) {
  const params = new URLSearchParams({ page, size, sort: 'denomination' })
  if (query && query.trim().length >= 1) params.set('search', query.trim())
  const data = await request(`/produits?${params.toString()}`)
  return {
    products:   (data.content ?? []).map(toProduct),
    total:      data.totalElements ?? 0,
    totalPages: data.totalPages ?? 1,
    page:       data.number ?? 0,
  }
}

export async function fetchVentes() {
  try {
    const page = await request('/ventes?size=200')
    return (page.content ?? []).map(toSale)
  } catch {
    return []
  }
}

export async function createVente(cart, payment) {
  const body = {
    modePaiement:    PAYMENT_TO_API[payment.mode] ?? 'ESPECES',
    montantRecu:     payment.montantRecu ?? null,
    patientNom:      payment.patientNom  ?? null,
    tpeReference:    payment.tpe?.ref   ?? null,
    tpeAutorisation: payment.tpe?.auth  ?? null,
    tpeCarte:        payment.tpe?.card  ?? null,
    lignes: cart.map(item => ({
      produitId: item.id,
      quantite:  item.qty,
    })),
  }
  return toSale(await request('/ventes', { method: 'POST', body: JSON.stringify(body) }))
}

export async function createVenteCredit(patientNom, produitId, quantite) {
  const body = {
    modePaiement: 'CREDIT',
    montantRecu:  0,
    patientNom,
    lignes: [{ produitId, quantite }],
  }
  return toSale(await request('/ventes', { method: 'POST', body: JSON.stringify(body) }))
}

export async function fetchClients(search = '') {
  try {
    const url = search.trim() ? `/clients?search=${encodeURIComponent(search.trim())}` : '/clients'
    return await request(url)
  } catch {
    return []
  }
}

export async function payerCredit(clientId, montant, commentaire = '') {
  return request(`/clients/${clientId}/payer-credit`, {
    method: 'PATCH',
    body: JSON.stringify({ montant, commentaire }),
  })
}

export async function fetchDefectueux() {
  try { return await request('/defectueux') }
  catch { return [] }
}

export async function createDefectueux(data) {
  return request('/defectueux', { method: 'POST', body: JSON.stringify(data) })
}

export async function updateStock(id, quantite, mode = 'SET') {
  return toProduct(await request(`/produits/${id}/stock`, {
    method: 'PATCH',
    body: JSON.stringify({ quantite, mode }),
  }))
}
