package pharmasys_backend.utilisateur;

public enum RoleUtilisateur {
    PHARMACIEN_TITULAIRE,
    PHARMACIEN_ADJOINT,
    PREPARATEUR,
    CAISSIER,
    RESPONSABLE_STOCK,
    COMPTABLE,
    SUPER_ADMIN
}
