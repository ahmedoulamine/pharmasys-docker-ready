package pharmasys_backend.defectueux;

public class DefectueuxRequest {
    private Long produitId;
    private TypeDefaut typeDefaut;
    private String description;
    private Integer quantiteConcernee;
    private String dateDetection;
    private String signaledParNom;
    private Priorite priorite;

    public Long getProduitId()              { return produitId; }
    public TypeDefaut getTypeDefaut()       { return typeDefaut; }
    public String getDescription()         { return description; }
    public Integer getQuantiteConcernee()  { return quantiteConcernee; }
    public String getDateDetection()       { return dateDetection; }
    public String getSignaledParNom()      { return signaledParNom; }
    public Priorite getPriorite()          { return priorite; }
}
