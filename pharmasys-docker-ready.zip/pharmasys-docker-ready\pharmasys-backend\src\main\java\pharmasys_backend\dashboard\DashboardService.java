package pharmasys_backend.dashboard;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import pharmasys_backend.achat.AchatRepository;
import pharmasys_backend.client.ClientRepository;
import pharmasys_backend.produit.Produit;
import pharmasys_backend.produit.ProduitRepository;
import pharmasys_backend.retour.RetourRepository;
import pharmasys_backend.retour.StatutRetour;
import pharmasys_backend.vente.StatutVente;
import pharmasys_backend.vente.VenteRepository;

import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final VenteRepository   venteRepository;
    private final ProduitRepository produitRepository;
    private final ClientRepository  clientRepository;
    private final AchatRepository   achatRepository;
    private final RetourRepository  retourRepository;

    public Map<String, Object> getStats() {
        LocalDateTime debutJour = LocalDate.now().atStartOfDay();
        LocalDate     debutMois = LocalDate.now().withDayOfMonth(1);

        // Ventes
        BigDecimal ventesJour  = venteRepository.sumTotalDepuis(debutJour);
        long       transactions = venteRepository.countByDateVenteAfterAndStatut(debutJour, StatutVente.COMPLETEE);

        // Stock
        long produitsAlerte   = produitRepository.countProduitsEnAlerte();
        long alertesCritiques = produitRepository.countAlertesCritiques();
        long produitsPerimes  = produitRepository.countProduitsPerimes();

        // Achats
        Double achatsMois    = achatRepository.sumMontantDepuis(debutMois);
        long   commandesMois = achatRepository.countByDateCommandeAfter(debutMois);

        // Retours
        long   retours        = retourRepository.countByStatut(StatutRetour.EN_ATTENTE);
        Double montantRetours = retourRepository.sumMontantEnAttente();

        // Clients
        long patientsActifs   = clientRepository.count();
        long nouveauxPatients = clientRepository.countNouveauxCeMois(debutMois);

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("ventesJour",      ventesJour  != null ? ventesJour : BigDecimal.ZERO);
        stats.put("transactions",    transactions);
        stats.put("produitsAlerte",  produitsAlerte);
        stats.put("alertesCritiques",alertesCritiques);
        stats.put("produitsPerimes", produitsPerimes);
        stats.put("achatsMois",      achatsMois  != null ? achatsMois : 0.0);
        stats.put("commandesMois",   commandesMois);
        stats.put("retours",         retours);
        stats.put("montantRetours",  montantRetours != null ? montantRetours : 0.0);
        stats.put("patientsActifs",  patientsActifs);
        stats.put("nouveauxPatients",nouveauxPatients);
        return stats;
    }

    public List<Map<String, Object>> getVentesSemaine() {
        LocalDateTime debut = LocalDate.now().minusDays(6).atStartOfDay();
        List<Object[]> rows = venteRepository.ventesParJour(debut);
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object[] row : rows) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("jour",   row[0]);
            map.put("ventes", row[1]);
            result.add(map);
        }
        return result;
    }

    public List<Map<String, Object>> getTopProduits() {
        List<Object[]> rows = venteRepository.topProduits();
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object[] row : rows) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("nom",    row[0]);
            map.put("unites", row[1]);
            result.add(map);
        }
        return result;
    }

    public List<Map<String, Object>> getAlertesStock() {
        List<Produit> alertes = produitRepository.findTop10ProduitsEnAlerte(PageRequest.of(0, 10));
        List<Map<String, Object>> result = new ArrayList<>();
        for (Produit p : alertes) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("nom",   p.getDenomination());
            map.put("stock", p.getStock());
            map.put("seuil", p.getSeuilAlerte());
            result.add(map);
        }
        return result;
    }

    public List<Map<String, Object>> getActivite() {
        List<Object[]> rows = venteRepository.findRecentActivity();
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object[] row : rows) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("type",   "vente");
            map.put("label",  "Vente #" + row[0] + " — " + row[2] + " DH");
            map.put("temps",  row[1] != null ? row[1].toString() : "");
            result.add(map);
        }
        return result;
    }

}
