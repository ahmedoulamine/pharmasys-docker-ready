package pharmasys_backend.vente;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import pharmasys_backend.client.Client;
import pharmasys_backend.client.ClientRepository;
import pharmasys_backend.produit.Produit;
import pharmasys_backend.produit.ProduitRepository;
import pharmasys_backend.utilisateur.Utilisateur;
import pharmasys_backend.utilisateur.UtilisateurRepository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class VenteService {

    private final VenteRepository        venteRepo;
    private final ProduitRepository      produitRepo;
    private final UtilisateurRepository  utilisateurRepo;
    private final ClientRepository       clientRepo;

    public VenteService(VenteRepository venteRepo,
                        ProduitRepository produitRepo,
                        UtilisateurRepository utilisateurRepo,
                        ClientRepository clientRepo) {
        this.venteRepo       = venteRepo;
        this.produitRepo     = produitRepo;
        this.utilisateurRepo = utilisateurRepo;
        this.clientRepo      = clientRepo;
    }

    public Page<VenteResponse> findAll(Pageable pageable) {
        return venteRepo.findByOrderByDateVenteDesc(pageable).map(this::toResponse);
    }

    public List<VenteResponse> findByPatientNom(String nom) {
        return venteRepo.findByPatientNomContainingIgnoreCaseOrderByDateVenteDesc(nom)
                .stream().map(this::toResponse).toList();
    }

    @Transactional
    public BigDecimal marquerVentesPayees(String patientNom, BigDecimal montantPaye) {
        List<Vente> attente = venteRepo
                .findByPatientNomIgnoreCaseAndStatutOrderByDateVenteAsc(patientNom, StatutVente.EN_ATTENTE);
        BigDecimal reste = montantPaye;
        for (Vente v : attente) {
            if (reste.compareTo(BigDecimal.ZERO) <= 0) break;
            v.setStatut(StatutVente.COMPLETEE);
            v.setMontantRecu(v.getTotalTtc());
            v.setDateVente(LocalDateTime.now());
            venteRepo.save(v);
            reste = reste.subtract(v.getTotalTtc());
        }
        // Si le montant payé dépasse le total des ventes en attente, on crée une vente complémentaire
        if (reste.compareTo(BigDecimal.valueOf(0.01)) > 0) {
            creerVenteSimple(patientNom, reste, StatutVente.COMPLETEE);
        }
        updateClientVisite(patientNom, true);
        return montantPaye;
    }

    @Transactional
    public void creerVenteCreditManuel(String patientNom, BigDecimal montant) {
        creerVenteSimple(patientNom, montant, StatutVente.EN_ATTENTE);
        if (patientNom != null && !patientNom.isBlank()) {
            final BigDecimal m = montant;
            clientRepo.findByNomIgnoreCase(patientNom.trim()).ifPresent(c -> {
                c.setCreditTotal(c.getCreditTotal() + m.doubleValue());
                clientRepo.save(c);
            });
        }
    }

    private void creerVenteSimple(String patientNom, BigDecimal montant, StatutVente statut) {
        BigDecimal m = montant.setScale(2, RoundingMode.HALF_UP);
        Vente vente = new Vente();
        vente.setNumeroVente(genererNumero());
        vente.setPatientNom(patientNom);
        vente.setTotalTtc(m);
        vente.setTotalHt(m);
        vente.setTotalTva(BigDecimal.ZERO);
        vente.setMontantRecu(statut == StatutVente.COMPLETEE ? m : BigDecimal.ZERO);
        vente.setRenduMonnaie(BigDecimal.ZERO);
        vente.setStatut(statut);
        vente.setModePaiement(ModePaiement.CREDIT);
        vente.setDateVente(LocalDateTime.now());
        utilisateurRepo.findById(1L).ifPresent(vente::setCaissier);
        venteRepo.save(vente);
    }

    @Transactional
    public VenteResponse create(VenteRequest req) {
        Long caissierId = req.getCaissierId() != null ? req.getCaissierId() : 1L;
        Utilisateur caissier = utilisateurRepo.findById(caissierId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Caissier introuvable"));

        Vente vente = new Vente();
        vente.setNumeroVente(genererNumero());
        vente.setCaissier(caissier);
        vente.setModePaiement(req.getModePaiement() != null ? req.getModePaiement() : ModePaiement.ESPECES);
        vente.setPatientNom(req.getPatientNom());
        vente.setTpeReference(req.getTpeReference());
        vente.setTpeAutorisation(req.getTpeAutorisation());
        vente.setTpeCarte(req.getTpeCarte());

        BigDecimal totalTtc = BigDecimal.ZERO;

        for (VenteRequest.LigneRequest lr : req.getLignes()) {
            Produit produit = produitRepo.findById(lr.getProduitId())
                .orElseThrow(() -> new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Médicament introuvable: " + lr.getProduitId()));

            // Vérifier stock disponible
            if (produit.getStock() < lr.getQuantite()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Stock insuffisant pour : " + produit.getDenomination()
                    + " (disponible: " + produit.getStock() + ")");
            }

            // Déduire le stock directement dans medicaments
            produit.setStock(produit.getStock() - lr.getQuantite());
            produitRepo.save(produit);

            BigDecimal prix      = parsePrix(produit.getPpv());
            BigDecimal sousTotal = prix.multiply(BigDecimal.valueOf(lr.getQuantite()))
                                       .setScale(2, RoundingMode.HALF_UP);

            LigneVente ligne = new LigneVente();
            ligne.setVente(vente);
            ligne.setProduit(produit);
            ligne.setQuantite(lr.getQuantite());
            ligne.setPrixUnitaire(prix);
            ligne.setTauxTva(BigDecimal.valueOf(7));
            ligne.setSousTotal(sousTotal);
            vente.getLignes().add(ligne);

            totalTtc = totalTtc.add(sousTotal);
        }

        BigDecimal tva = totalTtc.multiply(BigDecimal.valueOf(7))
                                  .divide(BigDecimal.valueOf(107), 2, RoundingMode.HALF_UP);
        vente.setTotalTtc(totalTtc);
        vente.setTotalTva(tva);
        vente.setTotalHt(totalTtc.subtract(tva));
        vente.setMontantRecu(req.getMontantRecu() != null ? req.getMontantRecu() : totalTtc);
        vente.setRenduMonnaie(vente.getMontantRecu().subtract(totalTtc).max(BigDecimal.ZERO));

        if (req.getModePaiement() == ModePaiement.CREDIT) {
            vente.setStatut(StatutVente.EN_ATTENTE);
            vente.setMontantRecu(BigDecimal.ZERO);
            vente.setRenduMonnaie(BigDecimal.ZERO);
        }

        VenteResponse response = toResponse(venteRepo.save(vente));

        if (vente.getStatut() == StatutVente.EN_ATTENTE && vente.getPatientNom() != null) {
            final BigDecimal montantCredit = vente.getTotalTtc();
            clientRepo.findByNomIgnoreCase(vente.getPatientNom().trim()).ifPresent(c -> {
                c.setCreditTotal(c.getCreditTotal() + montantCredit.doubleValue());
                clientRepo.save(c);
            });
        }

        boolean estPayee = vente.getStatut() == StatutVente.COMPLETEE;
        updateClientVisite(vente.getPatientNom(), estPayee);
        return response;
    }

    @Transactional
    public VenteResponse payerVenteById(Long venteId) {
        Vente vente = venteRepo.findById(venteId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Vente introuvable : " + venteId));

        if (vente.getStatut() != StatutVente.EN_ATTENTE) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cette vente est déjà réglée.");
        }

        vente.setStatut(StatutVente.COMPLETEE);
        vente.setMontantRecu(vente.getTotalTtc());
        vente.setDateVente(LocalDateTime.now());
        venteRepo.save(vente);

        if (vente.getPatientNom() != null) {
            final BigDecimal montant = vente.getTotalTtc();
            clientRepo.findByNomIgnoreCase(vente.getPatientNom().trim()).ifPresent(c -> {
                double nouveau = Math.max(0, c.getCreditTotal() - montant.doubleValue());
                c.setCreditTotal(nouveau);
                clientRepo.save(c);
            });
        }

        updateClientVisite(vente.getPatientNom(), true);
        return toResponse(vente);
    }

    private void updateClientVisite(String patientNom, boolean incrementAchats) {
        if (patientNom == null || patientNom.isBlank()) return;
        clientRepo.findByNomIgnoreCase(patientNom.trim()).ifPresent(c -> {
            c.setDerniereVisite(java.time.LocalDate.now());
            if (incrementAchats) c.setNombreAchats(c.getNombreAchats() + 1);
            clientRepo.save(c);
        });
    }

    private BigDecimal parsePrix(String val) {
        if (val == null || val.isBlank()) return BigDecimal.ZERO;
        String clean = val.trim().replace(" ", "");
        if (clean.contains(",")) {
            clean = clean.replace(".", "").replace(",", ".");
        }
        try { return new BigDecimal(clean).setScale(2, RoundingMode.HALF_UP); }
        catch (Exception e) { return BigDecimal.ZERO; }
    }

    private String genererNumero() {
        String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        long count  = venteRepo.count() + 1;
        return "V" + date + "-" + String.format("%04d", count);
    }

    VenteResponse toResponse(Vente v) {
        List<VenteResponse.LigneResponse> lignes = v.getLignes().stream().map(l ->
            new VenteResponse.LigneResponse(
                l.getId(),
                l.getProduit().getId(),
                l.getProduit().getDenomination(),
                l.getQuantite(),
                l.getPrixUnitaire(),
                l.getSousTotal()
            )
        ).toList();

        return new VenteResponse(
            v.getId(),
            v.getNumeroVente(),
            v.getDateVente().toString(),
            v.getTotalHt(),
            v.getTotalTva(),
            v.getTotalTtc(),
            v.getMontantRecu(),
            v.getRenduMonnaie(),
            v.getModePaiement().name(),
            v.getStatut().name(),
            v.getPatientNom(),
            v.getCaissier() != null
                ? v.getCaissier().getPrenom() + " " + v.getCaissier().getNom()
                : "",
            v.getTpeReference(),
            v.getTpeAutorisation(),
            v.getTpeCarte(),
            lignes
        );
    }
}
