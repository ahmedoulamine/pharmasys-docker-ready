package pharmasys_backend.vente;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/ventes")
public class VenteController {

    private final VenteService service;

    public VenteController(VenteService service) {
        this.service = service;
    }

    @GetMapping
    public Page<VenteResponse> findAll(
            @PageableDefault(size = 50) Pageable pageable) {
        return service.findAll(pageable);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public VenteResponse create(@RequestBody VenteRequest request) {
        return service.create(request);
    }

    @PostMapping("/credit-manuel")
    @ResponseStatus(HttpStatus.CREATED)
    public void createCreditManuel(
            @RequestParam String patientNom,
            @RequestParam BigDecimal montant) {
        service.creerVenteCreditManuel(patientNom, montant);
    }

    @PatchMapping("/{id}/payer")
    public VenteResponse payer(@PathVariable Long id) {
        return service.payerVenteById(id);
    }
}
