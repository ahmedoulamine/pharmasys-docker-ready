package pharmasys_backend.defectueux;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import pharmasys_backend.produit.Produit;
import pharmasys_backend.produit.ProduitRepository;

import java.time.LocalDate;
import java.util.List;

@Service
public class DefectueuxService {

    private final DefectueuxRepository repo;
    private final ProduitRepository produitRepo;

    public DefectueuxService(DefectueuxRepository repo, ProduitRepository produitRepo) {
        this.repo       = repo;
        this.produitRepo = produitRepo;
    }

    public List<DefectueuxResponse> findAll() {
        return repo.findByOrderByCreatedAtDesc().stream().map(this::toResponse).toList();
    }

    @Transactional
    public DefectueuxResponse create(DefectueuxRequest req) {
        Produit produit = produitRepo.findById(req.getProduitId())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Médicament introuvable"));

        if (req.getQuantiteConcernee() > produit.getStock()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                "Stock insuffisant. Disponible : " + produit.getStock());
        }

        produit.setStock(produit.getStock() - req.getQuantiteConcernee());
        produitRepo.save(produit);

        ProduitDefectueux d = new ProduitDefectueux();
        d.setProduit(produit);
        d.setTypeDefaut(req.getTypeDefaut() != null ? req.getTypeDefaut() : TypeDefaut.AUTRE);
        d.setDescription(req.getDescription() != null ? req.getDescription() : "");
        d.setQuantiteConcernee(req.getQuantiteConcernee());
        d.setDateDetection(req.getDateDetection() != null
            ? LocalDate.parse(req.getDateDetection()) : LocalDate.now());
        d.setSignaleParNom(req.getSignaledParNom());
        d.setPriorite(req.getPriorite() != null ? req.getPriorite() : Priorite.MOYENNE);

        return toResponse(repo.save(d));
    }

    private DefectueuxResponse toResponse(ProduitDefectueux d) {
        return new DefectueuxResponse(
            d.getId(),
            d.getProduit().getId(),
            d.getProduit().getDenomination(),
            d.getProduit().getCodeEan13(),
            d.getTypeDefaut(),
            d.getDescription(),
            d.getQuantiteConcernee(),
            d.getDateDetection(),
            d.getDateSignalement(),
            d.getSignaleParNom(),
            d.getPriorite(),
            d.getStatut(),
            d.getCreatedAt()
        );
    }
}
