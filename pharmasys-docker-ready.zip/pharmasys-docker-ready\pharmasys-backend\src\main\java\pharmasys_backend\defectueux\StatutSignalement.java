package pharmasys_backend.defectueux;

public enum StatutSignalement {
    EN_COURS, EN_ANALYSE, TRAITE, FERME
}
