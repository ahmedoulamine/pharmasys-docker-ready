package pharmasys_backend.achat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "lignes_achat")
public class LigneAchat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "achat_id")
    @JsonIgnore
    private Achat achat;

    private Long produitId;
    private String nom;
    private Integer quantite;
    private Double prixUnitaire;
}
