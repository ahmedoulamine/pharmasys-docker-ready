package pharmasys_backend.retour;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Data
@Entity
@Table(name = "retours")
public class Retour {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String reference;
    private String fournisseur;
    private LocalDate dateRetour;
    private String motif;

    @Column(columnDefinition = "TEXT")
    private String articlesList;

    private Integer articles;
    private Double montant;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatutRetour statut = StatutRetour.EN_ATTENTE;
}
