import { useState, useEffect, useCallback, useRef } from 'react'
import { searchMedicaments, fetchDefectueux, createDefectueux } from '../services/api'
import { AlertOctagon, CheckCircle, ClipboardList, Package, Search, X } from 'lucide-react'

const TYPE_DEFAUT_LABELS = {
  EMBALLAGE_ENDOMMAGE:       'Emballage endommagé',
  DATE_PEREMPTION_DEPASSEE:  'Date de péremption dépassée',
  RAPPEL_FABRICANT:          'Lot rappelé fabricant',
  CONTAMINATION_VISUELLE:    'Contamination visuelle',
  CONDITIONNEMENT_DEFECTUEUX:'Conditionnement défectueux',
  DOSAGE_INCORRECT:          'Dosage incorrect',
  CHAINE_FROID_ROMPUE:       'Chaîne de froid rompue',
  CORPS_ETRANGER:            'Corps étranger',
  ODEUR_COULEUR_ANORMALE:    'Odeur / couleur anormale',
  AUTRE:                     'Autre',
}

const TYPE_COLORS = {
  EMBALLAGE_ENDOMMAGE:       'bg-orange-100 text-orange-700',
  DATE_PEREMPTION_DEPASSEE:  'bg-red-100 text-red-700',
  RAPPEL_FABRICANT:          'bg-gray-100 text-gray-700',
  CONTAMINATION_VISUELLE:    'bg-yellow-100 text-yellow-700',
  CONDITIONNEMENT_DEFECTUEUX:'bg-orange-100 text-orange-700',
  DOSAGE_INCORRECT:          'bg-purple-100 text-purple-700',
  CHAINE_FROID_ROMPUE:       'bg-blue-100 text-blue-700',
  CORPS_ETRANGER:            'bg-yellow-100 text-yellow-700',
  ODEUR_COULEUR_ANORMALE:    'bg-pink-100 text-pink-700',
  AUTRE:                     'bg-gray-100 text-gray-600',
}

const PRIORITE_COLORS = {
  BASSE:    'bg-green-100 text-green-700',
  MOYENNE:  'bg-yellow-100 text-yellow-700',
  HAUTE:    'bg-orange-100 text-orange-700',
  CRITIQUE: 'bg-red-100 text-red-700',
}

const today = new Date().toISOString().split('T')[0]

const EMPTY_FORM = {
  produit: null,
  typeDefaut: 'EMBALLAGE_ENDOMMAGE',
  description: '',
  quantiteConcernee: 1,
  dateDetection: today,
  signaledParNom: '',
  priorite: 'MOYENNE',
}

export default function DefectiveProducts() {
  const [defectives, setDefectives] = useState([])
  const [form, setForm]             = useState(EMPTY_FORM)
  const [search, setSearch]         = useState('')
  const [searchResults, setSearchResults] = useState([])
  const [searchLoading, setSearchLoading] = useState(false)
  const [showDropdown, setShowDropdown]   = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess]       = useState(false)
  const [error, setError]           = useState('')
  const debounceRef = useRef(null)
  const dropdownRef = useRef(null)

  useEffect(() => {
    fetchDefectueux().then(setDefectives)
  }, [])

  const doSearch = useCallback(async (q) => {
    if (!q.trim()) { setSearchResults([]); return }
    setSearchLoading(true)
    try {
      const res = await searchMedicaments(q)
      setSearchResults(res)
      setShowDropdown(true)
    } catch { setSearchResults([]) }
    finally { setSearchLoading(false) }
  }, [])

  useEffect(() => {
    clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => doSearch(search), 300)
    return () => clearTimeout(debounceRef.current)
  }, [search, doSearch])

  useEffect(() => {
    function handleClick(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setShowDropdown(false)
      }
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [])

  function selectProduct(p) {
    setForm(f => ({ ...f, produit: p }))
    setSearch(p.nom)
    setShowDropdown(false)
  }

  function clearProduct() {
    setForm(f => ({ ...f, produit: null }))
    setSearch('')
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    if (!form.produit)               { setError('Veuillez sélectionner un produit.'); return }
    if (form.quantiteConcernee <= 0) { setError('La quantité doit être supérieure à 0.'); return }
    if (form.quantiteConcernee > form.produit.stock) {
      setError(`Stock insuffisant. Disponible : ${form.produit.stock} unités.`); return
    }

    setSubmitting(true)
    try {
      const created = await createDefectueux({
        produitId:         form.produit.id,
        typeDefaut:        form.typeDefaut,
        description:       form.description,
        quantiteConcernee: form.quantiteConcernee,
        dateDetection:     form.dateDetection,
        signaledParNom:    form.signaledParNom,
        priorite:          form.priorite,
      })
      setDefectives(prev => [created, ...prev])
      setForm(EMPTY_FORM)
      setSearch('')
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err.message || "Impossible d'enregistrer le signalement.")
    } finally {
      setSubmitting(false)
    }
  }

  const totalUnites  = defectives.reduce((s, d) => s + (d.quantiteConcernee ?? 0), 0)
  const nbPerimes    = defectives.filter(d => d.typeDefaut === 'DATE_PEREMPTION_DEPASSEE').length
  const nbRappels    = defectives.filter(d => d.typeDefaut === 'RAPPEL_FABRICANT').length
  const nbCritiques  = defectives.filter(d => d.priorite === 'CRITIQUE').length

  return (
    <div className="p-6 space-y-6">

      {/* Stats */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
          <div className="p-2.5 rounded-xl bg-red-50"><AlertOctagon className="w-5 h-5 text-red-500" /></div>
          <div>
            <p className="text-2xl font-bold text-gray-800">{defectives.length}</p>
            <p className="text-sm text-gray-500">Total signalements</p>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
          <div className="p-2.5 rounded-xl bg-orange-50"><Package className="w-5 h-5 text-orange-500" /></div>
          <div>
            <p className="text-2xl font-bold text-gray-800">{totalUnites}</p>
            <p className="text-sm text-gray-500">Unités retirées</p>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
          <div className="p-2.5 rounded-xl bg-red-50"><AlertOctagon className="w-5 h-5 text-red-400" /></div>
          <div>
            <p className="text-2xl font-bold text-gray-800">{nbPerimes}</p>
            <p className="text-sm text-gray-500">Périmés</p>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
          <div className="p-2.5 rounded-xl bg-red-50"><AlertOctagon className="w-5 h-5 text-red-600" /></div>
          <div>
            <p className="text-2xl font-bold text-gray-800">{nbCritiques}</p>
            <p className="text-sm text-gray-500">Priorité critique</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

        {/* Formulaire */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 className="font-semibold text-gray-800 flex items-center gap-2 mb-5">
              <AlertOctagon className="w-5 h-5 text-red-500" />
              Signaler un produit défectueux
            </h2>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-4 py-3 mb-4">{error}</div>
            )}
            {success && (
              <div className="bg-green-50 border border-green-200 text-green-700 text-sm rounded-xl px-4 py-3 mb-4 flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Signalement enregistré. Stock mis à jour.
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">

              {/* Recherche produit */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Produit *</label>
                <div className="relative" ref={dropdownRef}>
                  {form.produit ? (
                    <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-xl px-3 py-2.5">
                      <div>
                        <p className="text-sm font-semibold text-gray-800">{form.produit.nom}</p>
                        <p className="text-xs text-gray-500">Stock : {form.produit.stock} unités</p>
                      </div>
                      <button type="button" onClick={clearProduct} className="text-gray-400 hover:text-red-500 transition-colors">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        onFocus={() => searchResults.length > 0 && setShowDropdown(true)}
                        placeholder="Rechercher un médicament..."
                        className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-400"
                      />
                      {searchLoading && (
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 border-2 border-red-400 border-t-transparent rounded-full animate-spin" />
                      )}
                      {showDropdown && searchResults.length > 0 && (
                        <div className="absolute z-20 top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg max-h-48 overflow-y-auto">
                          {searchResults.map(p => (
                            <button key={p.id} type="button" onClick={() => selectProduct(p)}
                              className="w-full text-left px-4 py-2.5 hover:bg-gray-50 transition-colors border-b border-gray-50 last:border-0">
                              <p className="text-sm font-medium text-gray-800 truncate">{p.nom}</p>
                              <p className="text-xs text-gray-400">{p.formeDosage} — Stock : {p.stock}</p>
                            </button>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </div>
              </div>

              {/* Type de défaut */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Type de défaut *</label>
                <select value={form.typeDefaut}
                  onChange={e => setForm(f => ({ ...f, typeDefaut: e.target.value }))}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-400 bg-white">
                  {Object.entries(TYPE_DEFAUT_LABELS).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </div>

              {/* Quantité + Priorité */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Quantité *</label>
                  <input type="number" min={1}
                    max={form.produit?.stock ?? 9999}
                    value={form.quantiteConcernee}
                    onChange={e => setForm(f => ({ ...f, quantiteConcernee: parseInt(e.target.value) || 1 }))}
                    className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-400"
                    required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Priorité</label>
                  <select value={form.priorite}
                    onChange={e => setForm(f => ({ ...f, priorite: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-400 bg-white">
                    <option value="BASSE">Basse</option>
                    <option value="MOYENNE">Moyenne</option>
                    <option value="HAUTE">Haute</option>
                    <option value="CRITIQUE">Critique</option>
                  </select>
                </div>
              </div>

              {/* Date détection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Date de détection *</label>
                <input type="date" value={form.dateDetection}
                  onChange={e => setForm(f => ({ ...f, dateDetection: e.target.value }))}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-400"
                  required />
              </div>

              {/* Signalé par */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Signalé par</label>
                <input type="text" value={form.signaledParNom}
                  onChange={e => setForm(f => ({ ...f, signaledParNom: e.target.value }))}
                  placeholder="Nom du pharmacien..."
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-400" />
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Description / Observations</label>
                <textarea value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  placeholder="Détails supplémentaires..."
                  rows={3}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-400 resize-none" />
              </div>

              <button type="submit" disabled={submitting || !form.produit}
                className="w-full py-2.5 bg-red-500 hover:bg-red-600 disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors">
                {submitting ? 'Enregistrement...' : 'Enregistrer le signalement'}
              </button>
            </form>
          </div>
        </div>

        {/* Historique */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-gray-500" />
              <h2 className="font-semibold text-gray-800">Historique des signalements</h2>
              <span className="ml-auto text-xs bg-red-100 text-red-600 font-bold px-2 py-0.5 rounded-full">
                {defectives.length}
              </span>
            </div>

            {defectives.length === 0 ? (
              <div className="text-center py-16 text-gray-400">
                <AlertOctagon className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p>Aucun signalement enregistré</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-xs text-gray-400 border-b border-gray-100 bg-gray-50">
                      <th className="text-left px-5 py-3 font-medium">Date</th>
                      <th className="text-left px-4 py-3 font-medium">Produit</th>
                      <th className="text-center px-4 py-3 font-medium">Qté</th>
                      <th className="text-left px-4 py-3 font-medium">Type</th>
                      <th className="text-center px-4 py-3 font-medium">Priorité</th>
                      <th className="text-left px-4 py-3 font-medium">Signalé par</th>
                    </tr>
                  </thead>
                  <tbody>
                    {defectives.map(d => (
                      <tr key={d.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50/50">
                        <td className="px-5 py-3.5 text-gray-500 whitespace-nowrap text-xs">
                          {d.dateDetection ?? d.dateSignalement}
                        </td>
                        <td className="px-4 py-3.5">
                          <p className="font-semibold text-gray-800 text-sm truncate max-w-[140px]">{d.produitNom}</p>
                          <p className="text-xs font-mono text-gray-400">{d.produitEan13 || '—'}</p>
                        </td>
                        <td className="px-4 py-3.5 text-center">
                          <span className="font-bold text-red-600">{d.quantiteConcernee}</span>
                        </td>
                        <td className="px-4 py-3.5">
                          <span className={`text-xs font-medium px-2 py-1 rounded-full ${TYPE_COLORS[d.typeDefaut] ?? 'bg-gray-100 text-gray-600'}`}>
                            {TYPE_DEFAUT_LABELS[d.typeDefaut] ?? d.typeDefaut}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 text-center">
                          <span className={`text-xs font-medium px-2 py-1 rounded-full ${PRIORITE_COLORS[d.priorite] ?? 'bg-gray-100 text-gray-600'}`}>
                            {d.priorite}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 text-gray-500 text-xs">{d.signaledParNom || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
