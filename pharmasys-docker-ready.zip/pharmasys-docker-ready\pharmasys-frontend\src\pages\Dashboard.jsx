import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../api/axios.js";
import { AlertCircle, History, Package, ShoppingBag, TrendingUp, Users, RotateCcw, RefreshCcw } from "lucide-react";
import {
    LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
    BarChart, Bar, CartesianGrid
} from "recharts";

export default function Dashboard() {
    const [stats, setStats] = useState({
        ventesJour: 0, produitsAlerte: 0, alertesCritiques: 0,
        produitsPerimes: 0, transactions: 0, achatsMois: 0,
        commandesMois: 0, retours: 0, montantRetours: 0,
        patientsActifs: 0, nouveauxPatients: 0
    });
    const [ventesSemaine, setVentesSemaine] = useState([]);
    const [topProduits, setTopProduits]     = useState([]);
    const [alertesStock, setAlertesStock]   = useState([]);
    const [activite, setActivite]           = useState([]);
    const [loading, setLoading]             = useState(true);

    const navigate   = useNavigate();
    const role       = localStorage.getItem("role") || "TITULAIRE";
    const isTitulaire = role === "TITULAIRE";
    const isStock    = role === "RESPONSABLE_STOCK";
    const isEmploye  = role === "EMPLOYE";

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const [s, v, t, a, rec] = await Promise.all([
                axiosInstance.get("/dashboard/stats"),
                axiosInstance.get("/dashboard/ventes-semaine"),
                axiosInstance.get("/dashboard/top-produits"),
                axiosInstance.get("/dashboard/alertes-stock"),
                axiosInstance.get("/dashboard/activite")
            ]);
            setStats(s.data || {});
            setVentesSemaine(v.data || []);
            setTopProduits(t.data || []);
            setAlertesStock(a.data || []);
            setActivite(rec.data || []);
        } catch (e) {
            console.error("Erreur de synchronisation API:", e);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { loadData(); }, [loadData]);

    useEffect(() => {
        const onVisible = () => { if (document.visibilityState === 'visible') loadData(); };
        document.addEventListener('visibilitychange', onVisible);
        return () => document.removeEventListener('visibilitychange', onVisible);
    }, [loadData]);

    const handleCommander = (produit) => {
        navigate('/achats', {
            state: {
                openModal: true,
                produit: { name: produit.nom, quantite: Math.max(Math.round(produit.seuil * 2), 1) }
            }
        });
    };

    const fmt = (n) => `${Number(n || 0).toLocaleString("fr-MA")} DH`;

    if (loading) return <div style={{ padding: 40, color: "#6b7280" }}>Chargement des données en direct...</div>;

    const renderHeader = (title) => (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 25 }}>
            <h1 style={{ fontSize: 22, fontWeight: 700, margin: 0 }}>{title}</h1>
            <button onClick={loadData} style={refreshButtonStyle}>
                <RefreshCcw size={16} /> Actualiser
            </button>
        </div>
    );

    if (isEmploye) return (
        <div style={{ width: "100%", color: "#1f2937" }}>
            {renderHeader("Espace Vente")}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 28 }}>
                <KpiCard label="Transactions" value={stats.transactions} sub="Aujourd'hui" icon={<History size={20}/>} color="#3b82f6" bg="#eff6ff" />
                <KpiCard label="Patients actifs" value={stats.patientsActifs} sub={`+${stats.nouveauxPatients} ce mois`} icon={<Users size={20}/>} color="#10b981" bg="#ecfdf5" />
            </div>
            <div style={cardStyle}>
                <h3 style={cardTitleStyle}><History size={18} style={{marginRight: 8}} /> Activité récente</h3>
                <div style={{ display: "flex", flexDirection: "column" }}>
                    {activite.map((item, i) => (
                        <div key={i} style={activityRowStyle(i === activite.length - 1)}>
                            <div style={iconBoxStyle(item.type)}>{item.type === "vente" ? "🛒" : "👥"}</div>
                            <div style={{ marginLeft: 15 }}>
                                <div style={{ fontWeight: 600, fontSize: 14 }}>{item.label}</div>
                                <div style={{ fontSize: 12, color: "#9ca3af" }}>{item.temps || "À l'instant"}</div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );

    if (isStock) return (
        <div style={{ width: "100%", color: "#1f2937" }}>
            {renderHeader("Gestion des Stocks")}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20, marginBottom: 30 }}>
                <KpiCard label="Produits en alerte" value={stats.produitsAlerte} sub={`${stats.alertesCritiques} critiques`} icon={<AlertCircle size={20}/>} color="#f97316" bg="#fff7ed" />
                <KpiCard label="Produits périmés" value={stats.produitsPerimes} sub="Action requise" icon={<Package size={20}/>} color="#ef4444" bg="#fef2f2" />
                <KpiCard label="Commandes du mois" value={stats.commandesMois} sub="Suivi achats" icon={<ShoppingBag size={20}/>} color="#8b5cf6" bg="#f5f3ff" />
            </div>
            <div style={cardStyle}>
                <h3 style={cardTitleStyle}>Alertes de stock</h3>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                    {alertesStock.map((item, index) => (
                        <div key={index} style={alertRowStyle}>
                            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                                <AlertCircle size={20} color="#f97316" />
                                <span style={{ fontWeight: 600, fontSize: 14 }}>{item.nom}</span>
                            </div>
                            <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
                                <span style={{ fontSize: 13 }}>Stock: <b style={{color: "#ef4444"}}>{item.stock}</b> / Seuil: {item.seuil}</span>
                                <button onClick={() => handleCommander(item)} style={orderButtonStyle}>Commander</button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );

    return (
        <div style={{ width: "100%", color: "#1f2937" }}>
            {renderHeader(isTitulaire ? "Administration Pharmacie" : "Tableau de Bord")}

            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20, marginBottom: 20 }}>
                <KpiCard label="Ventes du jour" value={fmt(stats.ventesJour)} sub="Chiffre d'affaires" icon={<TrendingUp size={20}/>} color="#10b981" bg="#ecfdf5" />
                <KpiCard label="Alertes Stock" value={stats.produitsAlerte} sub={`${stats.alertesCritiques} critiques`} icon={<AlertCircle size={20}/>} color="#f97316" bg="#fff7ed" />
                <KpiCard label="Produits périmés" value={stats.produitsPerimes} sub="Urgents" icon={<Package size={20}/>} color="#ef4444" bg="#fef2f2" />
                <KpiCard label="Transactions" value={stats.transactions} sub="Volume jour" icon={<History size={20}/>} color="#3b82f6" bg="#eff6ff" />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20, marginBottom: 30 }}>
                <KpiCard label="Achats du mois" value={fmt(stats.achatsMois)} sub={`${stats.commandesMois} commandes`} icon={<ShoppingBag size={20}/>} color="#8b5cf6" bg="#f5f3ff" />
                <KpiCard label="Retours en attente" value={stats.retours} sub={fmt(stats.montantRetours)} icon={<RotateCcw size={20}/>} color="#ef4444" bg="#fef2f2" />
                <KpiCard label="Patients actifs" value={stats.patientsActifs} sub={`+${stats.nouveauxPatients} nouveaux`} icon={<Users size={20}/>} color="#3b82f6" bg="#eff6ff" />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1.2fr 0.8fr", gap: 20, marginBottom: 30 }}>
                <div style={cardStyle}>
                    <h3 style={cardTitleStyle}>Ventes de la semaine</h3>
                    <ResponsiveContainer width="100%" height={250}>
                        <LineChart data={ventesSemaine}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                            <XAxis dataKey="jour" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} />
                            <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} />
                            <Tooltip />
                            <Line type="monotone" dataKey="ventes" stroke="#10b981" strokeWidth={3} dot={{ r: 4, fill: '#10b981' }} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
                <div style={cardStyle}>
                    <h3 style={cardTitleStyle}>Top Produits (Unités)</h3>
                    <ResponsiveContainer width="100%" height={250}>
                        <BarChart data={topProduits}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                            <XAxis dataKey="nom" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 11}} />
                            <YAxis axisLine={false} tickLine={false} />
                            <Tooltip cursor={{fill: '#f9fafb'}} />
                            <Bar dataKey="unites" fill="#10b981" radius={[4, 4, 0, 0]} barSize={40} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            <div style={cardStyle}>
                <h3 style={cardTitleStyle}>Alertes de stock prioritaires</h3>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                    {alertesStock.slice(0, 5).map((item, index) => (
                        <div key={index} style={alertRowStyle}>
                            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                                <AlertCircle size={20} color="#f97316" />
                                <span style={{ fontWeight: 600, fontSize: 14 }}>{item.nom}</span>
                            </div>
                            <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
                                <span style={{ fontSize: 13 }}>Stock: <b style={{color: "#ef4444"}}>{item.stock}</b> / Seuil: {item.seuil}</span>
                                <button onClick={() => handleCommander(item)} style={orderButtonStyle}>Commander</button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

function KpiCard({ label, value, sub, icon, color, bg }) {
    return (
        <div style={{ ...cardStyle, display: "flex", justifyContent: "space-between", alignItems: "start", padding: "20px" }}>
            <div>
                <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 8 }}>{label}</div>
                <div style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>{value}</div>
                <div style={{ fontSize: 12, color: "#9ca3af" }}>{sub}</div>
            </div>
            <div style={{ width: 42, height: 42, borderRadius: 10, background: bg, color: color, display: "flex", alignItems: "center", justifyContent: "center" }}>
                {icon}
            </div>
        </div>
    );
}

const cardStyle          = { background: "#fff", borderRadius: 12, padding: "24px", border: "1px solid #f3f4f6", boxShadow: "0 1px 3px rgba(0,0,0,0.02)" };
const cardTitleStyle     = { fontSize: 15, fontWeight: 600, marginBottom: 20, color: "#111827", display: "flex", alignItems: "center" };
const alertRowStyle      = { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 20px", background: "#fff7ed", border: "1px solid #ffedd5", borderRadius: 12 };
const orderButtonStyle   = { background: "#10b981", color: "#fff", border: "none", padding: "8px 18px", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer" };
const refreshButtonStyle = { background: "#fff", border: "1px solid #e5e7eb", padding: "8px 14px", borderRadius: 8, cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 500 };
const activityRowStyle   = (isLast) => ({ display: "flex", alignItems: "center", padding: "12px 0", borderBottom: isLast ? "none" : "1px solid #f3f4f6" });
const iconBoxStyle       = (type) => ({ width: 36, height: 36, borderRadius: 8, background: type === "vente" ? "#ecfdf5" : "#eff6ff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 });
