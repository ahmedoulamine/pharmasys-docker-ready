package pharmasys_backend.caisse;

public enum StatutCaisse {
    OUVERTE, FERMEE
}
