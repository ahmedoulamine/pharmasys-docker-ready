package pharmasys_backend.rapport;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/rapports")
@RequiredArgsConstructor
public class RapportController {

    private final RapportService rapportService;

    @GetMapping("/stats")
    public Map<String, Object> getStats(@RequestParam(defaultValue = "mois") String periode) {
        return rapportService.getStats(periode);
    }

    @GetMapping("/ventes-mensuelles")
    public List<Map<String, Object>> getVentesMensuelles() {
        return rapportService.getVentesParMois();
    }

    @GetMapping("/ventes-categories")
    public List<Map<String, Object>> getVentesCategories(@RequestParam(defaultValue = "mois") String periode) {
        return rapportService.getVentesParCategorie(periode);
    }

    @GetMapping("/top-produits")
    public List<Map<String, Object>> getTopProduits() {
        return rapportService.getTopProduits();
    }

    @GetMapping("/performance-hebdo")
    public List<Map<String, Object>> getPerformanceHebdo(@RequestParam(defaultValue = "semaine") String periode) {
        return rapportService.getPerformanceHebdo(periode);
    }
}
