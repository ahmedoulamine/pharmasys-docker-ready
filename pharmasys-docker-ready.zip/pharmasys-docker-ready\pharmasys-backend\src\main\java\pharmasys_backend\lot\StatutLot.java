package pharmasys_backend.lot;

public enum StatutLot {
    EN_STOCK, EPUISE, RETIRE, RAPPEL_FABRICANT, QUARANTAINE
}
