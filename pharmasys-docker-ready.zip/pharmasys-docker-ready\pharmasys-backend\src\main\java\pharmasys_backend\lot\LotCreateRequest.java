package pharmasys_backend.lot;

public class LotCreateRequest {
    private Long    produitId;
    private String  numeroLot;
    private String  datePeremption;       // YYYY-MM-DD
    private Integer quantite;
    private String  fournisseur;
    private String  numeroBonLivraison;
    private Double  prixAchat;

    public Long    getProduitId()          { return produitId; }
    public String  getNumeroLot()          { return numeroLot; }
    public String  getDatePeremption()     { return datePeremption; }
    public Integer getQuantite()           { return quantite; }
    public String  getFournisseur()        { return fournisseur; }
    public String  getNumeroBonLivraison() { return numeroBonLivraison; }
    public Double  getPrixAchat()          { return prixAchat; }

    public void setProduitId(Long v)          { this.produitId = v; }
    public void setNumeroLot(String v)        { this.numeroLot = v; }
    public void setDatePeremption(String v)   { this.datePeremption = v; }
    public void setQuantite(Integer v)        { this.quantite = v; }
    public void setFournisseur(String v)      { this.fournisseur = v; }
    public void setNumeroBonLivraison(String v){ this.numeroBonLivraison = v; }
    public void setPrixAchat(Double v)        { this.prixAchat = v; }
}
