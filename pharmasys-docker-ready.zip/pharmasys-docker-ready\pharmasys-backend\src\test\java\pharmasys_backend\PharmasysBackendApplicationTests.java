package pharmasys_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmasysBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
