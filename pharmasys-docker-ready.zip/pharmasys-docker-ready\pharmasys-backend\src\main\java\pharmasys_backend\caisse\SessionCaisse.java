package pharmasys_backend.caisse;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Data
@Entity
@Table(name = "caisse_sessions")
public class SessionCaisse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate dateSession;
    private String heureOuverture;
    private String heureCloture;
    private Double fondOuverture;
    private Double fondCloture;

    @Column(nullable = false)
    private Double totalVentes = 0.0;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatutCaisse statut = StatutCaisse.OUVERTE;
}
