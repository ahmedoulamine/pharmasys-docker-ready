import { useState, useEffect, useRef } from "react";
import axiosInstance from "../api/axios.js";
import { searchMedicaments, createVenteCredit } from "../services/api";

const initialForm = { nom: "", telephone: "", email: "", creditTotal: 0 };

const s = {
  card:    { background: "#fff", borderRadius: 12, padding: "20px 24px", border: "1px solid #f0f0f0", boxShadow: "0 1px 4px rgba(0,0,0,0.05)" },
  btn:     (color="#10b981") => ({ background: color, color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", cursor: "pointer", fontWeight: 600, fontSize: 13 }),
  ghost:   { background: "none", border: "1px solid #e5e7eb", borderRadius: 8, padding: "10px 18px", cursor: "pointer", fontWeight: 600, fontSize: 13, color: "#374151" },
  input:   { width: "100%", padding: "11px 14px", borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 14, boxSizing: "border-box", outline: "none" },
  label:   { fontSize: 13, fontWeight: 600, display: "block", marginBottom: 7, color: "#374151" },
};

export default function Patients() {
  const [patients, setPatients]       = useState([]);
  const [stats, setStats]             = useState({ total: 0, avecCredit: 0, creditTotal: 0 });
  const [ventesJour, setVentesJour]   = useState(null); // CA du jour en temps réel
  const [search, setSearch]           = useState("");
  const [modal, setModal]             = useState(false);
  const [form, setForm]               = useState(initialForm);
  const [editId, setEditId]           = useState(null);
  const [loading, setLoading]         = useState(true);
  const [saving, setSaving]           = useState(false);
  const [error, setError]             = useState(null);
  const [formError, setFormError]     = useState(null);
  const [successMsg, setSuccessMsg]   = useState(null);

  // profil patient
  const [profil, setProfil]           = useState(null);
  const [ventes, setVentes]           = useState([]);
  const [ventesLoading, setVentesLoading] = useState(false);

  // opérations crédit
  const [creditModal, setCreditModal] = useState(null); // "ajouter" | "paiement"
  const [creditForm, setCreditForm]   = useState({ description: "", produitId: null, quantite: 1, prixUnitaire: 0, montant: 0 });

  // autocomplétion médicaments
  const [medSuggestions, setMedSuggestions]   = useState([]);
  const [showMedSug, setShowMedSug]           = useState(false);
  const medDebounceRef = useRef(null);

  const refreshCA = async () => {
    try {
      const res = await axiosInstance.get("/dashboard/stats");
      setVentesJour(res.data?.ventesJour ?? null);
    } catch { /* silencieux */ }
  };

  useEffect(() => { loadData(); refreshCA(); }, []);

  // Recharger les stats quand l'onglet/la page redevient visible (ex: retour du POS)
  useEffect(() => {
    const onVisible = () => { if (document.visibilityState === 'visible') loadData(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, []);

  useEffect(() => {
    clearTimeout(medDebounceRef.current);
    const q = creditForm.description.trim();
    if (q.length < 1) { setMedSuggestions([]); return; }
    medDebounceRef.current = setTimeout(async () => {
      const res = await searchMedicaments(q);
      setMedSuggestions(res.slice(0, 6));
    }, 250);
    return () => clearTimeout(medDebounceRef.current);
  }, [creditForm.description]);

  const loadData = async (s = "") => {
    setLoading(true); setError(null);
    try {
      const params = s ? { search: s } : {};
      const [p, st] = await Promise.all([
        axiosInstance.get("/clients", { params }),
        axiosInstance.get("/clients/stats"),
      ]);
      setPatients(p.data || []);
      setStats(st.data || { total: 0, avecCredit: 0, creditTotal: 0 });
    } catch {
      setError("Impossible de charger les patients.");
    } finally { setLoading(false); }
  };

  const handleSearch = (e) => {
    const val = e.target.value; setSearch(val);
    clearTimeout(window._t);
    window._t = setTimeout(() => loadData(val), 300);
  };

  const showSuccess = (msg) => { setSuccessMsg(msg); setTimeout(() => setSuccessMsg(null), 3000); };

  const openAdd  = () => { setForm(initialForm); setEditId(null); setFormError(null); setModal(true); };
  const openEdit = (p) => { setForm({ nom: p.nom||"", telephone: p.telephone||"", email: p.email||"", creditTotal: p.creditTotal||0 }); setEditId(p.id); setFormError(null); setModal(true); };

  const handleSave = async () => {
    if (!form.nom.trim()) { setFormError("Le nom est obligatoire."); return; }
    setSaving(true); setFormError(null);
    try {
      if (editId) { await axiosInstance.put(`/clients/${editId}`, form); showSuccess("Patient modifié."); }
      else        { await axiosInstance.post("/clients", form);          showSuccess("Patient ajouté."); }
      setModal(false); loadData();
    } catch (e) { setFormError(e.response?.data?.message || "Erreur serveur."); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Supprimer ce patient ?")) return;
    try { await axiosInstance.delete(`/clients/${id}`); showSuccess("Patient supprimé."); loadData(); }
    catch { setError("Impossible de supprimer."); }
  };

  // ── Profil ───────────────────────────────────────────────────────────────
  const openProfil = async (patient) => {
    setProfil(patient); setVentes([]); setVentesLoading(true);
    try {
      const res = await axiosInstance.get(`/clients/${patient.id}/ventes`);
      setVentes(res.data || []);
    } catch { setVentes([]); }
    finally { setVentesLoading(false); }
  };

  const closeProfil = () => { setProfil(null); setVentes([]); setCreditModal(null); };

  const handlePayerVenteCredit = async (vente) => {
    const montant = formatMoney(vente.totalTtc ?? vente.montant);
    if (!window.confirm(`Confirmer le paiement de ${montant} pour cette vente ?`)) return;
    try {
      await axiosInstance.patch(`/ventes/${vente.id}/payer`);
      showSuccess(`Crédit payé : ${montant} — caisse mise à jour`);
      await Promise.all([refreshProfil(), refreshCA()]);
      const vRes = await axiosInstance.get(`/clients/${profil.id}/ventes`);
      setVentes(vRes.data || []);
    } catch (e) {
      const status = e.response?.status;
      const msg = e.response?.data?.message;
      if (status === 404) {
        alert("Endpoint introuvable — redémarrez le backend pour activer cette fonctionnalité.");
      } else {
        alert(msg || e.message || "Erreur lors du paiement");
      }
    }
  };

  const refreshProfil = async () => {
    const [p, st] = await Promise.all([
      axiosInstance.get("/clients", { params: search ? { search } : {} }),
      axiosInstance.get("/clients/stats"),
    ]);
    setPatients(p.data || []);
    setStats(st.data || stats);
    if (profil) {
      const updated = (p.data || []).find(x => x.id === profil.id);
      if (updated) setProfil(updated);
    }
  };

  // ── Opérations crédit ────────────────────────────────────────────────────
  const handleAjouterCredit = async () => {
    try {
      let montantCredit;

      if (creditForm.produitId) {
        // Médicament sélectionné → POST /ventes avec CREDIT, backend auto-met-à-jour creditTotal
        const vente = await createVenteCredit(profil.nom, creditForm.produitId, creditForm.quantite);
        montantCredit = vente.total;
      } else {
        // Description libre → POST /ventes/credit-manuel, backend auto-met-à-jour creditTotal
        montantCredit = creditForm.quantite * creditForm.prixUnitaire;
        if (montantCredit <= 0) { alert("Montant invalide"); return; }
        await axiosInstance.post(`/ventes/credit-manuel?patientNom=${encodeURIComponent(profil.nom)}&montant=${montantCredit}`);
      }

      // NE PAS appeler PATCH /credit → le backend le fait déjà automatiquement
      await axiosInstance.patch(`/clients/${profil.id}/visite?achat=false`);
      showSuccess(`Crédit ajouté : ${Number(montantCredit).toFixed(2)} DH`);
      setCreditModal(null);
      setCreditForm({ description: "", produitId: null, quantite: 1, prixUnitaire: 0, montant: 0 });
      await Promise.all([refreshProfil(), refreshCA()]);
      const vRes = await axiosInstance.get(`/clients/${profil.id}/ventes`);
      setVentes(vRes.data || []);
    } catch (e) { alert(e.message || "Erreur lors de l'ajout du crédit"); }
  };

  const handlePaiement = async () => {
    const montant = Number(creditForm.montant);
    if (montant <= 0) { alert("Montant invalide"); return; }
    try {
      // payer-credit : marque les ventes EN_ATTENTE comme COMPLETEE → CA augmente
      await axiosInstance.patch(`/clients/${profil.id}/payer-credit`, { montant });
      await axiosInstance.patch(`/clients/${profil.id}/visite?achat=true`);
      showSuccess(`Paiement reçu : ${montant.toFixed(2)} DH — CA du jour augmenté de ${montant.toFixed(2)} DH`);
      setCreditModal(null);
      setCreditForm({ description: "", produitId: null, quantite: 1, prixUnitaire: 0, montant: 0 });
      await Promise.all([refreshProfil(), refreshCA()]);
      const vRes = await axiosInstance.get(`/clients/${profil.id}/ventes`);
      setVentes(vRes.data || []);
    } catch (e) { alert(e.response?.data?.message || "Erreur lors de l'enregistrement du paiement"); }
  };

  // ── Helpers ──────────────────────────────────────────────────────────────
  const initiales   = (nom) => { const p = (nom||"").trim().split(" "); return p.length>=2?(p[0][0]+p[1][0]).toUpperCase():(nom||"?").slice(0,2).toUpperCase(); };
  const couleur     = (nom) => ["#d1fae5","#dbeafe","#fce7f3","#fef3c7","#ede9fe"][(nom||" ").charCodeAt(0)%5];
  const formatDate  = (s) => { try { return new Date(s).toLocaleDateString("fr-FR"); } catch { return s||"—"; } };
  const formatMoney = (v) => Number(v||0).toLocaleString("fr-FR", { minimumFractionDigits: 2 }) + " DH";

  // ── Render ───────────────────────────────────────────────────────────────
  return (
    <div style={{ padding: "28px 32px", fontFamily: "system-ui, sans-serif", minHeight: "100vh" }}>

      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, margin: 0, color: "#111" }}>Gestion des Patients</h1>
        <p style={{ color: "#6b7280", margin: "6px 0 0", fontSize: 14 }}>Suivi des clients et de leurs crédits</p>
      </div>

      {successMsg && <div style={{ background:"#f0fdf4", border:"1px solid #86efac", borderRadius:10, padding:"12px 16px", marginBottom:18, color:"#166534", fontSize:14 }}>✅ {successMsg}</div>}
      {error      && <div style={{ background:"#fee2e2", border:"1px solid #fca5a5", borderRadius:10, padding:"12px 16px", marginBottom:18, color:"#dc2626", fontSize:14 }}>❌ {error}</div>}

      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16, marginBottom:24 }}>
        <div style={s.card}><div style={{ color:"#6b7280", fontSize:13, marginBottom:8 }}>👤 Total patients</div><div style={{ fontSize:32, fontWeight:700, color:"#111" }}>{stats.total}</div></div>
        <div style={{ ...s.card, background:"#fff8f0", border:"1px solid #fed7aa" }}><div style={{ color:"#c2410c", fontSize:13, marginBottom:8 }}>💳 Crédit total</div><div style={{ fontSize:32, fontWeight:700, color:"#c2410c" }}>{Number(stats.creditTotal||0).toFixed(2)} DH</div></div>
        <div style={s.card}><div style={{ color:"#6b7280", fontSize:13, marginBottom:8 }}>⚠️ Avec crédit</div><div style={{ fontSize:32, fontWeight:700, color:"#111" }}>{stats.avecCredit}</div></div>
      </div>

      {/* Toolbar */}
      <div style={{ display:"flex", gap:12, marginBottom:20 }}>
        <div style={{ position:"relative", flex:1 }}>
          <span style={{ position:"absolute", left:12, top:"50%", transform:"translateY(-50%)", color:"#9ca3af" }}>🔍</span>
          <input value={search} onChange={handleSearch} placeholder="Rechercher un patient..."
            style={{ ...s.input, paddingLeft:38 }} />
        </div>
        <button onClick={openAdd} style={s.btn()}>＋ Ajouter un patient</button>
      </div>

      {/* Table */}
      <div style={{ ...s.card, padding:0, overflow:"hidden" }}>
        {loading ? (
          <div style={{ padding:40, textAlign:"center", color:"#9ca3af" }}>⏳ Chargement...</div>
        ) : (
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:14 }}>
            <thead>
              <tr style={{ borderBottom:"1px solid #e5e7eb", background:"#fafafa" }}>
                {["Patient","Contact","Crédit","Dernière visite","Actions"].map(h => (
                  <th key={h} style={{ textAlign:"left", padding:"13px 18px", color:"#9ca3af", fontWeight:500, fontSize:13 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {patients.length === 0 ? (
                <tr><td colSpan={5} style={{ padding:40, textAlign:"center", color:"#9ca3af" }}>Aucun patient trouvé</td></tr>
              ) : patients.map(p => (
                <tr key={p.id} style={{ borderBottom:"1px solid #f3f4f6" }}
                  onMouseEnter={e => e.currentTarget.style.background="#fafafa"}
                  onMouseLeave={e => e.currentTarget.style.background="transparent"}>
                  <td style={{ padding:"14px 18px" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                      <div style={{ width:38, height:38, borderRadius:"50%", background:couleur(p.nom), display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:13, color:"#374151", flexShrink:0 }}>
                        {initiales(p.nom)}
                      </div>
                      <div>
                        <div style={{ fontWeight:600, color:"#111" }}>{p.nom}</div>
                        <div style={{ fontSize:12, color:"#9ca3af" }}>{p.nombreAchats || 0} achat(s)</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding:"14px 18px", color:"#6b7280" }}>
                    <div style={{ fontSize:13 }}>{p.telephone||"—"}</div>
                    <div style={{ fontSize:12, color:"#9ca3af" }}>{p.email||"—"}</div>
                  </td>
                  <td style={{ padding:"14px 18px" }}>
                    {(p.creditReel ?? p.creditTotal ?? 0) > 0
                      ? <span style={{ background:"#fed7aa", color:"#c2410c", padding:"4px 12px", borderRadius:20, fontWeight:600, fontSize:13 }}>{Number(p.creditReel ?? p.creditTotal).toFixed(2)} DH</span>
                      : <span style={{ color:"#9ca3af" }}>—</span>}
                  </td>
                  <td style={{ padding:"14px 18px", color:"#6b7280", fontSize:13 }}>🕐 {p.derniereVisite||"—"}</td>
                  <td style={{ padding:"14px 18px" }}>
                    <button onClick={() => openProfil(p)} style={{ color:"#2563eb", background:"none", border:"none", cursor:"pointer", fontWeight:600, fontSize:13, marginRight:12 }}>👁 Profil</button>
                    <button onClick={() => openEdit(p)}   style={{ color:"#10b981", background:"none", border:"none", cursor:"pointer", fontWeight:500, fontSize:13, marginRight:12 }}>Modifier</button>
                    <button onClick={() => handleDelete(p.id)} style={{ color:"#ef4444", background:"none", border:"none", cursor:"pointer", fontSize:13 }}>Supprimer</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* ── Modal ajout/modif ─────────────────────────────────────────────── */}
      {modal && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.45)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:1000 }}>
          <div style={{ background:"#fff", borderRadius:16, padding:"32px 36px", width:460, position:"relative", boxShadow:"0 20px 60px rgba(0,0,0,0.15)" }}>
            <button onClick={() => setModal(false)} style={{ position:"absolute", top:16, right:16, background:"none", border:"none", cursor:"pointer", fontSize:20, color:"#9ca3af" }}>✕</button>
            <h2 style={{ margin:"0 0 24px", fontSize:19, fontWeight:700, color:"#111" }}>
              {editId ? "✏️ Modifier le patient" : "➕ Nouveau patient"}
            </h2>
            {formError && <div style={{ background:"#fee2e2", color:"#dc2626", padding:"10px 14px", borderRadius:8, fontSize:13, marginBottom:16 }}>⚠️ {formError}</div>}
            {[
              { label:"Nom complet *", key:"nom",         type:"text",   placeholder:"Ex: Fatima Alaoui" },
              { label:"Téléphone",     key:"telephone",   type:"text",   placeholder:"+212 6 XX XX XX XX" },
              { label:"Email",         key:"email",       type:"email",  placeholder:"exemple@email.ma" },
              { label:"Crédit (DH)",   key:"creditTotal", type:"number", placeholder:"0" },
            ].map(f => (
              <div key={f.key} style={{ marginBottom:18 }}>
                <label style={s.label}>{f.label}</label>
                <input type={f.type} value={form[f.key]} placeholder={f.placeholder}
                  onChange={e => setForm({ ...form, [f.key]: f.type==="number" ? +e.target.value : e.target.value })}
                  style={s.input}
                  onFocus={e => e.target.style.borderColor="#10b981"}
                  onBlur={e => e.target.style.borderColor="#e5e7eb"}
                />
              </div>
            ))}
            <div style={{ display:"flex", gap:10, marginTop:8 }}>
              <button onClick={() => setModal(false)} style={{ flex:1, background:"#f3f4f6", color:"#374151", border:"none", borderRadius:8, padding:"12px", fontWeight:600, cursor:"pointer", fontSize:14 }}>Annuler</button>
              <button onClick={handleSave} disabled={saving} style={{ flex:2, ...s.btn(), padding:"12px", fontSize:14, opacity:saving?0.7:1 }}>
                {saving ? "Enregistrement..." : editId ? "Enregistrer" : "Ajouter"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Panel Profil patient ──────────────────────────────────────────── */}
      {profil && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.4)", display:"flex", justifyContent:"flex-end", zIndex:1000 }}>
          <div style={{ background:"#fff", width:"min(680px, 100vw)", height:"100vh", overflowY:"auto", padding:"32px 36px", boxShadow:"-4px 0 30px rgba(0,0,0,0.12)", display:"flex", flexDirection:"column", gap:24 }}>

            {/* Header */}
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
              <div style={{ display:"flex", alignItems:"center", gap:16 }}>
                <div style={{ width:56, height:56, borderRadius:"50%", background:couleur(profil.nom), display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:20, color:"#374151" }}>
                  {initiales(profil.nom)}
                </div>
                <div>
                  <h2 style={{ margin:0, fontSize:20, fontWeight:700, color:"#111" }}>{profil.nom}</h2>
                  <p style={{ margin:"4px 0 0", color:"#6b7280", fontSize:13 }}>
                    {profil.nombreAchats||0} achat(s) • Dernière visite : {profil.derniereVisite||"—"}
                  </p>
                </div>
              </div>
              <button onClick={closeProfil} style={{ background:"none", border:"none", cursor:"pointer", fontSize:22, color:"#9ca3af" }}>✕</button>
            </div>

            {/* Infos */}
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
              <div style={s.card}><div style={{ color:"#6b7280", fontSize:12, marginBottom:4 }}>Téléphone</div><div style={{ fontWeight:600 }}>{profil.telephone||"—"}</div></div>
              <div style={s.card}><div style={{ color:"#6b7280", fontSize:12, marginBottom:4 }}>Email</div><div style={{ fontWeight:600 }}>{profil.email||"—"}</div></div>
            </div>

            {/* Crédit */}
            {(() => {
              const creditEnAttente = ventes
                .filter(v => v.statut === 'EN_ATTENTE')
                .reduce((sum, v) => sum + Number(v.totalTtc ?? v.montant ?? 0), 0);
              const creditAffiche = ventesLoading
                ? (profil.creditReel ?? profil.creditTotal ?? 0)
                : creditEnAttente;
              return (
                <div style={{ background: creditAffiche > 0 ? "#fff8f0" : "#f0fdf4", border:`1px solid ${creditAffiche > 0 ? "#fed7aa" : "#86efac"}`, borderRadius:12, padding:"20px 24px" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <div>
                      <div style={{ fontSize:13, color:"#6b7280", marginBottom:4 }}>Crédit en cours</div>
                      <div style={{ fontSize:28, fontWeight:700, color: creditAffiche > 0 ? "#c2410c" : "#16a34a" }}>
                        {formatMoney(creditAffiche)}
                      </div>
                    </div>
                    <div style={{ display:"flex", gap:10 }}>
                      <button onClick={() => { setCreditModal("ajouter"); setCreditForm({ description:"", quantite:1, prixUnitaire:0, montant:0 }); }} style={s.btn("#ea580c")}>
                        + Nouvelle opération crédit
                      </button>
                      {creditAffiche > 0 && (
                        <button onClick={() => { setCreditModal("paiement"); setCreditForm({ description:"", quantite:1, prixUnitaire:0, montant:creditAffiche }); }} style={s.btn("#16a34a")}>
                          💰 Enregistrer paiement
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Modal crédit */}
            {creditModal === "ajouter" && (
              <div style={{ background:"#fff8f0", border:"1px solid #fed7aa", borderRadius:12, padding:"20px 24px" }}>
                <h3 style={{ margin:"0 0 16px", fontSize:15, color:"#ea580c" }}>Nouvelle opération crédit</h3>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
                  <div style={{ position:"relative" }}>
                    <label style={s.label}>Médicament / Description</label>
                    <input style={s.input} placeholder="Ex: Amoxicilline 500mg" value={creditForm.description}
                      onChange={e => { setCreditForm(f => ({ ...f, description: e.target.value, produitId: null })); setShowMedSug(true); }}
                      onFocus={() => setShowMedSug(true)}
                      onBlur={() => setTimeout(() => setShowMedSug(false), 180)}
                      autoComplete="off"
                    />
                    {showMedSug && medSuggestions.length > 0 && (
                      <div style={{ position:"absolute", top:"100%", left:0, right:0, background:"#fff", border:"1px solid #e5e7eb", borderRadius:10, boxShadow:"0 8px 24px rgba(0,0,0,0.10)", zIndex:100, overflow:"hidden", marginTop:3 }}>
                        {medSuggestions.map(m => (
                          <div key={m.id}
                            onMouseDown={() => {
                              setCreditForm(f => ({ ...f, description: m.nom, produitId: m.id, prixUnitaire: m.prixVente }));
                              setShowMedSug(false); setMedSuggestions([]);
                            }}
                            style={{ padding:"9px 14px", cursor:"pointer", fontSize:13, borderBottom:"1px solid #f3f4f6", display:"flex", justifyContent:"space-between", alignItems:"center" }}
                            onMouseEnter={e => e.currentTarget.style.background="#fff8f0"}
                            onMouseLeave={e => e.currentTarget.style.background="#fff"}
                          >
                            <span style={{ fontWeight:600, color:"#111" }}>{m.nom}</span>
                            <span style={{ color:"#ea580c", fontWeight:700, fontSize:13 }}>{m.prixVente.toFixed(2)} DH</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div>
                    <label style={s.label}>Quantité</label>
                    <input type="number" min={1} style={s.input} value={creditForm.quantite}
                      onChange={e => setCreditForm(f => ({ ...f, quantite: Number(e.target.value) }))} />
                  </div>
                  <div>
                    <label style={s.label}>Prix unitaire (DH)</label>
                    <input type="number" min={0} style={s.input} value={creditForm.prixUnitaire}
                      onChange={e => setCreditForm(f => ({ ...f, prixUnitaire: Number(e.target.value) }))} />
                  </div>
                  <div style={{ display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
                    <div style={{ background:"#fff", border:"1px solid #e5e7eb", borderRadius:8, padding:"11px 14px", fontSize:14, fontWeight:700, color:"#c2410c" }}>
                      Total : {(creditForm.quantite * creditForm.prixUnitaire).toFixed(2)} DH
                    </div>
                  </div>
                </div>
                <div style={{ display:"flex", gap:10 }}>
                  <button onClick={() => setCreditModal(null)} style={{ ...s.ghost, flex:1 }}>Annuler</button>
                  <button onClick={handleAjouterCredit} style={{ ...s.btn("#ea580c"), flex:2 }}>Valider et ajouter au crédit</button>
                </div>
              </div>
            )}

            {creditModal === "paiement" && (
              <div style={{ background:"#f0fdf4", border:"1px solid #86efac", borderRadius:12, padding:"20px 24px" }}>
                <h3 style={{ margin:"0 0 16px", fontSize:15, color:"#16a34a" }}>Enregistrer un paiement</h3>
                <div style={{ marginBottom:12 }}>
                  <label style={s.label}>Montant payé (DH) — Crédit restant : {formatMoney(creditForm.montant || 0)}</label>
                  <input type="number" min={0} style={s.input} value={creditForm.montant}
                    onChange={e => setCreditForm(f => ({ ...f, montant: Number(e.target.value) }))} />
                </div>
                <div style={{ display:"flex", gap:10 }}>
                  <button onClick={() => setCreditModal(null)} style={{ ...s.ghost, flex:1 }}>Annuler</button>
                  <button onClick={handlePaiement} style={{ ...s.btn("#16a34a"), flex:2 }}>Confirmer le paiement</button>
                </div>
              </div>
            )}

            {/* Crédits en attente */}
            {ventesLoading ? null : (() => {
              const creditsAttente = ventes.filter(v => v.statut === 'EN_ATTENTE');
              if (creditsAttente.length === 0) return null;
              return (
                <div>
                  <h3 style={{ margin:"0 0 14px", fontSize:15, fontWeight:700, color:"#c2410c", display:"flex", alignItems:"center", gap:8 }}>
                    💳 Crédits en attente ({creditsAttente.length})
                  </h3>
                  {creditsAttente.map(v => (
                    <div key={v.id} style={{ background:"#fff8f0", borderRadius:12, padding:"16px 20px", marginBottom:12, border:"1px solid #fed7aa" }}>
                      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:(v.lignes||[]).length > 0 ? 10 : 0 }}>
                        <div>
                          <span style={{ fontSize:12, color:"#9ca3af" }}>📅 {formatDate(v.dateVente)}</span>
                          <span style={{ marginLeft:10, fontSize:12, background:"#fed7aa", color:"#c2410c", padding:"2px 8px", borderRadius:8, fontWeight:600 }}>EN ATTENTE</span>
                        </div>
                        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                          <span style={{ fontWeight:700, fontSize:16, color:"#c2410c" }}>{formatMoney(v.totalTtc ?? v.montant)}</span>
                          <button onClick={() => handlePayerVenteCredit(v)} style={{ ...s.btn("#16a34a"), padding:"8px 16px", fontSize:12 }}>
                            💰 Payer ce crédit
                          </button>
                        </div>
                      </div>
                      {(v.lignes||[]).map((l, i) => (
                        <div key={i} style={{ display:"flex", justifyContent:"space-between", fontSize:13, color:"#6b7280", padding:"4px 0", borderTop:"1px solid #ffe4c4" }}>
                          <span>📦 {l.nom || '—'} <span style={{ color:"#9ca3af" }}>× {l.quantite}</span></span>
                          <span>{formatMoney(l.sousTotal)}</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              );
            })()}

            {/* Historique de tous les achats */}
            <div>
              <h3 style={{ margin:"0 0 14px", fontSize:15, fontWeight:700, color:"#111" }}>
                Historique des achats ({ventes.length})
              </h3>
              {ventesLoading ? (
                <div style={{ textAlign:"center", color:"#9ca3af", padding:20 }}>⏳ Chargement...</div>
              ) : ventes.length === 0 ? (
                <div style={{ textAlign:"center", color:"#9ca3af", padding:20, background:"#fafafa", borderRadius:12 }}>
                  Aucun achat enregistré au nom de ce patient
                </div>
              ) : ventes.map(v => {
                const isCredit = v.statut === 'EN_ATTENTE';
                return (
                  <div key={v.id} style={{ background: isCredit ? "#fff8f0" : "#fafafa", borderRadius:12, padding:"16px 20px", marginBottom:12, border:`1px solid ${isCredit ? "#fed7aa" : "#e5e7eb"}` }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap" }}>
                        <span style={{ fontSize:12, color:"#9ca3af" }}>📅 {formatDate(v.dateVente)}</span>
                        <span style={{ fontSize:12, padding:"2px 8px", borderRadius:8, fontWeight:600,
                          background: isCredit ? "#fed7aa" : "#dcfce7",
                          color:      isCredit ? "#c2410c" : "#15803d" }}>
                          {isCredit ? "CRÉDIT" : "PAYÉ"}
                        </span>
                        {v.modePaiement && (
                          <span style={{ fontSize:11, color:"#9ca3af" }}>{v.modePaiement}</span>
                        )}
                      </div>
                      <span style={{ fontWeight:700, fontSize:15, color: isCredit ? "#c2410c" : "#111" }}>
                        {formatMoney(v.totalTtc ?? v.montant)}
                      </span>
                    </div>
                    {(v.lignes||[]).map((l, i) => (
                      <div key={i} style={{ display:"flex", justifyContent:"space-between", fontSize:13, color:"#6b7280", padding:"4px 0", borderTop:"1px solid #f3f4f6" }}>
                        <span>📦 {l.nom || '—'} <span style={{ color:"#9ca3af" }}>× {l.quantite}</span></span>
                        <span>{formatMoney(l.sousTotal)}</span>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
