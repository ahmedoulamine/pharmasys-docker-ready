import axiosInstance from "../api/axios";

function mapProduit(p) {
  return {
    id:               p.id,
    name:             p.denomination       ?? '',
    dosage:           p.formeDosage        ?? '',
    barcode:          p.codeEan13          ?? '',
    price:            p.ppv                ?? 0,
    therapeuticClass: p.classeTherapeutique ?? '',
    composition:      p.dci                ?? '',
    priceHt:          p.pa                 ?? '',
    stock:            p.stock              ?? 0,
    stockMin:         p.stockMinimum       ?? 0,
    dateExpiration:   p.dateExpiration     ?? null,
  }
}

export const getAllProducts = (page = 0, size = 20, search = "") =>
  axiosInstance
    .get(`/produits`, { params: { page, size, sort: 'denomination', ...(search ? { search } : {}) } })
    .then(res => ({
      data: {
        ...res.data,
        content: (res.data.content ?? []).map(mapProduit),
      },
    }));

export const createProduct = (product) => axiosInstance.post('/produits', product);

export const updateProduct = (id, product) => axiosInstance.put(`/produits/${id}`, product);

export const deleteProduct = (id) => axiosInstance.delete(`/produits/${id}`);
