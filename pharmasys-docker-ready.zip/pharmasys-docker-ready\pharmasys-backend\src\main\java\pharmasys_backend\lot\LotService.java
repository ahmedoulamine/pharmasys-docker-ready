package pharmasys_backend.lot;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import pharmasys_backend.produit.Produit;
import pharmasys_backend.produit.ProduitRepository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LotService {

    private final LotRepository    lotRepository;
    private final ProduitRepository produitRepository;

    @Transactional
    public LotResponse create(LotCreateRequest req) {
        Produit produit = produitRepository.findById(req.getProduitId())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Produit introuvable"));

        Lot lot = new Lot();
        lot.setProduit(produit);
        lot.setNumeroLot(req.getNumeroLot() != null && !req.getNumeroLot().isBlank()
            ? req.getNumeroLot()
            : "LOT-" + req.getNumeroBonLivraison() + "-" + produit.getId());
        lot.setDatePeremption(LocalDate.parse(req.getDatePeremption()));
        lot.setQuantiteInitiale(req.getQuantite() != null ? req.getQuantite() : 0);
        lot.setQuantiteRestante(req.getQuantite() != null ? req.getQuantite() : 0);
        lot.setFournisseur(req.getFournisseur());
        lot.setNumeroBonLivraison(req.getNumeroBonLivraison());
        if (req.getPrixAchat() != null)
            lot.setPrixAchat(BigDecimal.valueOf(req.getPrixAchat()));
        lot.setStatut(StatutLot.EN_STOCK);

        return LotResponse.from(lotRepository.save(lot));
    }

    public List<LotResponse> getByProduit(Long produitId) {
        return lotRepository.findByProduitId(produitId)
            .stream()
            .map(LotResponse::from)
            .collect(Collectors.toList());
    }

    public LotStatsResponse getStatsByProduit(Long produitId) {
        List<Lot> lots = lotRepository.findByProduitId(produitId);
        LocalDate today = LocalDate.now();
        String denomination = lots.isEmpty() ? "" : lots.get(0).getProduit().getDenomination();

        int ok     = lots.stream()
            .filter(l -> l.getStatut() == StatutLot.EN_STOCK && !l.getDatePeremption().isBefore(today))
            .mapToInt(l -> l.getQuantiteRestante() != null ? l.getQuantiteRestante() : 0).sum();
        int perime = lots.stream()
            .filter(l -> l.getStatut() == StatutLot.EN_STOCK && l.getDatePeremption().isBefore(today))
            .mapToInt(l -> l.getQuantiteRestante() != null ? l.getQuantiteRestante() : 0).sum();

        return new LotStatsResponse(produitId, denomination, ok, perime, lots.size());
    }

    @Transactional
    public LotResponse retire(Long id) {
        Lot lot = lotRepository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Lot introuvable"));
        lot.setStatut(StatutLot.RETIRE);
        lot.setQuantiteRestante(0);
        return LotResponse.from(lotRepository.save(lot));
    }

    /** Retourne uniquement les produits ayant des lots périmés en stock. */
    public List<LotStatsResponse> getExpiredSummary() {
        List<Lot> expired = lotRepository.findExpiredInStock(LocalDate.now());

        Map<Long, List<Lot>> byProduit = expired.stream()
            .collect(Collectors.groupingBy(l -> l.getProduit().getId()));

        return byProduit.entrySet().stream().map(e -> {
            List<Lot> ls     = e.getValue();
            String denom     = ls.get(0).getProduit().getDenomination();
            int totalPerime  = ls.stream()
                .mapToInt(l -> l.getQuantiteRestante() != null ? l.getQuantiteRestante() : 0).sum();
            return new LotStatsResponse(e.getKey(), denom, 0, totalPerime, ls.size());
        }).collect(Collectors.toList());
    }
}
