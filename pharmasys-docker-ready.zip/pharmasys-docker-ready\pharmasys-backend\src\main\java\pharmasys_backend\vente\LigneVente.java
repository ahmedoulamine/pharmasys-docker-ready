package pharmasys_backend.vente;

import jakarta.persistence.*;
import pharmasys_backend.produit.Produit;

import java.math.BigDecimal;

@Entity
@Table(name = "lignes_vente")
public class LigneVente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vente_id", nullable = false)
    private Vente vente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "produit_id", nullable = false)
    private Produit produit;

    @Column(nullable = false)
    private Integer quantite;

    @Column(name = "prix_unitaire", nullable = false, precision = 10, scale = 2)
    private BigDecimal prixUnitaire;

    @Column(name = "remise_ligne", nullable = false, precision = 5, scale = 2)
    private BigDecimal remiseLigne = BigDecimal.ZERO;

    @Column(name = "taux_tva", nullable = false, precision = 5, scale = 2)
    private BigDecimal tauxTva = BigDecimal.valueOf(7);

    @Column(name = "sous_total", nullable = false, precision = 10, scale = 2)
    private BigDecimal sousTotal;

    public Long getId()                  { return id; }
    public Vente getVente()              { return vente; }
    public Produit getProduit()          { return produit; }
    public Integer getQuantite()         { return quantite; }
    public BigDecimal getPrixUnitaire()  { return prixUnitaire; }
    public BigDecimal getTauxTva()       { return tauxTva; }
    public BigDecimal getSousTotal()     { return sousTotal; }

    public void setVente(Vente v)           { this.vente = v; }
    public void setProduit(Produit p)       { this.produit = p; }
    public void setQuantite(Integer q)      { this.quantite = q; }
    public void setPrixUnitaire(BigDecimal p){ this.prixUnitaire = p; }
    public void setRemiseLigne(BigDecimal r) { this.remiseLigne = r; }
    public void setTauxTva(BigDecimal t)    { this.tauxTva = t; }
    public void setSousTotal(BigDecimal s)  { this.sousTotal = s; }
}
