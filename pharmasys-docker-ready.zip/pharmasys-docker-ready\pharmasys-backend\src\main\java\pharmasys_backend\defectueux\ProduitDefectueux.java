package pharmasys_backend.defectueux;

import jakarta.persistence.*;
import pharmasys_backend.produit.Produit;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "produits_defectueux")
public class ProduitDefectueux {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "produit_id", nullable = false)
    private Produit produit;

    @Enumerated(EnumType.STRING)
    @Column(name = "type_defaut", nullable = false)
    private TypeDefaut typeDefaut;

    @Column(nullable = false)
    private String description;

    @Column(name = "quantite_concernee", nullable = false)
    private Integer quantiteConcernee;

    @Column(name = "date_detection", nullable = false)
    private LocalDate dateDetection;

    @Column(name = "date_signalement")
    private LocalDate dateSignalement = LocalDate.now();

    @Column(name = "signale_par_nom")
    private String signaledParNom;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Priorite priorite = Priorite.MOYENNE;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatutSignalement statut = StatutSignalement.EN_COURS;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId()                           { return id; }
    public Produit getProduit()                   { return produit; }
    public TypeDefaut getTypeDefaut()             { return typeDefaut; }
    public String getDescription()               { return description; }
    public Integer getQuantiteConcernee()        { return quantiteConcernee; }
    public LocalDate getDateDetection()          { return dateDetection; }
    public LocalDate getDateSignalement()        { return dateSignalement; }
    public String getSignaleParNom()             { return signaledParNom; }
    public Priorite getPriorite()                { return priorite; }
    public StatutSignalement getStatut()         { return statut; }
    public LocalDateTime getCreatedAt()          { return createdAt; }

    public void setProduit(Produit v)            { this.produit = v; }
    public void setTypeDefaut(TypeDefaut v)      { this.typeDefaut = v; }
    public void setDescription(String v)        { this.description = v; }
    public void setQuantiteConcernee(Integer v) { this.quantiteConcernee = v; }
    public void setDateDetection(LocalDate v)   { this.dateDetection = v; }
    public void setSignaleParNom(String v)      { this.signaledParNom = v; }
    public void setPriorite(Priorite v)         { this.priorite = v; }
    public void setStatut(StatutSignalement v)  { this.statut = v; }
}
