package pharmasys_backend.caisse;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/caisse")
@RequiredArgsConstructor
public class CaisseController {

    private final CaisseService caisseService;

    @GetMapping("/active")
    public ResponseEntity<SessionCaisse> getActive() {
        return caisseService.getActiveSession()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.noContent().build());
    }

    @GetMapping("/historique")
    public List<SessionCaisse> getHistorique() {
        return caisseService.getHistorique();
    }

    @PostMapping("/ouvrir")
    public ResponseEntity<SessionCaisse> ouvrir(@RequestBody Map<String, Double> body) {
        Double fond = body.getOrDefault("fondInitial", 0.0);
        return ResponseEntity.ok(caisseService.ouvrirSession(fond));
    }

    @PutMapping("/{id}/fermer")
    public ResponseEntity<SessionCaisse> fermer(@PathVariable Long id, @RequestBody Map<String, Double> body) {
        Double fond = body.getOrDefault("fondCloture", 0.0);
        return ResponseEntity.ok(caisseService.fermerSession(id, fond));
    }

}
