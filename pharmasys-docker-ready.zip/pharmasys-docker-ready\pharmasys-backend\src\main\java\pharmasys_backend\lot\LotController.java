package pharmasys_backend.lot;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lots")
@RequiredArgsConstructor
public class LotController {

    private final LotService lotService;

    @PostMapping
    public ResponseEntity<LotResponse> create(@RequestBody LotCreateRequest req) {
        return ResponseEntity.ok(lotService.create(req));
    }

    @GetMapping("/produit/{produitId}")
    public List<LotResponse> getByProduit(@PathVariable Long produitId) {
        return lotService.getByProduit(produitId);
    }

    @GetMapping("/produit/{produitId}/stats")
    public LotStatsResponse getStats(@PathVariable Long produitId) {
        return lotService.getStatsByProduit(produitId);
    }

    @PutMapping("/{id}/retire")
    public ResponseEntity<LotResponse> retire(@PathVariable Long id) {
        return ResponseEntity.ok(lotService.retire(id));
    }

    @GetMapping("/expired-summary")
    public List<LotStatsResponse> getExpiredSummary() {
        return lotService.getExpiredSummary();
    }
}
