package pharmasys_backend.client;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.Formula;
import java.time.LocalDate;

@Data
@Entity
@Table(name = "clients")
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nom;

    private String telephone;
    private String email;
    private String adresse;

    private LocalDate derniereVisite;

    @Column(nullable = false)
    private Integer nombreAchats = 0;

    @Column(nullable = false)
    private Double creditTotal = 0.0;

    // Crédit réel calculé depuis les ventes EN_ATTENTE (toujours à jour, lecture seule)
    @Formula("(SELECT COALESCE(SUM(v.total_ttc), 0) FROM ventes v " +
             "WHERE LOWER(v.patient_nom) = LOWER(nom) AND v.statut = 'EN_ATTENTE')")
    private Double creditReel;
}
