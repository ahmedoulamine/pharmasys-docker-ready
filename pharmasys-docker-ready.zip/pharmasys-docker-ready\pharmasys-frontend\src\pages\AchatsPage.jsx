import { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import "./AchatsPage.css";
import {
  getAllAchats,
  createAchat,
  confirmAchat,
  markAchatAsReceived,
} from "../services/achatService";
import { searchMedicaments } from "../services/api";
import {
  DollarSign, Clock3, BadgeCheck, Building2,
  CalendarDays, Search, FileText, Truck,
  CheckCircle2, Edit3, Package,
} from "lucide-react";

/* ── Méta statuts pour l'onglet Bons de commande ── */
const BC_META = {
  "Brouillon":  { css: "draft",     label: "Brouillon"  },
  "En attente": { css: "waiting",   label: "En attente" },
  "Confirmée":  { css: "confirmed", label: "Confirmée"  },
  "Reçue":      { css: "received",  label: "Reçue"      },
  "Annulé":     { css: "cancelled", label: "Annulé"     },
};

/* ── Statut simplifié pour l'onglet Achats ── */
function statutAchats(statut) {
  if (statut === "Reçue") return { label: "Reçue",     css: "received" };
  return                         { label: "En attente", css: "waiting"  };
}

export default function AchatsPage() {
  const location     = useLocation();
  const processedNav = useRef(false);

  const [activeTab, setActiveTab]         = useState("bons-commande");
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const [achats, setAchats]               = useState([]);
  const [filtreAchats, setFiltreAchats]   = useState("Toutes");
  const [filtreBC, setFiltreBC]           = useState("Tous");
  const [search, setSearch]               = useState("");
  const [selectedAchat, setSelectedAchat] = useState(null);

  /* Modals */
  const [showNewCommande, setShowNewCommande] = useState(false); // onglet Achats
  const [showNewBC, setShowNewBC]             = useState(false); // onglet BC
  const [suggestionsByIndex, setSuggestionsByIndex] = useState({});

  /* Form commande simple (onglet Achats) */
  const [commande, setCommande] = useState({
    fournisseur: "", datePrevue: "",
    articles: [{ produitId: null, name: "", quantite: 1, prix: 0 }],
  });
  const [commandeErrors, setCommandeErrors] = useState({});

  /* Form BC (onglet Bons de commande) */
  const [bc, setBc] = useState({
    fournisseur: "", datePrevue: "",
    articles: [{ produitId: null, name: "", quantite: 1, prix: 0 }],
  });
  const [bcErrors, setBcErrors] = useState({});
  const bcModalRef = useRef(null);

  useEffect(() => {
    const t = setInterval(() => setCurrentDateTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const loadAchats = async () => {
    try { setAchats((await getAllAchats()).data ?? []); }
    catch { setAchats([]); }
  };
  useEffect(() => { loadAchats(); }, []);

  /* Navigation depuis Stock > alerte */
  useEffect(() => {
    if (!processedNav.current && location.state?.openModal && location.state?.produit) {
      processedNav.current = true;
      const p = location.state.produit;
      setCommande(prev => ({
        ...prev,
        articles: [{ produitId: p.id ?? null, name: p.nom ?? p.name ?? "", quantite: p.quantite ?? 1, prix: p.prixAchat ?? 0 }],
      }));
      setActiveTab("achats");
      setShowNewCommande(true);
      window.history.replaceState({}, "");
    }
  }, [location.state]);

  /* ── Données dérivées ── */
  const bonsCommande = achats.filter(a => !["Reçue", "Annulé"].includes(a.statut));
  const q = search.toLowerCase();

  /* Onglet Achats : TOUS les achats */
  const achatsFiltres = achats.filter(a => {
    const matchF = filtreAchats === "Toutes" || (filtreAchats === "Reçues" ? a.statut === "Reçue" : a.statut !== "Reçue" && a.statut !== "Annulé");
    const matchS = (a.fournisseur ?? "").toLowerCase().includes(q) || (a.reference ?? a.numeroBC ?? "").toLowerCase().includes(q);
    return matchF && matchS;
  });
  const totalMois   = achats.reduce((s, a) => s + (a.montant ?? a.totalHt ?? 0), 0);
  const nbEnAttente = achats.filter(a => a.statut !== "Reçue" && a.statut !== "Annulé").length;
  const nbRecues    = achats.filter(a => a.statut === "Reçue").length;
  const nbFourn     = new Set(achats.map(a => a.fournisseur).filter(Boolean)).size;

  /* Onglet Bons de commande */
  const bcFiltres = bonsCommande.filter(a => {
    const matchF = filtreBC === "Tous" || a.statut === filtreBC;
    const matchS = (a.fournisseur ?? "").toLowerCase().includes(q) || (a.numeroBC ?? a.reference ?? "").toLowerCase().includes(q);
    return matchF && matchS;
  });
  const nbBCConfirmees = bonsCommande.filter(a => a.statut === "Confirmée").length;
  const nbBCEnAttente  = bonsCommande.filter(a => a.statut === "En attente").length;
  const nbBCBrouillons = bonsCommande.filter(a => a.statut === "Brouillon").length;
  const totalBCMois    = bonsCommande.reduce((s, a) => s + (a.totalHt ?? a.montant ?? 0), 0);

  /* Helpers */
  const fmt    = n => (n ?? 0).toLocaleString("fr-FR", { minimumFractionDigits: 2 });
  const fmtD   = d => d ? new Date(d).toLocaleDateString("fr-FR") : "—";
  const htOf   = a => a.totalHt ?? a.montant ?? 0;
  const ttcOf  = a => a.totalTtc ?? htOf(a) * 1.1;
  const numOf  = a => a.reference ?? a.numeroBC ?? "—";
  const artOf  = a => a.articlesCount ?? a.lignes?.length ?? 0;

  /* Recherche médicament */
  const searchMeds = async (text, index, setter) => {
    if (text.trim().length < 2) { setSuggestionsByIndex(p => ({ ...p, [index]: [] })); return; }
    try {
      const res = await searchMedicaments(text);
      setSuggestionsByIndex(p => ({ ...p, [index]: res }));
    } catch { setSuggestionsByIndex(p => ({ ...p, [index]: [] })); }
  };

  const updateArt = (form, setForm, index, patch) =>
    setForm({ ...form, articles: form.articles.map((a, i) => i === index ? { ...a, ...patch } : a) });

  /* Actions */
  const doCreateCommande = async () => {
    const errors = {};
    if (!commande.fournisseur) errors.fournisseur = "Veuillez sélectionner un fournisseur";
    if (!commande.datePrevue)  errors.datePrevue  = "Veuillez saisir une date de livraison";
    if (Object.keys(errors).length > 0) { setCommandeErrors(errors); return; }
    setCommandeErrors({});
    const totalHt = commande.articles.reduce((s, a) => s + a.quantite * a.prix, 0);
    const seq = achats.length + 1;
    try {
      await createAchat({
        reference:    `CMD-${new Date().getFullYear()}-${String(seq).padStart(3, "0")}`,
        fournisseur:  commande.fournisseur,
        datePrevue:   commande.datePrevue,
        articlesCount:commande.articles.length,
        montant:      totalHt,
        totalHt,
        totalTtc:     Math.round(totalHt * 1.1 * 100) / 100,
        statut:       "En attente",
        lignes:       commande.articles.map(a => ({ produitId: a.produitId, nom: a.name, quantite: a.quantite, prixUnitaire: a.prix })),
      });
      loadAchats();
      setCommande({ fournisseur: "", datePrevue: "", articles: [{ produitId: null, name: "", quantite: 1, prix: 0 }] });
      setShowNewCommande(false);
    } catch { alert("Erreur lors de la création."); }
  };

  const doCreateBC = async (statut) => {
    const errors = {};
    if (!bc.fournisseur) errors.fournisseur = "Veuillez sélectionner un fournisseur";
    if (!bc.datePrevue)  errors.datePrevue  = "Veuillez saisir une date de livraison";
    if (Object.keys(errors).length > 0) {
      setBcErrors(errors);
      bcModalRef.current?.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    setBcErrors({});
    const totalHt = bc.articles.reduce((s, a) => s + a.quantite * a.prix, 0);
    try {
      await createAchat({
        fournisseur:  bc.fournisseur,
        datePrevue:   bc.datePrevue,
        articlesCount:bc.articles.length,
        montant:      totalHt,
        totalHt,
        totalTtc:     Math.round(totalHt * 1.1 * 100) / 100,
        statut,
        lignes:       bc.articles.map(a => ({ produitId: a.produitId, nom: a.name, quantite: a.quantite, prixUnitaire: a.prix })),
      });
      loadAchats();
      setBc({ fournisseur: "", datePrevue: "", articles: [{ produitId: null, name: "", quantite: 1, prix: 0 }] });
      setShowNewBC(false);
    } catch { alert("Erreur lors de la création."); }
  };

  const doConfirm  = async a => { try { await confirmAchat(a.id);        loadAchats(); } catch { } };
  const doReceive  = async a => { try { await markAchatAsReceived(a.id); setSelectedAchat(null); loadAchats(); } catch { } };

  const fournisseurs = ["Laboratoire SOTHEMA","Distributeur Pharma Maroc","Cooper Pharma","PharmaDist","MediSupply","PharmaCorp","BioMed","SanofiDist","Pharma 5"];

  const formattedDate = currentDateTime.toLocaleDateString("fr-FR", { weekday:"long", day:"numeric", month:"long", year:"numeric" });
  const formattedTime = currentDateTime.toLocaleTimeString("fr-FR");

  /* ─────────────────── RENDER ─────────────────── */
  return (
    <div className="achats-page">

      {/* Header */}
      <div className="achats-top-header">
        <h2>Achats</h2>
        <span className="separator" />
        <span className="header-icon"><CalendarDays size={20} />{formattedDate}</span>
        <span className="header-icon"><Clock3 size={20} />{formattedTime}</span>
      </div>

      {/* Onglets */}
      <div className="achats-page-tabs">
        <button className={`page-tab ${activeTab === "achats" ? "page-tab--active" : ""}`}
          onClick={() => { setActiveTab("achats"); setSearch(""); }}>
          <Truck size={18} /> Achats
        </button>
        <button className={`page-tab ${activeTab === "bons-commande" ? "page-tab--active" : ""}`}
          onClick={() => { setActiveTab("bons-commande"); setSearch(""); }}>
          <FileText size={18} /> Bons de commande
          {bonsCommande.length > 0 && <span className="tab-badge">{bonsCommande.length}</span>}
        </button>
      </div>

      <div className="achats-content">

        {/* ══════════════════════════════════════════
            ONGLET : ACHATS FOURNISSEURS
        ══════════════════════════════════════════ */}
        {activeTab === "achats" && (<>
          <div className="achats-title-row">
            <div>
              <h1>Achats Fournisseurs</h1>
              <p>Gérer les commandes et livraisons</p>
            </div>
          </div>

          <div className="stats-grid">
            <div className="stat-card">
              <div><p>Total du mois</p><h2>{fmt(totalMois)} DH</h2></div>
              <div className="stat-icon green"><Truck size={32} /></div>
            </div>
            <div className="stat-card">
              <div><p>En attente</p><h2 className="orange-text">{nbEnAttente}</h2></div>
              <div className="stat-icon orange"><Clock3 size={32} /></div>
            </div>
            <div className="stat-card">
              <div><p>Reçues</p><h2 className="green-text">{nbRecues}</h2></div>
              <div className="stat-icon green"><BadgeCheck size={32} /></div>
            </div>
            <div className="stat-card">
              <div><p>Fournisseurs</p><h2>{nbFourn}</h2></div>
              <div className="stat-icon blue"><Building2 size={32} /></div>
            </div>
          </div>

          <div className="filter-card">
            <div className="search-box">
              <Search size={20} className="search-icon" />
              <input type="text" placeholder="Rechercher par fournisseur ou référence..."
                value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            {["Toutes","En attente","Reçues"].map(f => (
              <button key={f}
                className={`filter-tab ${filtreAchats === f ? (f === "Reçues" ? "active-green" : f === "En attente" ? "active-orange" : "active-green") : ""}`}
                onClick={() => setFiltreAchats(f)}>{f}</button>
            ))}
          </div>

          <div className="achats-table-card">
            <table>
              <thead>
                <tr>
                  <th>Référence</th><th>Fournisseur</th><th>Date commande</th>
                  <th>Date prévue</th><th>Articles</th><th>Montant</th><th>Statut</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {achatsFiltres.length === 0 ? (
                  <tr><td colSpan={8} className="empty-row">Aucune commande</td></tr>
                ) : achatsFiltres.map(achat => {
                  const s = statutAchats(achat.statut);
                  return (
                    <tr key={achat.id}>
                      <td className="bold">{numOf(achat)}</td>
                      <td>{achat.fournisseur}</td>
                      <td><span className="date-cell"><CalendarDays size={15} />{fmtD(achat.dateCommande)}</span></td>
                      <td><span className="date-cell"><CalendarDays size={15} />{fmtD(achat.datePrevue)}</span></td>
                      <td>{artOf(achat)} article{artOf(achat) > 1 ? "s" : ""}</td>
                      <td className="bold">{fmt(achat.montant ?? achat.totalHt ?? 0)} DH</td>
                      <td><span className={`status-badge ${s.css}`}>{s.label}</span></td>
                      <td><button className="details-btn" onClick={() => setSelectedAchat(achat)}>Détails</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>)}

        {/* ══════════════════════════════════════════
            ONGLET : BONS DE COMMANDE
        ══════════════════════════════════════════ */}
        {activeTab === "bons-commande" && (<>
          <div className="achats-title-row" style={{ marginTop: 32 }}>
            <div /> {/* spacer gauche */}
            <button className="new-order-btn" onClick={() => setShowNewBC(true)}>
              + Nouveau bon de commande
            </button>
          </div>

          <div className="stats-grid" style={{ marginTop: 0 }}>
            <div className="stat-card">
              <div><p>Total ce mois</p><h2>{fmt(totalBCMois)} DH</h2></div>
              <div className="stat-icon green"><FileText size={32} /></div>
            </div>
            <div className="stat-card">
              <div><p>Confirmées</p><h2 className="blue-text">{nbBCConfirmees}</h2></div>
              <div className="stat-icon blue"><CheckCircle2 size={32} /></div>
            </div>
            <div className="stat-card">
              <div><p>En attente</p><h2 className="orange-text">{nbBCEnAttente}</h2></div>
              <div className="stat-icon orange"><Clock3 size={32} /></div>
            </div>
            <div className="stat-card">
              <div><p>Brouillons</p><h2 className="gray-text">{nbBCBrouillons}</h2></div>
              <div className="stat-icon gray"><Edit3 size={32} /></div>
            </div>
          </div>

          <div className="filter-card">
            <div className="search-box">
              <Search size={20} className="search-icon" />
              <input type="text" placeholder="Rechercher par fournisseur ou N° bon..."
                value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            {["Tous","Brouillon","En attente","Confirmée"].map(f => (
              <button key={f}
                className={`filter-tab ${filtreBC === f ? (f==="Brouillon"?"active-gray":f==="En attente"?"active-orange":f==="Confirmée"?"active-blue":"active-green") : ""}`}
                onClick={() => setFiltreBC(f)}>{f}</button>
            ))}
          </div>

          <div className="achats-table-card">
            <table>
              <thead>
                <tr>
                  <th>N° Bon</th><th>Fournisseur</th><th>Date commande</th>
                  <th>Date livraison</th><th>Articles</th><th>Total HT</th><th>Total TTC</th><th>Statut</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {bcFiltres.length === 0 ? (
                  <tr><td colSpan={9} className="empty-row">Aucun bon de commande</td></tr>
                ) : bcFiltres.map(achat => {
                  const meta = BC_META[achat.statut] ?? { css:"waiting", label:achat.statut };
                  return (
                    <tr key={achat.id}>
                      <td className="bold">{achat.numeroBC ?? achat.reference ?? "—"}</td>
                      <td>{achat.fournisseur}</td>
                      <td><span className="date-cell"><CalendarDays size={15} />{fmtD(achat.dateCommande)}</span></td>
                      <td><span className="date-cell"><CalendarDays size={15} />{fmtD(achat.datePrevue)}</span></td>
                      <td>{artOf(achat)} article{artOf(achat)>1?"s":""}</td>
                      <td className="bold">{fmt(htOf(achat))} DH</td>
                      <td>{fmt(ttcOf(achat))} DH</td>
                      <td><span className={`status-badge ${meta.css}`}>{meta.label}</span></td>
                      <td>
                        <div className="action-btns">
                          {achat.statut === "Brouillon"  && <button className="action-btn send-btn"    onClick={() => doConfirm(achat)}>Envoyer</button>}
                          {achat.statut === "En attente" && <button className="action-btn confirm-btn"  onClick={() => doConfirm(achat)}>Confirmer</button>}
                          {achat.statut === "Confirmée"  && <button className="action-btn receive-btn-sm" onClick={() => doReceive(achat)}>Réceptionner</button>}
                          <button className="details-btn" onClick={() => setSelectedAchat(achat)}>Détails</button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>)}

        {/* ══════════════════════════════════════════
            MODAL : NOUVELLE COMMANDE (onglet Achats)
        ══════════════════════════════════════════ */}
        {showNewCommande && (
          <div className="modal-overlay">
            <div className="details-modal">
              <div className="modal-header"><h2>Nouvelle Commande Fournisseur</h2></div>
              <div className="modal-info-grid">
                <div>
                  <p>Fournisseur {commandeErrors.fournisseur && <span style={{ color:"#dc2626", fontSize:12, fontWeight:600 }}>— {commandeErrors.fournisseur}</span>}</p>
                  <select
                    className="modal-input"
                    value={commande.fournisseur}
                    style={commandeErrors.fournisseur ? { borderColor:"#dc2626", boxShadow:"0 0 0 2px #fee2e2" } : {}}
                    onChange={e => { setCommande({...commande,fournisseur:e.target.value}); setCommandeErrors(p=>({...p,fournisseur:undefined})); }}>
                    <option value="">Sélectionner un fournisseur</option>
                    {fournisseurs.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div>
                  <p>Date de livraison prévue {commandeErrors.datePrevue && <span style={{ color:"#dc2626", fontSize:12, fontWeight:600 }}>— {commandeErrors.datePrevue}</span>}</p>
                  <input
                    type="date"
                    className="modal-input"
                    value={commande.datePrevue}
                    style={commandeErrors.datePrevue ? { borderColor:"#dc2626", boxShadow:"0 0 0 2px #fee2e2" } : {}}
                    onChange={e => { setCommande({...commande,datePrevue:e.target.value}); setCommandeErrors(p=>({...p,datePrevue:undefined})); }} />
                </div>
              </div>
              <h3 className="articles-title">Articles</h3>
              <div className="ordered-items">
                {commande.articles.map((art, i) => (
                  <div className="ordered-item" key={i}>
                    <div className="medicine-search">
                      <input type="text" className="article-name-input" placeholder="Nom du médicament..."
                        value={art.name}
                        onChange={e => { updateArt(commande, setCommande, i, {name:e.target.value,produitId:null,prix:0}); searchMeds(e.target.value,i); }} />
                      {suggestionsByIndex[i]?.length > 0 && (
                        <div className="medicine-suggestions">
                          {suggestionsByIndex[i].map(p => (
                            <div className="medicine-suggestion-item" key={p.id}
                              onClick={() => { updateArt(commande,setCommande,i,{produitId:p.id,name:p.nom??p.denomination??"",prix:p.prixAchat??0}); setSuggestionsByIndex(s=>({...s,[i]:[]})); }}>
                              <strong>{p.nom??p.denomination}</strong>
                              <span>{p.formeDosage??""} — {(p.prixAchat??0).toFixed(2)} DH</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div><label>Quantité</label>
                      <input type="number" min={1} value={art.quantite}
                        onChange={e => updateArt(commande,setCommande,i,{quantite:Number(e.target.value)})} /></div>
                    <div><label>Prix HA (DH)</label>
                      <input type="number" min={0} value={art.prix}
                        onChange={e => updateArt(commande,setCommande,i,{prix:Number(e.target.value)})} /></div>
                    <div className="article-total"><label>Total</label>
                      <strong>{((art.quantite??0)*(art.prix??0)).toLocaleString("fr-FR")} DH</strong></div>
                    <button className="remove-article-btn"
                      onClick={() => setCommande({...commande,articles:commande.articles.filter((_,j)=>j!==i)})}>×</button>
                  </div>
                ))}
                <button className="add-medicine-btn"
                  onClick={() => setCommande({...commande,articles:[...commande.articles,{produitId:null,name:"",quantite:1,prix:0}]})}>
                  + Ajouter un médicament
                </button>
              </div>
              <div className="modal-total">
                <div><span>Total HT</span>
                  <strong>{commande.articles.reduce((s,a)=>s+(a.quantite??0)*(a.prix??0),0).toLocaleString("fr-FR")} DH</strong></div>
              </div>
              <div className="modal-actions">
                <button className="close-btn" onClick={() => { setShowNewCommande(false); setCommandeErrors({}); }}>Annuler</button>
                <button className="receive-btn" onClick={doCreateCommande}>Créer la commande</button>
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════
            MODAL : NOUVEAU BON DE COMMANDE (onglet BC)
        ══════════════════════════════════════════ */}
        {showNewBC && (
          <div className="modal-overlay">
            <div className="details-modal" ref={bcModalRef} style={{ overflowY: "auto", maxHeight: "90vh" }}>
              <div className="modal-header"><h2>Nouveau Bon de Commande</h2></div>
              <div className="modal-info-grid">
                <div>
                  <p>Fournisseur {bcErrors.fournisseur && <span style={{ color: "#dc2626", fontSize: 12, fontWeight: 600 }}>— {bcErrors.fournisseur}</span>}</p>
                  <select
                    className="modal-input"
                    value={bc.fournisseur}
                    style={bcErrors.fournisseur ? { borderColor: "#dc2626", boxShadow: "0 0 0 2px #fee2e2" } : {}}
                    onChange={e => { setBc({...bc,fournisseur:e.target.value}); setBcErrors(p => ({...p,fournisseur:undefined})); }}>
                    <option value="">Sélectionner un fournisseur</option>
                    {fournisseurs.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div>
                  <p>Date de livraison prévue {bcErrors.datePrevue && <span style={{ color: "#dc2626", fontSize: 12, fontWeight: 600 }}>— {bcErrors.datePrevue}</span>}</p>
                  <input
                    type="date"
                    className="modal-input"
                    value={bc.datePrevue}
                    style={bcErrors.datePrevue ? { borderColor: "#dc2626", boxShadow: "0 0 0 2px #fee2e2" } : {}}
                    onChange={e => { setBc({...bc,datePrevue:e.target.value}); setBcErrors(p => ({...p,datePrevue:undefined})); }} />
                </div>
              </div>
              <h3 className="articles-title">Articles</h3>
              <div className="ordered-items">
                {bc.articles.map((art, i) => (
                  <div className="ordered-item" key={i}>
                    <div className="medicine-search">
                      <input type="text" className="article-name-input" placeholder="Nom du médicament..."
                        value={art.name}
                        onChange={e => { updateArt(bc,setBc,i,{name:e.target.value,produitId:null,prix:0}); searchMeds(e.target.value,`bc_${i}`); }} />
                      {suggestionsByIndex[`bc_${i}`]?.length > 0 && (
                        <div className="medicine-suggestions">
                          {suggestionsByIndex[`bc_${i}`].map(p => (
                            <div className="medicine-suggestion-item" key={p.id}
                              onClick={() => { updateArt(bc,setBc,i,{produitId:p.id,name:p.nom??p.denomination??"",prix:p.prixAchat??0}); setSuggestionsByIndex(s=>({...s,[`bc_${i}`]:[]})); }}>
                              <strong>{p.nom??p.denomination}</strong>
                              <span>{p.formeDosage??""} — {(p.prixAchat??0).toFixed(2)} DH</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div><label>Quantité</label>
                      <input type="number" min={1} value={art.quantite}
                        onChange={e => updateArt(bc,setBc,i,{quantite:Number(e.target.value)})} /></div>
                    <div><label>Prix HA (DH)</label>
                      <input type="number" min={0} value={art.prix}
                        onChange={e => updateArt(bc,setBc,i,{prix:Number(e.target.value)})} /></div>
                    <div className="article-total"><label>Total</label>
                      <strong>{((art.quantite??0)*(art.prix??0)).toLocaleString("fr-FR")} DH</strong></div>
                    <button className="remove-article-btn"
                      onClick={() => setBc({...bc,articles:bc.articles.filter((_,j)=>j!==i)})}>×</button>
                  </div>
                ))}
                <button className="add-medicine-btn"
                  onClick={() => setBc({...bc,articles:[...bc.articles,{produitId:null,name:"",quantite:1,prix:0}]})}>
                  + Ajouter un médicament
                </button>
              </div>
              <div className="modal-total">
                <div><span>Total HT</span>
                  <strong>{bc.articles.reduce((s,a)=>s+(a.quantite??0)*(a.prix??0),0).toLocaleString("fr-FR")} DH</strong></div>
                <div><span>Total TTC</span>
                  <strong className="ttc-val">{(bc.articles.reduce((s,a)=>s+(a.quantite??0)*(a.prix??0),0)*1.1).toLocaleString("fr-FR",{maximumFractionDigits:2})} DH</strong></div>
              </div>
              <div className="modal-actions">
                <button className="close-btn" onClick={() => { setShowNewBC(false); setBcErrors({}); }}>Annuler</button>
                <button className="draft-btn" onClick={() => doCreateBC("Brouillon")}>Enregistrer brouillon</button>
                <button className="receive-btn" onClick={() => doCreateBC("En attente")}>Envoyer commande</button>
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════
            MODAL : DÉTAILS
        ══════════════════════════════════════════ */}
        {selectedAchat && (() => {
          const isBC = !!selectedAchat.numeroBC;
          const meta = isBC ? (BC_META[selectedAchat.statut] ?? {css:"waiting",label:selectedAchat.statut}) : statutAchats(selectedAchat.statut);
          return (
            <div className="modal-overlay">
              <div className="details-modal">
                <div className="modal-header">
                  <h2>Détails — {numOf(selectedAchat)}</h2>
                  <span className={`status-badge ${meta.css}`}>{meta.label}</span>
                </div>
                <div className="modal-info-grid">
                  <div><p>Référence</p><h3>{numOf(selectedAchat)}</h3></div>
                  <div><p>Fournisseur</p><h3>{selectedAchat.fournisseur}</h3></div>
                  <div><p>Date de commande</p><h3>{fmtD(selectedAchat.dateCommande)}</h3></div>
                  <div><p>Date livraison prévue</p><h3>{fmtD(selectedAchat.datePrevue)}</h3></div>
                </div>
                {selectedAchat.lignes?.length > 0 && (
                  <>
                    <h3 className="articles-title">Articles</h3>
                    <table className="lignes-table">
                      <thead><tr><th>Médicament</th><th>Qté</th><th>Prix HA</th><th>Total</th></tr></thead>
                      <tbody>
                        {selectedAchat.lignes.map((l,i)=>(
                          <tr key={i}>
                            <td>{l.nom}</td><td>{l.quantite}</td>
                            <td>{(l.prixUnitaire??0).toFixed(2)} DH</td>
                            <td className="bold">{((l.quantite??0)*(l.prixUnitaire??0)).toFixed(2)} DH</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </>
                )}
                <div className="modal-total">
                  <div><span>Montant HT</span><strong>{fmt(htOf(selectedAchat))} DH</strong></div>
                  {isBC && <div><span>Total TTC</span><strong className="ttc-val">{fmt(ttcOf(selectedAchat))} DH</strong></div>}
                </div>
                <div className="modal-actions">
                  <button className="close-btn" onClick={() => setSelectedAchat(null)}>Fermer</button>
                  {selectedAchat.statut === "Brouillon"  && <button className="receive-btn" onClick={()=>{doConfirm(selectedAchat);setSelectedAchat(null);}}>Envoyer commande</button>}
                  {selectedAchat.statut === "En attente" && <button className="receive-btn" onClick={()=>{isBC?doConfirm(selectedAchat):doReceive(selectedAchat);}}>
                    {isBC ? "Confirmer" : "Marquer comme reçue"}
                  </button>}
                  {selectedAchat.statut === "Confirmée"  && <button className="receive-btn" onClick={()=>doReceive(selectedAchat)}>Réceptionner</button>}
                </div>
              </div>
            </div>
          );
        })()}

      </div>
    </div>
  );
}
