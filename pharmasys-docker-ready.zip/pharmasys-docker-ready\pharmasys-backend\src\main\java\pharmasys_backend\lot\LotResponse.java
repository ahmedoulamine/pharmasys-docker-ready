package pharmasys_backend.lot;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class LotResponse {
    public Long          id;
    public Long          produitId;
    public String        denomination;
    public String        numeroLot;
    public LocalDate     dateFabrication;
    public LocalDate     datePeremption;
    public Integer       quantiteInitiale;
    public Integer       quantiteRestante;
    public String        fournisseur;
    public String        numeroBonLivraison;
    public BigDecimal    prixAchat;
    public String        statut;
    public boolean       perime;
    public LocalDateTime createdAt;

    public static LotResponse from(Lot l) {
        LotResponse r = new LotResponse();
        r.id                 = l.getId();
        r.produitId          = l.getProduit().getId();
        r.denomination       = l.getProduit().getDenomination();
        r.numeroLot          = l.getNumeroLot();
        r.dateFabrication    = l.getDateFabrication();
        r.datePeremption     = l.getDatePeremption();
        r.quantiteInitiale   = l.getQuantiteInitiale();
        r.quantiteRestante   = l.getQuantiteRestante();
        r.fournisseur        = l.getFournisseur();
        r.numeroBonLivraison = l.getNumeroBonLivraison();
        r.prixAchat          = l.getPrixAchat();
        r.statut             = l.getStatut().name();
        r.perime             = l.getDatePeremption().isBefore(LocalDate.now());
        r.createdAt          = l.getCreatedAt();
        return r;
    }
}
