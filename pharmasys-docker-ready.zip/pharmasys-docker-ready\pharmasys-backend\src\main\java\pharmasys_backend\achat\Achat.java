package pharmasys_backend.achat;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.persistence.Column;
import lombok.Data;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "achats")
public class Achat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String reference;

    @Column(name = "numero_bc")
    private String numeroBC;

    private String fournisseur;
    private LocalDate dateCommande;
    private LocalDate datePrevue;
    private Integer articlesCount;
    private Double montant;

    @Column(name = "total_ht")
    private Double totalHt;

    @Column(name = "total_ttc")
    private Double totalTtc;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatutAchat statut = StatutAchat.EN_ATTENTE;

    @OneToMany(mappedBy = "achat", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @JsonIgnoreProperties("achat")
    private List<LigneAchat> lignes = new ArrayList<>();
}
